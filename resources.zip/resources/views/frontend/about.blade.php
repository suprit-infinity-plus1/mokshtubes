@extends('layouts.master')
@section('title', 'About Mokshtubes LLP | Expert in High-Performance Alloys')
@section('meta_description', 'Learn about Mokshtubes LLP, a trusted global supplier of stainless steel, nickel alloys, Hastelloy, Inconel and custom-engineered metal solutions for critical industries.')
@section(
        'meta_keywords',
        'Mokshtubes, Metal Alloys Supplier, High Performance Alloys, Industrial Metal Solutions,
    Premium Quality Alloys, Alloy Tubes, Engineering Alloys'
)

{{-- Only custom OG fields --}}
@section('og_image', asset('assets/images/about/fabrication-workshop-banner.webp'))
@section('og_type', 'website')

@section('content')

    <!--Start breadcrumb area-->
    <section class="breadcrumb-area" style="background-image: url(/assets/images/about/fabrication-workshop-banner.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>About Moksh Tubes <br> Trusted Alloy Experts</h1> <!-- 52 characters -->
                </div>
            </div>
        </div>
    </section>

    <!--End breadcrumb area-->


    <section class="about-us sec-padd-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-12">

                    <figure class="about-img h-100 m-0">
                        <img src="{{ asset('assets/images/about/steel-pipes-tubes-bars-sections.webp') }}" width="1000" height="750"
                            alt="Stainless steel pipes, tubes, bars and structural sections" class="img-fluid w-100 h-100 object-fit-cover custom-img"
                            loading="lazy">
                    </figure>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <div class="about-text">
                        <h2>
                            About <span class="thm-color">Moksh Tubes & Fittings LLP</span>
                        </h2>
                        <div class="text">
                            <p>
                                <strong class="text-black">
                                    MOKSH TUBES & FITTINGS LLP
                                </strong>
                                is one of the leading suppliers,
                                stockists, and exporters of <strong class="text-black"><a
                                        href="{{ route('products.pipes-tubes') }}"> Pipes & Tubes</a>, Pipe Fittings,
                                    Flanges,
                                    Fasteners, Sheets
                                    & Plates, Coils, Wires, Round Bars, Flat Bars, Angles, Channels, Welding rods,
                                    Wire
                                    Mesh, and other Custom and Hard to Find Steel Products. </strong> <br> <br>

                                With a strong focus on reliability and precision, we specialize in catering to a
                                diverse industrial sectors by offering a wide range of materials in <strong
                                    class="text-black">ferrous
                                    and
                                    non-ferrous grades, including Stainless Steel, Duplex & Super Duplex Steel,
                                    Nickel
                                    Alloys such as <a href="{{ route('materials.hastelloy') }}"> Hastelloy</a>,<a
                                        href="{{ route('materials.inconel') }}"> Inconel</a>,<a
                                        href="{{ route('materials.monel') }}"> Monel</a>, Titanium Alloys, Copper & Bronze
                                    Alloys,
                                    Carbon Steel Alloys, Rare Alloys such as Nimonic, ferralium, Zirconium, Tantalum
                                    and
                                    so on. </strong> <br> <br>

                                Our extensive inventory and top-notch sourcing capabilities enables us to assist
                                our
                                clients with all their project requirements across Industries like Oil & Gas,
                                Sugar
                                Industries, Dairies, Boilers & Pressure Vessels, Petrochemicals, Water
                                Management,
                                Pharmaceuticals, Marine, Food & Beverage Processing, Power Generation,
                                Construction,
                                Solar, and Chemical Industries.

                            </p>
                        </div>


                    </div>


                </div>
                <div class="fact-counter">
                    <ul class="d-flex flex-wrap justify-content-center gap-5">
                        <li class="single-fact-counter">
                            <div class="icon-holder"><span class="flaticon-social"></span></div>
                            <span class="timer" data-from="1" data-to="20" data-speed="5000"
                                data-refresh-interval="50">20</span>
                            <i class="fa fa-plus" aria-hidden="true"></i>
                            <h3>Years of Experience</h3>
                        </li>
                        <li class="single-fact-counter">
                            <div class="icon-holder"><span class="flaticon-landscape"></span></div>
                            <span class="timer" data-from="1" data-to="12" data-speed="5000"
                                data-refresh-interval="50">12</span>
                            <i class="fa fa-plus" aria-hidden="true"></i>
                            <h3>Countries Served Globally</h3>
                        </li>
                        <li class="single-fact-counter">
                            <div class="icon-holder"><span class="flaticon-innovation"></span></div>
                            <span class="timer" data-from="1" data-to="300" data-speed="5000"
                                data-refresh-interval="50">300</span>
                            <i class="fa fa-plus" aria-hidden="true"></i>
                            <h3>Projects Completed</h3>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="call-out sec-padd center" style="background-image: url(images/background/2.jpg);">
        <div class="container">
            <div class="content">
                <h2>Action Is the Foundational Key to All Success</h2>
                <p>Quality materials. Reliable supply. Trusted by professionals across industries, we’re here to
                    support your success with products built to perform.</p>

                <a href="{{ route('contact-us') }}" class="thm-btn bg-clr1">contact us</a>
            </div>
        </div>
    </section>


    <section>
        <div class="container vision-mission">
            <!-- First Row: Text Left, Image Right -->
            <div class="row align-items-center mb-5">
                <div class="col-md-6">
                    <h2>Our History</h2>
                    <p>
                        Established in the year <strong class="text-black">2005</strong> by <strong class="text-black">Mr.
                            Vikram B. Jain and Mr. Naresh
                            B. Jain, Moksh Tubes &
                            Fittings LLP,</strong>
                        which had started as a modest venture has evolved into a global leader in
                        <strong class="text-black">manufacturing
                            and
                            supply of
                            a wide range of Steel Products.</strong>
                    </p>
                    <h2 class="mt-4">Our Mission</h2>
                    <p>
                        To provide immediate access to our clients by giving them access to a comprehensive range of
                        piping
                        products & components in various material options.
                    </p>
                </div>
                <div class="col-md-6 text-center">
                    <!-- Desktop Image -->
                    <img src="{{ asset('assets/images/history/our-mission.webp') }}" width="1843" height="997" alt="Large"
                        class="img-fluid d-none d-lg-block" loading="lazy">
                    <!-- Tablet Image 400x250-->
                    <img src="{{ asset('assets/images/history/our-mission.webp') }}" width="1843" height="997" alt="Tablet"
                        class="img-fluid d-none d-md-block d-lg-none" loading="lazy">
                    <!-- Mobile Image 300x200 -->
                    <img src="{{ asset('assets/images/history/our-mission.webp') }}" width="1843" height="997" alt="Mobile"
                        class="img-fluid d-block d-md-none mx-auto" loading="lazy">
                </div>
            </div>

            <!-- Second Row: Image Left, Text Right -->
            <div class="row align-items-center mb-5 flex-md-row-reverse">
                <div class="col-md-6">
                    <h2>Our Vision</h2>
                    <p>
                        To support a broad spectrum of industries by supplying high quality materials where quality,
                        corrosion & heat resistance and timely deliveries are critical to operations.
                    </p>
                    <h2 class="mt-4">Our Goal</h2>
                    <p>
                        To expand our global footprint while maintaining the highest standards of quality in
                        delivering
                        reliable solutions for our customer’s most demanding projects and critical applications.
                    </p>
                </div>
                <div class="col-md-6 text-center">
                    <!-- Desktop Image 600x300 -->
                    <img src="{{ asset('assets/images/history/our-goal.webp') }}" width="1920" height="1080" alt="Large"
                        class="img-fluid d-none d-lg-block">
                    <!-- Tablet Image 400x250 -->
                    <img src="{{ asset('assets/images/history/our-goal.webp') }}" width="1920" height="1080" alt="Tablet"
                        class="img-fluid d-none d-md-block d-lg-none">
                    <!-- Mobile Image 300x200 -->
                    <img src="{{ asset('assets/images/history/our-goal.webp') }}" width="1920" height="1080" alt="Mobile"
                        class="img-fluid d-block d-md-none mx-auto">
                </div>
            </div>
        </div>



        <section class="why-chooseus sec-padd2">
            <div class="container">

                <div class="section-title center">
                    <h2>Why Choose Us</h2>
                </div>

                <div class="row">
                    <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box wow fadeIn animated" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="icon_box">
                                <span class="fas fa-warehouse
            "></span>
                            </div>
                            <h3>Extensive Inventory</h3>
                            <div class="text">
                                <p>Over 200 tons of steel products in ready stock for fast and reliable delivery across
                                    sectors.</p>
                            </div>
                        </div>
                    </div>

                    <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box wow fadeIn animated" data-wow-delay="100ms" data-wow-duration="1500ms">
                            <div class="icon_box">
                                <span class="fas fa-globe"></span>
                            </div>
                            <h3>Sourcing Capabilities</h3>
                            <div class="text">
                                <p>Backed by a global network to locate and deliver even the hardest-to-find steel
                                    products.</p>
                            </div>
                        </div>
                    </div>

                    <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box wow fadeIn animated" data-wow-delay="200ms" data-wow-duration="1500ms">
                            <div class="icon_box">
                                <span class="fas fa-layer-group"></span>
                            </div>
                            <h3>Wide Range of Materials</h3>
                            <div class="text">
                                <p>Offering stainless steel, duplex, nickel alloys, and more to meet diverse industry
                                    needs.</p>
                            </div>
                        </div>
                    </div>

                    <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box wow fadeIn animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="icon_box">
                                <span class="fas fa-certificate
            "></span>
                            </div>
                            <h3>Certified Quality</h3>
                            <div class="text">
                                <p>All materials comply with ASTM, ASME, ISO, DIN, and other global quality standards.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box wow fadeIn animated" data-wow-delay="400ms" data-wow-duration="1500ms">
                            <div class="icon_box">
                                <span class="fas fa-tags
            "></span>
                            </div>
                            <h3>Competitive Pricing</h3>
                            <div class="text">
                                <p>We deliver cost-effective solutions without compromising on quality or performance.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box wow fadeIn animated" data-wow-delay="500ms" data-wow-duration="1500ms">
                            <div class="icon_box">
                                <span class="fas fa-truck
            "></span>
                            </div>
                            <h3>Reliable Logistics</h3>
                            <div class="text">
                                <p>On-time delivery solutions tailored to meet tight project schedules and deadlines.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="item col-lg-4 col-md-6 col-sm-12 col-xs-12">
                        <div class="inner-box wow fadeIn animated" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="icon_box">
                                <span class="fas fa-headset
            "></span>
                            </div>
                            <h3>Dedicated Support</h3>
                            <div class="text">
                                <p>Get expert technical advice and seamless support from start to finish on every order.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="brand-area sec-padd-top sec-padd-bottom">
            <div class="container">
                <div class="section-title center">
                    <h2>Some of Our Esteemed Clients</h2>
                </div>
                <div class="brand-carousel owl-carousel owl-theme brand">
                    <div class="single-item">
                        <a href="javascript:void(0);">
                            <img src="{{ asset('assets/images/bharat-heavy-electricals-limited.jpg') }}" width="612" height="355"
                                alt="Bharat Heavy Electricals Limited (BHEL)">
                            <p class="company-name">Bharat Heavy Electricals Limited (BHEL)</p>
                        </a>
                    </div>
                    <div class="single-item">
                        <a href="javascript:void(0);">
                            <img src="{{ asset('assets/images/maharashtra-seamless-limited-logo.png') }}" width="1200" height="666"
                                alt="Maharashtra Seamless Limited (MSL)">
                            <p class="company-name">Maharashtra Seamless Limited (MSL)</p>
                        </a>
                    </div>
                    <div class="single-item">
                        <a href="javascript:void(0);">
                            <img src="{{ asset('assets/images/nuclear-power-corporation-of-india-limited.webp') }}" width="449" height="160"
                                alt="Nuclear Power Corporation of India Limited (NPCIL)">
                            <p class="company-name">Nuclear Power Corporation of India Limited (NPCIL)</p>
                        </a>
                    </div>
                    <div class="single-item">
                        <a href="javascript:void(0);">
                            <img src="{{ asset('assets/images/chemdist-process-solutions-logo.jpg') }}" width="674" height="296"
                                alt="Chemdist Process Solutions Private Limited">
                            <p class="company-name">Chemdist Process Solutions Pvt Ltd</p>
                        </a>
                    </div>
                    <div class="single-item">
                        <a href="javascript:void(0);">
                            <img src="{{ asset('assets/images/ssepl-techno-logo.png') }}" width="359" height="185"
                                alt="SSEPL Techno Private Limited">
                            <p class="company-name">SSEPL Techno Private Limited</p>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <section class="subscribe center sec-padd">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12 mx-auto">
                        <h2>Subscribe For Newsletter</h2>
                        <p>Idea of denouncing pleasure praising pain was born and I will give you a complete account
                            <br> of system, expound the great explorer.
                        </p>
                        <form class="subscribe-form">
                            <input type="email" placeholder="Email Address"><span class="fa fa-envelope ms-2"></span>
                            <button type="submit" class="thm-btn bg-clr1">subscribe us</button>
                        </form>
                    </div>
                </div>

            </div>
        </section>


        <!--Start faq content area-->
        <section class="faq-content-area sec-padd2">
            <div class="container">
                <div class="section-title center">
                    <h2>FAQ's</h2>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="accordion-box">
                            <!--Start single accordion box-->
                            <div class="accordion accordion-block">
                                <div class="accord-btn active">
                                    <h3 class="h6">What products does Moksh Tubes & Fittings LLP manufacture and supply?
                                    </h3>
                                </div>
                                <div class="accord-content collapsed">
                                    <p>Moksh Tubes & Fittings LLP manufactures and supplies a wide range of steel products,
                                        including Pipes & Tubes, Pipe Fittings, Flanges, Fasteners, Sheets & Plates, Coils,
                                        Wires, Round Bars, Flat Bars, Angles, Channels, Welding Rods, Wire Mesh, and other
                                        custom and hard-to-find steel products in both ferrous and non-ferrous grades.</p>
                                </div>
                            </div>
                            <!--End single accordion box-->
                            <!--Start single accordion box-->
                            <div class="accordion accordion-block">
                                <div class="accord-btn">
                                    <h3 class="h6">Which industries does Moksh Tubes & Fittings LLP serve?</h3>
                                </div>
                                <div class="accord-content">
                                    <p>We cater to diverse industries such as Oil & Gas, Petrochemicals, Power Generation,
                                        Water Management, Pharmaceuticals, Food & Beverage, Marine, Construction, Sugar
                                        Industries, Boilers & Pressure Vessels, Solar, and Chemical Processing, delivering
                                        high quality materials for critical applications.</p>
                                </div>
                            </div>
                            <!--End single accordion box-->
                            <!--Start single accordion box-->
                            <div class="accordion accordion-block">
                                <div class="accord-btn">
                                    <h3 class="h6">What materials are available at Moksh Tubes & Fittings LLP?
                                    </h3>
                                </div>
                                <div class="accord-content">
                                    <p>Our product range covers Stainless Steel, Duplex & Super Duplex Steel, Nickel Alloys
                                        like Hastelloy, Inconel, and Monel, Titanium Alloys, Copper & Bronze Alloys, Carbon
                                        Steel, and rare alloys including Nimonic, Ferralium, Zirconium, and Tantalum.</p>
                                </div>
                            </div>
                            <!--End single accordion box-->
                            <!--Start single accordion box-->
                            <div class="accordion accordion-block">
                                <div class="accord-btn">
                                    <h3 class="h6">How does Moksh Tubes & Fittings LLP ensure quality standards?
                                    </h3>
                                </div>
                                <div class="accord-content">
                                    <p>All materials we supply comply with international standards such as ASTM, ASME, ISO,
                                        and DIN. We maintain strict quality control procedures and partner with trusted
                                        suppliers to ensure reliable performance and durability in every project.
                                    </p>
                                </div>
                            </div>
                            <!--End single accordion box-->
                            <!--Start single accordion box-->
                            <div class="accordion accordion-block">
                                <div class="accord-btn">
                                    <h3 class="h6">Does Moksh Tubes & Fittings LLP offer global delivery?
                                    </h3>
                                </div>
                                <div class="accord-content">
                                    <p>Yes. With over 20 years of experience and projects completed in over 12 countries, Moksh
                                        Tubes & Fittings LLP has the logistics and sourcing capabilities to deliver steel
                                        products worldwide, ensuring on-time supply for urgent and large-scale orders.</p>
                                </div>
                            </div>
                            <!--End single accordion box-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End faq content area-->







@endsection
    @section('jsscripts')
            <script type="application/ld+json">
            @verbatim {
                    "@context": "https://schema.org"
                    , "@type": "FAQPage"
                    , "mainEntity": [{
                            "@type": "Question"
                            , "name": "What products does Moksh Tubes & Fittings LLP manufacture and supply?"
                            , "acceptedAnswer": {
                                "@type": "Answer"
                                , "text": "Moksh Tubes & Fittings LLP manufactures and supplies a wide range of steel products, including Pipes & Tubes, Pipe Fittings, Flanges, Fasteners, Sheets & Plates, Coils, Wires, Round Bars, Flat Bars, Angles, Channels, Welding Rods, Wire Mesh, and other custom and hard-to-find steel products in both ferrous and non-ferrous grades."
                            }
                        }
                        , {
                            "@type": "Question"
                            , "name": "Which industries does Moksh Tubes & Fittings LLP serve?"
                            , "acceptedAnswer": {
                                "@type": "Answer"
                                , "text": "We cater to diverse industries such as Oil & Gas, Petrochemicals, Power Generation, Water Management, Pharmaceuticals, Food & Beverage, Marine, Construction, Sugar Industries, Boilers & Pressure Vessels, Solar, and Chemical Processing, delivering high quality materials for critical applications."
                            }
                        }
                        , {
                            "@type": "Question"
                            , "name": "What materials are available at Moksh Tubes & Fittings LLP?"
                            , "acceptedAnswer": {
                                "@type": "Answer"
                                , "text": "Our product range covers Stainless Steel, Duplex & Super Duplex Steel, Nickel Alloys like Hastelloy, Inconel, and Monel, Titanium Alloys, Copper & Bronze Alloys, Carbon Steel, and rare alloys including Nimonic, Ferralium, Zirconium, and Tantalum."
                            }
                        }
                        , {
                            "@type": "Question"
                            , "name": "How does Moksh Tubes & Fittings LLP ensure quality standards?"
                            , "acceptedAnswer": {
                                "@type": "Answer"
                                , "text": "All materials we supply comply with international standards such as ASTM, ASME, ISO, and DIN. We maintain strict quality control procedures and partner with trusted suppliers to ensure reliable performance and durability in every project."
                            }
                        }
                        , {
                            "@type": "Question"
                            , "name": "Does Moksh Tubes & Fittings LLP offer global delivery?"
                            , "acceptedAnswer": {
                                "@type": "Answer"
                                , "text": "Yes. With over 20 years of experience and projects completed in over 12 countries, Moksh Tubes & Fittings LLP has the logistics and sourcing capabilities to deliver steel products worldwide, ensuring on-time supply for urgent and large-scale orders."
                            }
                        }
                    ]
                }
            @endverbatim

        </script>
    @endsection
@push('vendor-scripts')
    <!-- Owl carousel, jquery.appear, countTo -->
    <script src="{{ asset('assets/js/counter-carousel.bundle.min.js') }}" defer></script>
@endpush
