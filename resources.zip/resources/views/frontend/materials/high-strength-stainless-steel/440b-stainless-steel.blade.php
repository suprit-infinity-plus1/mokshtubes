@extends('layouts.master')

@section('title', 'Stainless Steel 440B | Precision Bars & Rods Supplier')
@section('meta_description',
    'Premium 440B Stainless Steel bars & rods offering high strength, wear resistance & polish
    finish for industrial, tooling & engineering applications.')
@section('meta_keywords',
    '440B Stainless Steel, UNS S44004, AISI 440B, High Carbon Martensitic Stainless Steel,
    Corrosion Resistant Stainless Steel, High Strength Stainless Steel, Wear Resistant Alloy, Industrial Stainless Steel
    Supplier, Engineering Grade Stainless Steel, Tooling Stainless Steel')
@section('og_image', asset('assets/images/high-strength-stainless-steel/440B-Stainless-Steel.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/high-strength-stainless-steel/440B-Stainless-Steel.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Stainless Steel 440B <br> High-Carbon Martensitic Stainless Steel</h1>
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>

            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                INTRODUCTION TO STAINLESS STEEL 440B / AISI 440B / UNS S44004
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/high-strength-stainless-steel/440B-Stainless-Steel.webp') }}"
                        alt="Hastelloy C276" class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4" style="text-align: justify;">
                            <strong class="text-black">Stainless Steel 440B (UNS S44004)</strong> is a high-carbon
                            martensitic stainless steel offering higher hardness and wear resistance than 440A after heat
                            treatment, while retaining moderate corrosion resistance in mildly corrosive environments. It is
                            fully magnetic and can be hardened by conventional quench-and-temper cycles, making it suitable
                            for blades, wear parts, and precision components.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <a href="{{ route('index') }}"><strong class="text-black">MOKSH TUBES & FITTINGS
                                    LLP</strong></a> is a trusted supplier, exporter, importer, and stockist of stainless
                            440B <a href="{{ route('products') }}">products</a>, including pipes, tubes, fittings, flanges,
                            fasteners, sheets, plates, coils, wires, bars, and custom machined parts, produced to
                            international standards for performance and reliability.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            Compared to lower-carbon grades, <strong class="text-black">440B</strong> delivers excellent
                            edge retention, high surface hardness up to 56–60 HRC when properly heat treated, and good
                            polishability for cutting tool and industrial service applications where both hardness and
                            oxidation resistance are required.
                        </p>

                        <p class="fs-6 mb-4" style="text-align: justify;">
                            For weight-critical designs, note typical <strong>steel density</strong> of 7.85 g/cm³ versus
                            <strong>440B density</strong> 7.65 g/cm³, which can slightly reduce component mass without
                            compromising mechanical performance when properly heat treated and finished.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download High Strength Stainless Steel 440B Datasheet</h3>
            <p class="mb-3">
                Get the complete High Strength Stainless Steel 440B datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

{{-- 
<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>Material Summary – SS 440B / UNS S44003</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Material Type</td>
                                    <td>High-Carbon Martensitic Stainless Steel</td>
                                </tr>
                                <tr class="t-row">
                                    <td>UNS Designation</td>
                                    <td>S44003</td>
                                </tr>
                                <tr class="t-row">
                                    <td>AISI</td>
                                    <td>440B</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium Content</td>
                                    <td>16.0 – 18.0 %</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon Content</td>
                                    <td>0.75 – 0.95 %</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatable</td>
                                    <td>✔ Yes (Quench & Temper)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Maximum Hardness</td>
                                    <td>56 – 60 HRC</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Wear Resistance</td>
                                    <td>Very Good</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Corrosion Resistance</td>
                                    <td>Moderate</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Property</td>
                                    <td>Fully Magnetic</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Density</td>
                                    <td>~7.65 g/cm³</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            👉 The higher carbon content gives SS 440B superior hardness and wear resistance compared to
                            440A, while maintaining reasonable corrosion resistance.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of SS 440B</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>0.75 – 0.95</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese (Mn)</td>
                                    <td>≤ 1.00</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon (Si)</td>
                                    <td>≤ 1.00</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Phosphorus (P)</td>
                                    <td>≤ 0.04</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sulfur (S)</td>
                                    <td>≤ 0.03</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>16.0 – 18.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Molybdenum (Mo)</td>
                                    <td>≤ 0.75</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>Balance</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">Technical Composition of SS 440B</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                     <h3 class="text-center mb-3" style="color: #db7227;">Physical Properties of SS 440B
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Value</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>7.65 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Point</td>
                                    <td>1480 – 1530 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Modulus of Elasticity</td>
                                    <td>200 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Thermal Conductivity</td>
                                    <td>24 W/m·K (100 °C)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Electrical Resistivity</td>
                                    <td>0.60 µΩ·m</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Properties</td>
                                    <td>Fully Magnetic (Martensitic)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Heat Treatment -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color:#db7227;">
                        Heat Treatment & Hardening Cycle – SS 440B
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Process</th>
                                    <th>Temperature Range</th>
                                    <th>Purpose</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Annealing</td>
                                    <td>840 – 900 °C</td>
                                    <td>Improves machinability</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hardening (Austenitizing)</td>
                                    <td>1010 – 1065 °C</td>
                                    <td>Forms martensitic structure</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Quenching</td>
                                    <td>Oil / Air</td>
                                    <td>Achieves high hardness</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Cryogenic Treatment</td>
                                    <td>−70 to −196 °C</td>
                                    <td>Improves wear & dimensional stability</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Tempering</td>
                                    <td>150 – 370 °C</td>
                                    <td>Balances hardness & toughness</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>600 – 650 °C</td>
                                    <td>Reduces internal stresses</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            📌 SS 440B is positioned between 440A and 440C, offering excellent edge retention after precise
                            quench & temper cycles.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties of SS 440B
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Metric</th>
                            <th>Imperial</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>655 – 895 MPa</td>
                            <td>95,000 – 130,000 psi</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>~415 MPa</td>
                            <td>~60,000 psi</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation</td>
                            <td>15 – 20%</td>
                            <td>15 – 20%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Hardness (Annealed)</td>
                            <td>215 – 235 HB</td>
                            <td>215 – 235 HB</td>
                        </tr>
                        <tr class="t-row">
                            <td>Hardness (Hardened)</td>
                            <td colspan="2">56 – 60 HRC</td>
                        </tr>
                    </tbody>
                </table>

                <p class="mt-3 text-center">
                    👉 SS 440B achieves high surface hardness and excellent edge retention, making it ideal for blades and
                    wear-resistant components.
                </p>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5">
                <h2>Available Forms & Size Range – SS 440B</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark text-center">
                            <tr class="t-row">
                                <th>Product Form</th>
                                <th>Typical Size Range</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr class="t-row">
                                <td>Round Bars / Rods</td>
                                <td>Ø6 mm – Ø400 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Flat Bars</td>
                                <td>5 – 100 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Sheets & Plates</td>
                                <td>0.5 – 60 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Coils & Strips</td>
                                <td>0.3 – 5 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Pipes & Tubes</td>
                                <td>OD 6 – 610 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Fasteners</td>
                                <td>M6 – M64</td>
                            </tr>
                            <tr class="t-row">
                                <td>Forged Components</td>
                                <td>As per drawing</td>
                            </tr>
                            <tr class="t-row">
                                <td>Precision Machined Parts</td>
                                <td>CNC / Ground</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section  id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Stainless Steel 440B</h2>
            </div>

            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">MOKSH TUBES & FITTINGS LLP</strong>, with extensive experience in
                        martensitic stainless steels,
                        supplies <strong class="text-dark">Stainless Steel 440B</strong> in a broad range of product forms
                        for industrial, mechanical,
                        and precision applications. Known for its excellent hardness, wear resistance, and moderate
                        corrosion protection,
                        440B serves as a versatile material for engineering and production environments that demand high
                        performance.
                    </p>
                </div>
            </div>

            <!-- Horizontal Styled Product List -->
            <div class="row justify-content-center mb-5">
                <div class="col-lg-10">
                    <div class="p-4 bg-white rounded shadow-sm border-start border-4" style="border-color: #db7227;">
                        <div class="row">
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Seamless Pipes</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Welded Pipes (ERW & EFW)</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Tubes (Capillary, Instrumentation, Heat Exchanger)</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Sheets & Plates</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Coils & Strips</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Round Bars, Flat Bars, Hex Bars, Square Bars</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Pipe Fittings (Elbows, Tees, Reducers, Caps, Stub Ends)</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Flanges (Weld Neck, Slip-On, Blind, Socket Weld, Threaded)</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Fasteners (Bolts, Nuts, Screws, Washers, Studs)</span>
                            </div>
                            <div class="col-12 col-sm-6 mb-2 d-flex align-items-start">
                                <span class="me-2" style="color: #db7227; font-size: 1.1rem;">&#10004;</span>
                                <span>Precision Machined & Heat-Treated Components</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Standards Section -->
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <p class="fw-bold fs-6 text-center my-4" style="color: #174268;">
                        All products comply with international standards such as <strong>ASTM A276 / A314 / A580</strong>
                        to ensure top-quality material performance and dimensional accuracy.
                    </p>
                </div>
            </div>
        </div>
    </section>

<section  id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages of 440B stainless steel</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gem"></i></div>
                        <h5>High Surface Hardness</h5>
                        <p>Achieves superior surface hardness after precise heat treatment, making it ideal for
                            wear-intensive applications.</p>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Good Corrosion Resistance</h5>
                        <p>Performs reliably in mild corrosive environments such as air, freshwater, and lightly acidic
                            conditions.</p>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-magnet"></i></div>
                        <h5>Fully Magnetic Ferritic Structure</h5>
                        <p>Maintains strong magnetic properties in both annealed and heat-treated conditions, suitable for
                            specialized engineering uses.</p>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-tools"></i></div>
                        <h5>Excellent Wear Resistance</h5>
                        <p>Offers high edge retention and superior wear resistance, essential for cutting tools and
                            precision components.</p>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Heat-Treatable for Strength</h5>
                        <p>Can be heat treated to achieve exceptional hardness, strength, and performance in high-stress
                            conditions.</p>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Easy to Machine and Polish</h5>
                        <p>Suitable for machining, grinding, and polishing operations, ensuring precision and enhanced
                            surface finish.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Stainless Steel 440B</h2>
                <p class="text-center pb-3">
                    <strong class="text-dark">Stainless Steel 440B</strong> is valued for its hardness, wear resistance,
                    and moderate corrosion protection, making it an excellent choice across various demanding industries.
                </p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>Stainless Steel 440B Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹380 – ₹880 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ’s – 440B Stainless Steel</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is 440B Stainless Steel?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    440B is a high-carbon martensitic stainless steel offering high hardness, strength, and corrosion resistance, ideal for precision tools.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are its key properties?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Excellent wear resistance, high hardness after heat treatment, good polishability, and moderate corrosion resistance.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Where is it used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Knife blades, surgical instruments, bearings, cutting tools, and wear-resistant components.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Is it weldable?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Welding is possible but requires preheating and post-weld heat treatment to maintain properties.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose Mokshtubes?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Mokshtubes supplies premium-grade 440B stainless steel with precise quality, reliable delivery, and competitive pricing.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us"  class="sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    For inquiries or to request a quote, reach out to <strong>Moksh Tubes & Fittings LLP</strong> – your
                    trusted partner for <strong>Stainless Steel 440B</strong> products.
                </p>

                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades – SS 440B</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>S44003</td>
                        </tr>
                        <tr class="t-row">
                            <td>AISI</td>
                            <td>440B</td>
                        </tr>
                        <tr class="t-row">
                            <td>EN</td>
                            <td>1.4122</td>
                        </tr>
                        <tr class="t-row">
                            <td>DIN</td>
                            <td>X90CrMoV18</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>A276, A314, A580</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS</td>
                            <td>SUS 440B</td>
                        </tr>
                        <tr class="t-row">
                            <td>ISO</td>
                            <td>X90CrMoV18</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <!-- FAQ Schema Markup -->
    <script type="application/ld+json">
    @verbatim
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is 440B Stainless Steel?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "440B is a high-carbon martensitic stainless steel offering high hardness, strength, and corrosion resistance, ideal for precision tools."
      }
    },
    {
      "@type": "Question",
      "name": "What are its key properties?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Excellent wear resistance, high hardness after heat treatment, good polishability, and moderate corrosion resistance."
      }
    },
    {
      "@type": "Question",
      "name": "Where is it used?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Knife blades, surgical instruments, bearings, cutting tools, and wear-resistant components."
      }
    },
    {
      "@type": "Question",
      "name": "Is it weldable?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Welding is possible but requires preheating and post-weld heat treatment to maintain properties."
      }
    },
    {
      "@type": "Question",
      "name": "Why choose Mokshtubes?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Mokshtubes supplies premium-grade 440B stainless steel with precise quality, reliable delivery, and competitive pricing."
      }
    }
  ]
}
@endverbatim
</script>
@endsection



