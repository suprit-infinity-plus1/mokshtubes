@extends('layouts.master')

@section('title', 'Copper Nickel Cu-Ni 70/30 | Seawater & Marine Alloy')

@section('meta_description',
    'Copper Nickel Alloy 70/30 (Cu-Ni) offers superior corrosion resistance, strength, and
    durability in seawater and harsh marine environments.')

@section('meta_keywords',
    'Copper Nickel 70/30, Cu-Ni 70/30 Alloy, Copper Nickel Marine Alloy, Seawater Resistant Copper
    Nickel, Corrosion Resistant Cu-Ni 70/30, Durable Copper Nickel, Industrial Copper Nickel Alloy')
@section('og_image', asset('assets/images/copper-alloys/copper-alloys-cu-ni-70_30.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/copper-alloys/copper-alloys-cu-ni-70_30.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Copper Nickel Alloy 70/30 (Cu-Ni) <br> Marine Grade</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        Copper Nickel Alloy 70/30 (Cu-Ni) is a premium marine-grade alloy known for its exceptional
                        resistance to seawater corrosion, erosion, and biofouling. It offers high strength, excellent
                        thermal conductivity, and long-term durability, making it ideal for shipbuilding, heat exchangers,
                        condensers, offshore structures, and other demanding marine and coastal applications.

                    </p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Copper Nickel Alloy 70/30 (Cu-Ni) | Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Copper Alloys CU-NI 70/30 / UNS C71500 / CW354H
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/copper-alloys/copper-alloys-cu-ni-70_30.webp') }}"alt="Copper Alloys CU-NI 70/30"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> is a leading manufacturer,
                            supplier, exporter, importer, and stockist of<strong class="text-black"> Copper Nickel 70/30
                                (UNS C71500 / CW354H)
                                <a href="{{ route('products') }}">products</a></strong>. We offer a complete range including
                            Seamless & Welded Pipes and Tubes, Sheets & Plates, Rods, Bars, Pipe Fittings, Flanges, Wires,
                            Fasteners, and Custom Machined Components.

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black"><a href="{{ route('materials.copper-Alloys') }}">Copper Alloys
                                    CU-NI 70/30</a></strong>, is a stronger and more corrosion-resistant copper-nickel alloy
                            than 90/10. It is well suited for highly corrosive environments, including high-velocity
                            seawater and industrial chemical exposure. With enhanced mechanical strength, excellent
                            weldability, and strong resistance to biofouling, erosion, and hydrogen embrittlement, CU-NI
                            70/30 is widely used in demanding marine, offshore, and thermal applications.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Copper Alloys Cu Ni 70 30 Datasheet</h3>
            <p class="mb-3">
                Get the complete Copper Alloys Cu Ni 70 30 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>Technical Specifications – Copper Nickel 70/30 (UNS C71500 / EN CW354H)</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                         <tr class="t-row">
                            <th>Category</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr class="t-row">
                            <td>Material</td>
                            <td>Copper Nickel 70/30</td>
                        </tr>
                         <tr class="t-row">
                            <td>UNS No.</td>
                            <td>C71500</td>
                        </tr>
                         <tr class="t-row">
                            <td>EN / DIN</td>
                            <td>CW354H / 2.0882</td>
                        </tr>
                         <tr class="t-row">
                            <td>ISO Designation</td>
                            <td>CuNi30Fe1Mn</td>
                        </tr>
                         <tr class="t-row">
                            <td>Copper Content</td>
                            <td>65.5 – 69.5 %</td>
                        </tr>
                         <tr class="t-row">
                            <td>Nickel Content</td>
                            <td>29 – 33 %</td>
                        </tr>
                         <tr class="t-row">
                            <td>Iron Content</td>
                            <td>0.4 – 1.0 %</td>
                        </tr>
                         <tr class="t-row">
                            <td>Magnetic Properties</td>
                            <td>Non-Magnetic</td>
                        </tr>
                         <tr class="t-row">
                            <td>Heat Treatable</td>
                            <td>❌ No</td>
                        </tr>
                         <tr class="t-row">
                            <td>Strength Control</td>
                            <td>Cold Working</td>
                        </tr>
                         <tr class="t-row">
                            <td>Weldability</td>
                            <td>Excellent</td>
                        </tr>
                         <tr class="t-row">
                            <td>Seawater Resistance</td>
                            <td>Outstanding (High-Velocity)</td>
                        </tr>
                         <tr class="t-row">
                            <td>Erosion / Cavitation</td>
                            <td>Excellent</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom" id="composition">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition – Copper Nickel 70/30 (C71500)</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle text-center">
                    <thead class="table-dark">
                         <tr class="t-row">
                            <th>Element</th>
                            <th>Composition (% by weight)</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr class="t-row">
                            <td>Copper (Cu)</td>
                            <td>Balance (approx. 65.5 – 69.5)</td>
                        </tr>
                         <tr class="t-row">
                            <td>Nickel (Ni)</td>
                            <td>29.0 – 33.0</td>
                        </tr>
                         <tr class="t-row">
                            <td>Iron (Fe)</td>
                            <td>0.4 – 1.0</td>
                        </tr>
                         <tr class="t-row">
                            <td>Manganese (Mn)</td>
                            <td>1.0 max</td>
                        </tr>
                         <tr class="t-row">
                            <td>Zinc (Zn)</td>
                            <td>1.0 max</td>
                        </tr>
                         <tr class="t-row">
                            <td>Lead (Pb)</td>
                            <td>0.05 max</td>
                        </tr>
                         <tr class="t-row">
                            <td>Other Impurities</td>
                            <td>≤ 0.50 (Total)</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="properties">
        <div class="container">
            <div class="section-title center">
                <h2>Physical Properties – Copper Nickel 70/30</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle text-center">
                    <thead class="table-dark">
                         <tr class="t-row">
                            <th>Property</th>
                            <th>Imperial Units</th>
                            <th>Metric Units</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr class="t-row">
                            <td>Density</td>
                            <td>0.323 lb/in³</td>
                            <td>8.94 g/cm³</td>
                        </tr>
                         <tr class="t-row">
                            <td>Melting Range</td>
                            <td>2260 – 2390 °F</td>
                            <td>1240 – 1310 °C</td>
                        </tr>
                         <tr class="t-row">
                            <td>Thermal Conductivity</td>
                            <td>19 Btu/ft·hr·°F</td>
                            <td>33 W/m·K</td>
                        </tr>
                         <tr class="t-row">
                            <td>Electrical Resistivity</td>
                            <td>312 ohm·cmil/ft</td>
                            <td>0.520 µΩ·m</td>
                        </tr>
                         <tr class="t-row">
                            <td>Specific Heat Capacity</td>
                            <td>0.09 Btu/lb·°F</td>
                            <td>0.38 J/g·K</td>
                        </tr>
                         <tr class="t-row">
                            <td>Coefficient of Expansion</td>
                            <td>9.8 × 10⁻⁶ /°F</td>
                            <td>17.6 × 10⁻⁶ /°C</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center">
                <h2>Mechanical Properties – Copper Nickel 70/30</h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle text-center">
                    <thead class="table-dark">
                         <tr class="t-row">
                            <th>Property / Condition</th>
                            <th>Annealed / Type O</th>
                            <th>Cold-Drawn (Stress-Relieved)</th>
                            <th>Hot-Rolled / Sheet</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>360 MPa (52 ksi) min</td>
                            <td>495 MPa (~72 ksi)</td>
                            <td>372 – 517 MPa (54 – 75 ksi)</td>
                        </tr>
                         <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>125 MPa (18 ksi) min</td>
                            <td>345 MPa (~50 ksi)</td>
                            <td>125 – 300 MPa (18 – 43 ksi)</td>
                        </tr>
                         <tr class="t-row">
                            <td>Elongation (%)</td>
                            <td>≥ 30 %</td>
                            <td>12 – 15 %</td>
                            <td>30 – 45 %</td>
                        </tr>
                         <tr class="t-row">
                            <td>Brinell Hardness</td>
                            <td>—</td>
                            <td>—</td>
                            <td>80 – 120 HB</td>
                        </tr>
                         <tr class="t-row">
                            <td>Rockwell Hardness (B)</td>
                            <td>—</td>
                            <td>≤ 88 B</td>
                            <td>~81 B</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center">
                <h2>Available Forms & Size Range – Copper Nickel 70/30</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle text-center">
                    <thead class="table-dark">
                         <tr class="t-row">
                            <th>Product Form</th>
                            <th>Size Range</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr class="t-row">
                            <td>Pipes & Tubes</td>
                            <td>OD 6 – 450 mm, WT 0.7 – 35 mm</td>
                        </tr>
                         <tr class="t-row">
                            <td>Sheets & Plates</td>
                            <td>Thickness 0.5 – 80 mm</td>
                        </tr>
                         <tr class="t-row">
                            <td>Coils & Strips</td>
                            <td>0.1 – 6 mm</td>
                        </tr>
                         <tr class="t-row">
                            <td>Rods & Bars</td>
                            <td>Ø 6 – 350 mm</td>
                        </tr>
                         <tr class="t-row">
                            <td>Fittings & Flanges</td>
                            <td>ASME / DIN Standards</td>
                        </tr>
                         <tr class="t-row">
                            <td>Forged Components</td>
                            <td>As per drawing</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Copper Alloys CU-NI 70/30</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Copper Alloys CU-NI 70/30</strong> is available in:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Copper Alloys CU-NI 70/30 products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Highly resistant to pitting, crevice corrosion, and biofouling in both stagnant and flowing
                            seawater.</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Stronger than CU-NI 90/10, suited for demanding structural and pressure-bearing applications.
                        </h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Performs reliably in thermal cycling and exposure to acids, salts, and ammonia.</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Suitable for all standard welding methods with minimal pre/post-heat requirements.</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Ideal for installations in remote or offshore environments with limited access.</h5>
                    </div>
                </div>
            </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Copper Alloys CU-NI 70/30</h2>
                <p class="text-center pb-3"><strong class="text-dark">Copper Alloys CU-NI 70/30</strong> is widely used in
                    highly corrosive and high-stress applications in marine and industrial sectors:</p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>COPPER NICKEL 70/30 PRICE PER KG (INDIA)</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹2,200 – ₹4,200 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is Copper Nickel 70/30 and how is it different from 90/10?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Copper Nickel 70/30, also known as UNS C71500 or CW354H, is a copper alloy containing
                                    about 70% copper
                                    and 30% nickel with small additions of iron and manganese. Compared to Copper Nickel
                                    90/10, the 70/30
                                    grade offers greater mechanical strength, improved corrosion resistance, and excellent
                                    durability in
                                    highly aggressive environments such as fast-flowing seawater and chemical processing
                                    systems.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the main benefits of using Copper Nickel 70/30 alloy?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    The key benefits of Copper Nickel 70/30 include outstanding resistance to pitting,
                                    crevice corrosion,
                                    biofouling, and stress cracking in both stagnant and turbulent seawater. It is stronger
                                    than CU-NI 90/10,
                                    performs reliably under thermal cycling, and is resistant to acidic and saline
                                    environments. Additionally,
                                    it has excellent weldability with minimal pre or post-heat treatment requirements,
                                    making it a reliable
                                    choice for marine and offshore installations.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Where is Copper Nickel 70/30 commonly used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Copper Nickel 70/30 is widely used in marine and shipbuilding industries for seawater
                                    piping, condenser
                                    plates, valves, and propeller sleeves. It is a preferred material in power plants for
                                    feedwater heaters,
                                    condensers, and cooling water lines, in desalination plants for brine heaters and
                                    evaporator shells, and
                                    in offshore oil and gas for firewater systems, risers, and deck piping. Defense and
                                    naval sectors also use
                                    it extensively for submarine systems and hull-mounted components due to its long term
                                    performance in harsh
                                    environments.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What Copper Nickel 70/30 products are supplied by MOKSH TUBES & FITTINGS LLP?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP offers a comprehensive range of Copper Nickel 70/30 products
                                    including seamless
                                    and welded pipes and tubes, sheets, plates, coils, strips, round bars, flats, hex bars,
                                    pipe fittings,
                                    flanges, fasteners, wires, and custom machined components. All materials are produced in
                                    compliance with
                                    international standards and can be customized in terms of size, thickness, and finish to
                                    meet specific
                                    project requirements.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for Copper Nickel 70/30 materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, supplier, and exporter of Copper
                                    Nickel 70/30 with
                                    extensive industry experience. The company provides marine-grade certified products from
                                    reputed mills,
                                    an extensive stock range, cut-to-size services, and global logistics support. With
                                    expertise in serving
                                    shipyards, EPC contractors, power plants, refineries, and defense projects, the company
                                    ensures high-quality
                                    CU-NI 70/30 products with full traceability and reliable performance.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    contact <strong>Moksh Tubes & Fittings LLP</strong> — your dependable source for
                    corrosion-resistant Cu-Ni alloys.
                    <!-- Call button -->
                    <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                        data-bs-target="#contactFormModal">
                        Get in Touch
                    </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="heat-treatment">
        <div class="container">
            <div class="section-title center">
                <h2>Heat Treatment & Fabrication – Copper Nickel 70/30</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle text-center">
                    <thead class="table-dark">
                         <tr class="t-row">
                            <th>Process</th>
                            <th>Temperature Range</th>
                            <th>Purpose</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr class="t-row">
                            <td>Annealing</td>
                            <td>700 – 900 °C</td>
                            <td>Restores ductility</td>
                        </tr>
                         <tr class="t-row">
                            <td>Stress Relieving</td>
                            <td>300 – 350 °C</td>
                            <td>Removes residual stress</td>
                        </tr>
                         <tr class="t-row">
                            <td>Cold Working</td>
                            <td>—</td>
                            <td>Improves strength</td>
                        </tr>
                         <tr class="t-row">
                            <td>Welding</td>
                            <td>TIG / MIG / SMAW</td>
                            <td>Excellent weldability</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades – Copper Nickel 70/30</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle text-center">
                    <thead class="table-dark">
                         <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr class="t-row">
                            <td>UNS</td>
                            <td>C71500</td>
                        </tr>
                         <tr class="t-row">
                            <td>EN</td>
                            <td>CW354H</td>
                        </tr>
                         <tr class="t-row">
                            <td>DIN</td>
                            <td>2.0882</td>
                        </tr>
                         <tr class="t-row">
                            <td>ISO</td>
                            <td>CuNi30Fe1Mn</td>
                        </tr>
                         <tr class="t-row">
                            <td>ASTM</td>
                            <td>B111, B122, B466, B467</td>
                        </tr>
                         <tr class="t-row">
                            <td>BS</td>
                            <td>CN108</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
    @verbatim
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is Copper Nickel 70/30 and how is it different from 90/10?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Copper Nickel 70/30, also known as UNS C71500 or CW354H, is a copper alloy containing about 70% copper and 30% nickel with small additions of iron and manganese. Compared to Copper Nickel 90/10, the 70/30 grade offers greater mechanical strength, improved corrosion resistance, and excellent durability in highly aggressive environments such as fast-flowing seawater and chemical processing systems."
      }
    },
    {
      "@type": "Question",
      "name": "What are the main benefits of using Copper Nickel 70/30 alloy?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The key benefits of Copper Nickel 70/30 include outstanding resistance to pitting, crevice corrosion, biofouling, and stress cracking in both stagnant and turbulent seawater. It is stronger than CU-NI 90/10, performs reliably under thermal cycling, and is resistant to acidic and saline environments. It also offers excellent weldability with minimal pre or post-heat treatment requirements, making it ideal for marine and offshore installations."
      }
    },
    {
      "@type": "Question",
      "name": "Where is Copper Nickel 70/30 commonly used?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Copper Nickel 70/30 is widely used in marine and shipbuilding industries for seawater piping, condenser plates, valves, and propeller sleeves. It is a preferred material in power plants, desalination plants, and offshore oil and gas facilities. The alloy is also used in defense and naval sectors for submarine systems and hull-mounted components due to its long-term durability in harsh environments."
      }
    },
    {
      "@type": "Question",
      "name": "What Copper Nickel 70/30 products are supplied by MOKSH TUBES & FITTINGS LLP?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "MOKSH TUBES & FITTINGS LLP supplies seamless and welded pipes and tubes, sheets, plates, coils, strips, round bars, flats, hex bars, pipe fittings, flanges, fasteners, wires, and custom machined components made from Copper Nickel 70/30. All materials comply with international standards and can be customized in size, thickness, and finish as per project requirements."
      }
    },
    {
      "@type": "Question",
      "name": "Why choose MOKSH TUBES & FITTINGS LLP for Copper Nickel 70/30 materials?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, supplier, and exporter of Copper Nickel 70/30 products with extensive experience serving marine, offshore, and industrial projects. The company offers certified materials, large inventories, cut-to-size services, and global logistics support, ensuring reliable quality, traceability, and performance for every order."
      }
    }
  ]
}
@endverbatim
</script>
@endsection


