@extends('layouts.master')
@section('title', 'Aluminium Bronze Alloy | High Strength & Corrosion Resistant')
@section('meta_description',
    'Aluminium Bronze – high-strength copper alloy offering exceptional corrosion resistance
    for marine, chemical, and heavy industrial applications.')
@section('meta_keywords',
    'Aluminium Bronze, copper alloy, high strength copper, corrosion resistant alloy, marine
    copper alloy, industrial copper alloy')
@section('og_image', asset('assets/images/copper-alloys/copper alloys aluminium bronze.webp'))
@section('og_type', 'article')

@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/copper-alloys/copper alloys aluminium bronze.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Aluminium Bronze <br> High Strength Corrosion Alloy</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        Aluminium Bronze is a high-strength copper alloy containing aluminium (5–12%) along with iron,
                        nickel, and manganese for enhanced corrosion resistance and wear performance. These alloys deliver
                        exceptional mechanical strength, excellent seawater resistance, and superior anti-galling
                        properties—making them ideal for marine, offshore, defense, and heavy engineering applications.

                    </p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Copper Alloys C44300 | Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Aluminium Bronze (C95400 / C95500 / C95800)
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/copper-alloys/copper alloys aluminium bronze.webp') }}"alt="Aluminium Bronze"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> is a trusted manufacturer,
                            stockist, and global supplier of high-quality<strong class="text-black"> Aluminium Bronze
                                products</strong>. This family of
                            copper-based alloys with <a href="{{ route('materials.aluminium-Alloys') }}">aluminium</a> as
                            the primary alloying element offers outstanding strength,
                            wear resistance, and corrosion resistance in marine and industrial environments.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black"><a href="{{ route('materials.copper-Alloys') }}">Aluminium
                                    Bronze</a></strong>, typically contains 5% to 12% aluminium,
                            along with iron, nickel, and manganese for enhanced mechanical and anti-corrosive properties. It
                            is the material of choice for demanding applications involving seawater, chemical exposure, and
                            heavy-duty loads.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Copper Alloys Aluminium Bronze Datasheet</h3>
            <p class="mb-3">
                Get the complete Copper Alloys Aluminium Bronze datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>Aluminium Bronze Specifications (C95400 / C95500 / C95800)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-9">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grades</td>
                                    <td>C95400, C95500, C95800, BS 1400 AB1 / AB2</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Material Type</td>
                                    <td>High-Strength Copper–Aluminium Alloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Composition Range</td>
                                    <td>Cu 77–83%, Al 8.5–11.5%, Fe 3–5%, Ni 0–5.5%, Mn ≤ 1.5%</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Standards</td>
                                    <td>ASTM B148, B150, B505, B271; BS 1400 AB1 / AB2</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>As-Cast, Hot Rolled, Cold Drawn, Heat Treated / Aged</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Annealing, Stress Relieving, Aging</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing Offered</td>
                                    <td>Chemical, Mechanical, Hardness, IGC, UT (on request)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2 MTC</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition – Aluminium Bronze</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Element</th>
                            <th>C95400 (%)</th>
                            <th>C95500 (%)</th>
                            <th>C95800 (%)</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Copper (Cu)</td>
                            <td>83.0</td>
                            <td>79.0</td>
                            <td>77.0</td>
                        </tr>
                        <tr class="t-row">
                            <td>Aluminium (Al)</td>
                            <td>10.5 – 11.5</td>
                            <td>10.0 – 11.5</td>
                            <td>8.5 – 9.5</td>
                        </tr>
                        <tr class="t-row">
                            <td>Iron (Fe)</td>
                            <td>3.0 max</td>
                            <td>3.5 – 5.0</td>
                            <td>4.0 – 5.0</td>
                        </tr>
                        <tr class="t-row">
                            <td>Nickel (Ni)</td>
                            <td>—</td>
                            <td>4.5 – 5.5</td>
                            <td>4.5 – 5.5</td>
                        </tr>
                        <tr class="t-row">
                            <td>Manganese (Mn)</td>
                            <td>0.5 max</td>
                            <td>1.5 max</td>
                            <td>1.5 max</td>
                        </tr>
                        <tr class="t-row">
                            <td>Other Elements</td>
                            <td>1.5 max</td>
                            <td>1.5 max</td>
                            <td>1.5 max</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-4">
                <h2 class="fw-bold" style="color:#174268;">Physical Properties of Aluminium Bronze</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Density</td>
                            <td>7.6 – 7.8 g/cm³</td>
                        </tr>
                        <tr class="t-row">
                            <td>Melting Point</td>
                            <td>~1030 – 1045 °C</td>
                        </tr>
                        <tr class="t-row">
                            <td>Thermal Conductivity</td>
                            <td>40 – 60 W/m·K</td>
                        </tr>
                        <tr class="t-row">
                            <td>Electrical Conductivity</td>
                            <td>7 – 12% IACS</td>
                        </tr>
                        <tr class="t-row">
                            <td>Magnetic Properties</td>
                            <td>Non-Magnetic</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-4">
                <h2 class="fw-bold" style="color:#174268;">Mechanical Properties – Aluminium Bronze</h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Annealed</th>
                            <th>Cold-Drawn</th>
                            <th>As-Cast</th>
                            <th>Heat Treated</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>480–620 MPa</td>
                            <td>760–1030 MPa</td>
                            <td>380–480 MPa</td>
                            <td>830–1100 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>170–310 MPa</td>
                            <td>480–760 MPa</td>
                            <td>140–275 MPa</td>
                            <td>760–965 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation</td>
                            <td>30–50%</td>
                            <td>10–20%</td>
                            <td>10–30%</td>
                            <td>5–15%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Brinell Hardness</td>
                            <td>150–230 HB</td>
                            <td>230–300 HB</td>
                            <td>120–180 HB</td>
                            <td>250–320 HB</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Available Forms & Size Range – Aluminium Bronze</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Product Form</th>
                            <th>Size Range / Description</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Round Bars / Rods</td>
                            <td>10 mm – 400 mm diameter</td>
                        </tr>
                        <tr class="t-row">
                            <td>Flats, Squares & Hex Bars</td>
                            <td>Custom sizes up to 300 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Sheets & Plates</td>
                            <td>2 – 150 mm (Width 600 – 3000 mm)</td>
                        </tr>
                        <tr class="t-row">
                            <td>Pipes (Seamless / Welded)</td>
                            <td>OD 12 – 200 mm, WT 2 – 20 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Bushings & Bearings</td>
                            <td>Custom OD / ID</td>
                        </tr>
                        <tr class="t-row">
                            <td>Rings, Discs & Forgings</td>
                            <td>As per specification</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Aluminium Bronze</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Aluminium Bronze</strong> is available in:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Aluminium Bronze products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Exceptional corrosion resistance (esp. in seawater)</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>High strength and hardness</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Non-sparking and anti-galling</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Excellent wear and erosion resistance</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Good weldability and castability</h5>
                    </div>
                </div>
            </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Aluminium Bronze</h2>
                <p class="text-center pb-3"><strong class="text-dark">Aluminium Bronze</strong> is extensively used in
                    highly corrosive and high-load environments:</p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>Aluminium Bronze Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹650 – ₹1,100 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    What is Aluminium Bronze and why is it used?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Aluminium Bronze is a family of copper-based alloys containing 5–12% aluminium, along
                                    with iron, nickel, and manganese. It is widely used because of its high strength, wear
                                    resistance, and exceptional corrosion resistance in seawater and industrial
                                    environments.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    How does Aluminium Bronze compare to other copper alloys or stainless steel?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Compared to traditional copper alloys, Aluminium Bronze offers superior hardness,
                                    tensile strength, and resistance to erosion and galling. Unlike stainless steels, it is
                                    non magnetic, non sparking, and performs exceptionally well in marine and offshore
                                    environments.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    What are the common applications of Aluminium Bronze?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Aluminium Bronze is extensively used in marine, oil & gas, defense, aerospace, power
                                    generation, general engineering, and chemical industries. Typical applications include
                                    propeller shafts, pump casings, valves, heat exchangers, turbine parts, non sparking
                                    tools, bearings, and gears.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    What Aluminium Bronze products does MOKSH TUBES & FITTINGS LLP supply?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    We supply a wide range of Aluminium Bronze products including seamless & welded pipes,
                                    tubes, sheets, plates, coils, bars, pipe fittings, flanges, fasteners, and
                                    custom-fabricated components, all produced in compliance with ASTM, EN, BS, and ISO
                                    standards.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    Why choose MOKSH TUBES & FITTINGS LLP for Aluminium Bronze products?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, stockist, and global supplier
                                    offering large inventory, precision machining, customized solutions, competitive
                                    pricing, and timely delivery. With expertise in Aluminium Bronze, we provide reliable
                                    materials for marine, industrial, and high performance applications.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    contact <strong>Moksh Tubes & Fittings LLP</strong> — Your trusted partner for
                    high-performance copper alloys and engineered metal solutions.
                    <!-- Call button -->
                    <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                        data-bs-target="#contactFormModal">
                        Get in Touch
                    </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Heat Treatment of Aluminium Bronze</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Process</th>
                            <th>Temperature Range</th>
                            <th>Cooling / Procedure</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Annealing</td>
                            <td>650 – 750°C</td>
                            <td>Furnace cool slowly</td>
                        </tr>
                        <tr class="t-row">
                            <td>Stress Relieving</td>
                            <td>250 – 350°C</td>
                            <td>Air cool</td>
                        </tr>
                        <tr class="t-row">
                            <td>Solution Treatment</td>
                            <td>780 – 870°C</td>
                            <td>Water or oil quench</td>
                        </tr>
                        <tr class="t-row">
                            <td>Age Hardening</td>
                            <td>450 – 550°C</td>
                            <td>Air cool (increases strength)</td>
                        </tr>
                    </tbody>
                </table>

                <p class="mt-3 text-center">
                    📌 Heat treatment varies by grade and desired mechanical properties.
                </p>
            </div>
        </div>
    </section>
--}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>C95400 / C95500 / C95800</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>B148, B150, B505, B271</td>
                        </tr>
                        <tr class="t-row">
                            <td>BS</td>
                            <td>AB1, AB2</td>
                        </tr>
                        <tr class="t-row">
                            <td>ISO / EN</td>
                            <td>CuAl10Fe5Ni5 (approx.)</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS</td>
                            <td>CAC703, CAC704 (approx.)</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
    @verbatim
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is Aluminium Bronze and why is it used?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Aluminium Bronze is a family of copper-based alloys containing 5–12% aluminium, along with iron, nickel, and manganese. It is widely used because of its high strength, wear resistance, and exceptional corrosion resistance in seawater and industrial environments."
      }
    },
    {
      "@type": "Question",
      "name": "How does Aluminium Bronze compare to other copper alloys or stainless steel?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Compared to traditional copper alloys, Aluminium Bronze offers superior hardness, tensile strength, and resistance to erosion and galling. Unlike stainless steels, it is non-magnetic, non-sparking, and performs exceptionally well in marine and offshore environments."
      }
    },
    {
      "@type": "Question",
      "name": "What are the common applications of Aluminium Bronze?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Aluminium Bronze is extensively used in marine, oil & gas, defense, aerospace, power generation, general engineering, and chemical industries. Typical applications include propeller shafts, pump casings, valves, heat exchangers, turbine parts, non-sparking tools, bearings, and gears."
      }
    },
    {
      "@type": "Question",
      "name": "What Aluminium Bronze products does MOKSH TUBES & FITTINGS LLP supply?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We supply a wide range of Aluminium Bronze products including seamless and welded pipes, tubes, sheets, plates, coils, bars, pipe fittings, flanges, fasteners, and custom-fabricated components, all produced in compliance with ASTM, EN, BS, and ISO standards."
      }
    },
    {
      "@type": "Question",
      "name": "Why choose MOKSH TUBES & FITTINGS LLP for Aluminium Bronze products?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, stockist, and global supplier offering large inventory, precision machining, customized solutions, competitive pricing, and timely delivery. With expertise in Aluminium Bronze, we provide reliable materials for marine, industrial, and high-performance applications."
      }
    }
  ]
}
@endverbatim
</script>
@endsection


