@extends('layouts.master')
@section('title', 'Beryllium Copper Alloy | High Conductivity & Durability')
@section('meta_description',
    'BBeryllium Copper – premium alloy with superior electrical conductivity, exceptional
    strength, and wear resistance for industrial applications')
@section('meta_keywords',
    'Beryllium Copper, high conductivity copper alloy, durable copper alloy, wear resistant
    copper, electrical copper alloy, industrial copper alloy')
@section('og_image', asset('assets/images/copper-alloys/copper-alloys-beryllium-copper.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/copper-alloys/copper-alloys-beryllium-copper.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Beryllium Copper <br> High Conductivity & Durable Alloy</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        Beryllium Copper is a high-strength copper alloy that combines excellent electrical and thermal
                        conductivity with outstanding durability. It offers superior resistance to wear, fatigue, and
                        corrosion, making it ideal for demanding applications such as electrical components, springs,
                        precision tools, and aerospace parts where reliability and long service life are essential.

                    </p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Copper Alloys C44300 | Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Beryllium Copper / UNS C17200 / ALLOY 25
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/copper-alloys/copper-alloys-beryllium-copper.webp') }}"alt="Beryllium Copper"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> is a reliable manufacturer,
                            exporter, importer, and stockist of high-quality<strong class="text-black"> Beryllium Copper <a
                                    href="{{ route('products') }}">products</a></strong>. We offer a wide
                            range of forms, including <a href="{{ route('products.pipes-tubes') }}">Pipes & Tubes</a>,
                            Sheets & Plates, Coils, Rods, Bars, Wire, Foil,
                            Forgings, and Custom Components tailored to industrial needs.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black"><a href="{{ route('materials.copper-Alloys') }}">Beryllium
                                    Copper</a></strong>, also known as<strong class="text-black"> Copper Beryllium</strong>,
                            is a high-performance alloy known
                            for its remarkable combination of strength, conductivity, and corrosion resistance. This
                            non-ferrous alloy contains 0.4% to 2% beryllium and is often used where non-sparking,
                            non-magnetic, and high-strength materials are required. It can be heat-treated for enhanced
                            mechanical properties and performs excellently in electrical, aerospace, marine, and oil & gas
                            environments.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Copper Alloys Beryllium Coppar Datasheet</h3>
            <p class="mb-3">
                Get the complete Copper Alloys Beryllium Coppar datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>Specifications of Beryllium Copper (UNS R60702)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>Beryllium Copper / UNS R60702</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>Commercially Pure Beryllium</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Standards</td>
                                    <td>ASTM B551, B523, B658, B493, B550</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Forms</td>
                                    <td>Pipes, Tubes, Sheets, Plates, Rods, Wire, Fittings, Flanges, Fasteners</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Chemical Analysis, PMI, Tensile, Hardness</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of Beryllium Copper C17200</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Element</th>
                            <th>Composition (%)</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Beryllium (Be)</td>
                            <td>1.80 – 2.00</td>
                        </tr>
                        <tr class="t-row">
                            <td>Cobalt + Nickel (Co + Ni)</td>
                            <td>0.20 – 0.50</td>
                        </tr>
                        <tr class="t-row">
                            <td>Copper (Cu)</td>
                            <td>Balance</td>
                        </tr>
                        <tr class="t-row">
                            <td>Iron (Fe)</td>
                            <td>0.15 max</td>
                        </tr>
                        <tr class="t-row">
                            <td>Lead (Pb)</td>
                            <td>0.02 max</td>
                        </tr>
                        <tr class="t-row">
                            <td>Others (each)</td>
                            <td>0.10 max</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-4">
                <h2 class="fw-bold" style="color:#174268;">Physical Properties of Beryllium Copper C17200</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Density</td>
                            <td>8.25 g/cm³</td>
                        </tr>
                        <tr class="t-row">
                            <td>Melting Point</td>
                            <td>866 – 982 °C</td>
                        </tr>
                        <tr class="t-row">
                            <td>Electrical Conductivity</td>
                            <td>20 – 65% IACS</td>
                        </tr>
                        <tr class="t-row">
                            <td>Thermal Conductivity</td>
                            <td>105 W/m·K</td>
                        </tr>
                        <tr class="t-row">
                            <td>Specific Heat Capacity</td>
                            <td>0.38 J/g·K</td>
                        </tr>
                        <tr class="t-row">
                            <td>Modulus of Elasticity</td>
                            <td>131 GPa</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-4">
                <h2 class="fw-bold" style="color:#174268;">Mechanical Properties of Beryllium Copper C17200 (Aged)</h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Annealed (TB00)</th>
                            <th>Cold-Drawn</th>
                            <th>Precipitation Hardened (HT)</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>415–585 MPa</td>
                            <td>620–1140 MPa</td>
                            <td>1140–1585 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>275–345 MPa</td>
                            <td>≈90% of TS</td>
                            <td>≈90% of TS</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation</td>
                            <td>20–30%</td>
                            <td>10–20%</td>
                            <td>2–5%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Hardness</td>
                            <td>35–60 HRB</td>
                            <td>Up to 60 HRB</td>
                            <td>36–45 HRC</td>
                        </tr>
                        <tr class="t-row">
                            <td>Electrical Conductivity</td>
                            <td>19–28% IACS</td>
                            <td>15–20% IACS</td>
                            <td>15–20% IACS</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Available Forms & Size Range – Beryllium Copper C17200</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Product Form</th>
                            <th>Size Range</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Sheets & Plates</td>
                            <td>0.5 – 50 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Coils & Strips</td>
                            <td>0.1 – 5 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Rods & Bars</td>
                            <td>Ø 5 – 300 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Pipes & Tubes</td>
                            <td>OD 6 – 150 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Wires & Foils</td>
                            <td>As thin as 0.02 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Forged Components</td>
                            <td>As per drawing</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Beryllium Copper</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Beryllium Copper</strong> is available in:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Beryllium Copper products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>High strength comparable to steels</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Excellent fatigue and stress relaxation resistance</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Non-magnetic and non-sparking</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>High electrical and thermal conductivity</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Excellent corrosion and wear resistance</h5>
                    </div>
                </div>
            </div>
    </section>

<section id="applications"class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Beryllium Copper</h2>
                <p class="text-center pb-3"><strong class="text-dark">Beryllium Copper</strong> is widely chosen for its
                    unmatched combination of high strength, corrosion resistance, and non-magnetic properties, making it
                    indispensable in:</p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>BERYLLIUM COPPER PRICE PER KG (INDIA)</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹4,500 – ₹9,000 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    What is Beryllium Copper and what are its key properties?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Beryllium Copper (CuBe) is a high-performance copper alloy containing 0.4%–2% beryllium.
                                    It is valued for its exceptional strength, electrical and thermal conductivity,
                                    non magnetic
                                    behavior, and corrosion resistance. It can be heat treated for even higher mechanical
                                    strength,
                                    making it ideal for demanding applications.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    What are the main applications of Beryllium Copper?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Beryllium Copper is widely used in electrical & electronics, aerospace & defense, marine
                                    engineering,
                                    oil & gas, automotive, and tooling industries. Common applications include connectors,
                                    contacts, springs,
                                    non-sparking tools, valve components, bearings, molds, and aerospace hardware.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    Why is Beryllium Copper preferred over other copper alloys?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Unlike standard copper alloys, Beryllium Copper provides a unique balance of high
                                    strength and conductivity.
                                    It offers better fatigue resistance, non-sparking safety, and non-magnetic properties,
                                    making it superior in
                                    critical environments like offshore platforms, defense systems, and high precision
                                    electrical components.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    What Beryllium Copper products does MOKSH TUBES & FITTINGS LLP supply?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    We manufacture and stock a wide range of Beryllium Copper products, including pipes,
                                    tubes, sheets, plates,
                                    coils, bars, wires, foils, forgings, pipe fittings, flanges, fasteners, and
                                    custom fabricated components,
                                    all produced to international standards such as ASTM, AMS, and DIN.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>
                                    Why choose MOKSH TUBES & FITTINGS LLP for Beryllium Copper materials?
                                </h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted global supplier offering strict quality control,
                                    custom sizes,
                                    fast delivery, and compliance with international standards. With our technical
                                    expertise, global logistics,
                                    and reliable material traceability, we are the preferred choice for high quality
                                    Beryllium Copper solutions.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    contact <strong>Moksh Tubes & Fittings LLP</strong> — for reliable supply, precision quality, and
                    unbeatable service.
                    <!-- Call button -->
                    <a href="tel:+919769584950" class="contact-cta-btn">Get in Touch</a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Heat Treatment of Beryllium Copper C17200</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Heat Treatment Stage</th>
                            <th>Temperature Range</th>
                            <th>Purpose</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Solution Annealing</td>
                            <td>760 – 800°C</td>
                            <td>Dissolves beryllium into copper matrix</td>
                        </tr>
                        <tr class="t-row">
                            <td>Quenching</td>
                            <td>Water quench</td>
                            <td>Retains solid solution</td>
                        </tr>
                        <tr class="t-row">
                            <td>Age Hardening (Precipitation)</td>
                            <td>315 – 325°C (2–3 hrs)</td>
                            <td>Achieves maximum strength & hardness</td>
                        </tr>
                        <tr class="t-row">
                            <td>Stress Relieving</td>
                            <td>260 – 315°C</td>
                            <td>Reduces internal stresses</td>
                        </tr>
                    </tbody>
                </table>

                <p class="mt-3 text-center">
                    📌 After precipitation hardening, C17200 can reach up to <strong>45 HRC</strong> with excellent fatigue
                    resistance.
                </p>
            </div>
        </div>
    </section>
--}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades – C17200</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>C17200</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>Alloy 25</td>
                        </tr>
                        <tr class="t-row">
                            <td>SAE</td>
                            <td>J461 / J463</td>
                        </tr>
                        <tr class="t-row">
                            <td>AMS</td>
                            <td>4533, 4534, 4535, 4650</td>
                        </tr>
                        <tr class="t-row">
                            <td>DIN</td>
                            <td>CuBe2</td>
                        </tr>
                        <tr class="t-row">
                            <td>ISO</td>
                            <td>CuBe2</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
    @verbatim
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is Beryllium Copper and what are its key properties?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Beryllium Copper (CuBe) is a high-performance copper alloy containing 0.4%–2% beryllium. It is valued for its exceptional strength, electrical and thermal conductivity, non-magnetic behavior, and corrosion resistance. It can be heat treated for even higher mechanical strength, making it ideal for demanding applications."
      }
    },
    {
      "@type": "Question",
      "name": "What are the main applications of Beryllium Copper?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Beryllium Copper is widely used in electrical and electronics, aerospace and defense, marine engineering, oil and gas, automotive, and tooling industries. Common applications include connectors, contacts, springs, non-sparking tools, valve components, bearings, molds, and aerospace hardware."
      }
    },
    {
      "@type": "Question",
      "name": "Why is Beryllium Copper preferred over other copper alloys?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Unlike standard copper alloys, Beryllium Copper provides a unique balance of high strength and conductivity. It offers better fatigue resistance, non-sparking safety, and non-magnetic properties, making it superior in critical environments like offshore platforms, defense systems, and high-precision electrical components."
      }
    },
    {
      "@type": "Question",
      "name": "What Beryllium Copper products does MOKSH TUBES & FITTINGS LLP supply?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We manufacture and stock a wide range of Beryllium Copper products, including pipes, tubes, sheets, plates, coils, bars, wires, foils, forgings, pipe fittings, flanges, fasteners, and custom fabricated components, all produced to international standards such as ASTM, AMS, and DIN."
      }
    },
    {
      "@type": "Question",
      "name": "Why choose MOKSH TUBES & FITTINGS LLP for Beryllium Copper materials?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "MOKSH TUBES & FITTINGS LLP is a trusted global supplier offering strict quality control, custom sizes, fast delivery, and compliance with international standards. With our technical expertise, global logistics, and reliable material traceability, we are the preferred choice for high-quality Beryllium Copper solutions."
      }
    }
  ]
}
@endverbatim
</script>
@endsection


