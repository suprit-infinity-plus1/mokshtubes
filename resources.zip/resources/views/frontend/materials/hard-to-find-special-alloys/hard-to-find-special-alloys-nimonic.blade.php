@extends('layouts.master')

@section('title', 'Nimonic Alloys | High-Temp Strength & Durability')
@section('meta_description',
    'Nimonic alloys – high-temperature, creep-resistant, and durable for aerospace, turbines,
    power generation, and extreme industrial environments.')
@section('meta_keywords',
    'Nimonic alloy, high temperature alloy, creep resistant alloy, aerospace alloy, turbine alloy,
    power generation alloy, durable high strength alloy')
@section('og_image',
    asset('assets/images/hard-to-find-and-special-alloys/hard-to-find-and-special-alloys-nimonic.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/hard-to-find-and-special-alloys/hard-to-find-and-special-alloys-nimonic.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Nimonic Alloys <br> High-Temperature Strength</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        Nimonic Alloys are high-performance nickel-based superalloys specifically engineered for exceptional
                        strength, creep resistance, and stability at elevated temperatures. They offer excellent oxidation
                        and corrosion resistance, making them ideal for aerospace engines, gas turbines, heat-treatment
                        equipment, and other high-temperature industrial applications where long-term reliability is
                        critical.

                    </p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Nimonic Alloys
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/hard-to-find-and-special-alloys/hard-to-find-and-special-alloys-nimonic.webp') }}"
                        alt="Nimonic Alloys" class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> is a leading supplier, stockist,
                            and exporter of high-performance<strong class="text-black"> Nimonic Alloys,</strong> known for
                            their exceptional resistance to heat,
                            oxidation, and corrosion. These nickel-chromium-based superalloys are engineered for extreme
                            temperature applications where mechanical strength and structural stability are vital—especially
                            in aerospace, gas turbines, nuclear reactors, and high-stress environments.
                        </p>
                        <p> <strong class="text-black"><a
                                    href="{{ route('materials.hard-To-Find-Special-Alloys') }}">Nimonic
                                    Alloys</a></strong> are primarily composed of Nickel (Ni) and
                            Chromium (Cr), often combined with Titanium (Ti) and Aluminum (Al) for precipitation hardening.
                            Popular grades include Nimonic 75, 80A, 90, 105, 263, and others—each suited to specific
                            mechanical and thermal requirements.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Hard To Find Special Alloy Nimonic Datasheet</h3>
            <p class="mb-3">
                Get the complete Hard To Find Special Alloy Nimonic datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

{{-- 
<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>Material Summary – NIMONIC® Alloys</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Material Type</td>
                                    <td>Nickel–Chromium Superalloys</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Strength Mechanism</td>
                                    <td>Solid Solution + Precipitation Hardening</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Temperature Resistance</td>
                                    <td>Up to 950 – 1050 °C (Grade dependent)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Oxidation Resistance</td>
                                    <td>Excellent</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Creep Resistance</td>
                                    <td>Excellent</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Weldability</td>
                                    <td>Good (Best: Nimonic 263)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Property</td>
                                    <td>Non-Magnetic</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Forms</td>
                                    <td>Bars, Sheets, Tubes, Wires, Forgings</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of Common Nimonic Grades</h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Element</th>
                            <th>Nimonic 75</th>
                            <th>Nimonic 80A</th>
                            <th>Nimonic 90</th>
                            <th>Nimonic 105</th>
                            <th>Nimonic 263</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Ni</td>
                            <td>≤ 20%</td>
                            <td>≤ 30%</td>
                            <td>≤ 30%</td>
                            <td>≤ 30%</td>
                            <td>≤ 20%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Cr</td>
                            <td>≤ 3%</td>
                            <td>≤ 3%</td>
                            <td>≤ 3%</td>
                            <td>≤ 5%</td>
                            <td>≤ 3%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Co</td>
                            <td>Present</td>
                            <td>≥ 2.5%</td>
                            <td>≤ 5%</td>
                            <td>≤ 5%</td>
                            <td>≤ 5%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Ti</td>
                            <td>≥ 0.6%</td>
                            <td>≤ 0.5%</td>
                            <td>≤ 0.5%</td>
                            <td>≤ 0.5%</td>
                            <td>≤ 0.5%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Al</td>
                            <td>≥ 0.6%</td>
                            <td>≤ 0.5%</td>
                            <td>≤ 0.5%</td>
                            <td>≤ 0.5%</td>
                            <td>≥ 1.0%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Mo</td>
                            <td>Present</td>
                            <td>Present</td>
                            <td>Present</td>
                            <td>≤ 1.0%</td>
                            <td>≤ 1.0%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Fe</td>
                            <td>≥ 10%</td>
                            <td>≥ 5%</td>
                            <td>≥ 5%</td>
                            <td>≥ 5%</td>
                            <td>≥ 2%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Others</td>
                            <td>No C, Mn, Si, Cu, S</td>
                            <td>No B, Zr, C, Mn</td>
                            <td>No B, Zr, C, Mn</td>
                            <td>No B, Zr, C, Mn</td>
                            <td>Excludes C, Mn, Si; adds P, Sn</td>
                        </tr>
                    </tbody>
                </table>

                <p class="mt-3 text-center">
                    📌 Composition varies by grade. Contact us for full datasheets of Nimonic 80A, 90, 105 & 263.
                </p>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Physical Properties of Nimonic 75 (Typical)
                </h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Imperial Units</th>
                            <th>Metric Units</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Density</td>
                            <td>0.30 lb/in³</td>
                            <td>8.2 g/cm³</td>
                        </tr>
                        <tr class="t-row">
                            <td>Melting Range</td>
                            <td>2500 – 2650 °F</td>
                            <td>1370 – 1460 °C</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elastic Modulus (Tension)</td>
                            <td>28 × 10³ ksi</td>
                            <td>193 GPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elastic Modulus (Compression)</td>
                            <td>28 × 10³ ksi</td>
                            <td>193 GPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elastic Modulus (Torsion)</td>
                            <td>10 × 10³ ksi</td>
                            <td>69 GPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Poisson’s Ratio</td>
                            <td>0.30</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Curie Temperature</td>
                            <td>~1040 °F</td>
                            <td>~560 °C</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Heat Treatment -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-10">
                    <h4 class="text-center mb-3" style="color:#db7227;">
                        Heat Treatment & Strengthening of Nimonic Alloys
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Process</th>
                                    <th>Temperature Range</th>
                                    <th>Purpose</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Solution Annealing</td>
                                    <td>1050 – 1200 °C</td>
                                    <td>Dissolves precipitates, improves ductility</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aging / Precipitation Hardening</td>
                                    <td>700 – 850 °C</td>
                                    <td>Increases high-temperature strength</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>650 – 750 °C</td>
                                    <td>Reduces residual stresses</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hot Working</td>
                                    <td>950 – 1150 °C</td>
                                    <td>Forging & rolling</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Cold Working + Aging</td>
                                    <td>—</td>
                                    <td>Improves strength & creep resistance</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            📌 Grades like Nimonic 80A, 90 & 105 rely on γ′ (gamma-prime) precipitation for strength.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties – Nimonic 75 (Typical)
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Annealed</th>
                            <th>Hot-Finished</th>
                            <th>Cold-Drawn</th>
                            <th>Hot-Rolled</th>
                            <th>Sheet</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>620–830 MPa</td>
                            <td>896–1172 MPa</td>
                            <td>1034–1379 MPa</td>
                            <td>690–965 MPa</td>
                            <td>620–896 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>414–620 MPa</td>
                            <td>758–1034 MPa</td>
                            <td>965–1240 MPa</td>
                            <td>483–758 MPa</td>
                            <td>414–620 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation</td>
                            <td>15–30%</td>
                            <td>8–15%</td>
                            <td>5–10%</td>
                            <td>15–25%</td>
                            <td>20–30%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Brinell Hardness</td>
                            <td>180–220</td>
                            <td>250–300</td>
                            <td>300–350</td>
                            <td>200–250</td>
                            <td>180–220</td>
                        </tr>
                        <tr class="t-row">
                            <td>Rockwell Hardness</td>
                            <td>60–70 B</td>
                            <td>80–90 B</td>
                            <td>90–95 B</td>
                            <td>70–80 B</td>
                            <td>65–75 B</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="available-forms">
        <div class="container">
            <div class="section-title center">
                <h2>Available Forms & Size Range – Nimonic Alloys</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Product Form</th>
                            <th>Typical Size Range</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Round Bars / Rods</td>
                            <td>6 mm – 350 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Flat Bars</td>
                            <td>Thickness 5 – 100 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Sheets & Plates</td>
                            <td>0.5 – 60 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Coils & Strips</td>
                            <td>0.1 – 6 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Pipes & Tubes</td>
                            <td>OD 6 – 250 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Wires</td>
                            <td>0.1 – 12 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Fasteners</td>
                            <td>M4 – M72</td>
                        </tr>
                        <tr class="t-row">
                            <td>Custom Components</td>
                            <td>As per drawing</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Nimonic Alloys</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Nimonic Alloys</strong> is commonly supplied as:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        We supply Nimonic Alloys materials in accordance with the most stringent industry standards: </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Superior resistance to heat creep and fatigue</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Excellent oxidation and corrosion resistance at high temperatures</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>High strength-to-weight ratio</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Good weldability and workability (especially Nimonic 263)</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Long-term dimensional and structural stability</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Nimonic Alloys</h2>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>Nimonic Alloy Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹3,500 – ₹12,000 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are Nimonic Alloys used for?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Nimonic Alloys are used in turbine blades, combustion chambers, exhaust systems, gas
                                    turbines, nuclear reactors, high performance automotive components, and industrial
                                    furnace parts requiring superior heat and corrosion resistance.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Which grades of Nimonic Alloys are available?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Popular grades include Nimonic 75, 80A, 90, 105, and 263, each engineered for specific
                                    mechanical strength, thermal performance, and structural stability under extreme
                                    conditions.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key properties of Nimonic Alloys?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Nimonic Alloys offer excellent heat creep resistance, oxidation and corrosion
                                    resistance, high strength to weight ratio, dimensional stability, and good weldability,
                                    especially in Nimonic 263.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>In what forms are Nimonic Alloys supplied?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    They are supplied as seamless and welded pipes, tubes, sheets, plates, coils, strips,
                                    round/flat/hex/square bars, pipe fittings, flanges, fasteners, and custom engineered
                                    components.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS for Nimonic Alloys?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    We provide ISO 9001:2015 certified Nimonic products with wide inventory availability,
                                    custom fabrication, CNC machining, fast turnaround, competitive pricing, and global
                                    shipping with export compliance.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    Contact <strong>Moksh Tubes & Fittings LLP</strong> — for expert support, MTC-certified materials, and
                    custom solutions.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades – Nimonic</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Grade</th>
                            <th>UNS</th>
                            <th>British Std</th>
                            <th>AMS</th>
                            <th>ISO</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Nimonic 75</td>
                            <td>N06075</td>
                            <td>BS HR1</td>
                            <td>AMS 5709</td>
                            <td>ISO NiCr20Ti</td>
                        </tr>
                        <tr class="t-row">
                            <td>Nimonic 80A</td>
                            <td>N07080</td>
                            <td>BS HR6017</td>
                            <td>AMS 5699</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Nimonic 90</td>
                            <td>N07090</td>
                            <td>BS HR3</td>
                            <td>AMS 5823</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Nimonic 105</td>
                            <td>N12115</td>
                            <td>BS HR5</td>
                            <td>AMS 5745</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Nimonic 263</td>
                            <td>N07263</td>
                            <td>—</td>
                            <td>AMS 5887</td>
                            <td>—</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
                {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                    "@type": "Question",
                    "name": "What are Nimonic Alloys used for?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Nimonic Alloys are used in turbine blades, combustion chambers, exhaust systems, gas turbines, nuclear reactors, high performance automotive components, and industrial furnace parts requiring superior heat and corrosion resistance."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "Which grades of Nimonic Alloys are available?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Popular grades include Nimonic 75, 80A, 90, 105, and 263, each engineered for specific mechanical strength, thermal performance, and structural stability under extreme conditions."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What are the key properties of Nimonic Alloys?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Nimonic Alloys offer excellent heat creep resistance, oxidation and corrosion resistance, high strength to weight ratio, dimensional stability, and good weldability, especially in Nimonic 263."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "In what forms are Nimonic Alloys supplied?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "They are supplied as seamless and welded pipes, tubes, sheets, plates, coils, strips, round/flat/hex/square bars, pipe fittings, flanges, fasteners, and custom engineered components."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "Why choose MOKSH TUBES & FITTINGS for Nimonic Alloys?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "We provide ISO 9001:2015 certified Nimonic products with wide inventory availability, custom fabrication, CNC machining, fast turnaround, competitive pricing, and global shipping with export compliance."
                    }
                    }
                ]
                }

            @endverbatim
    </script>
@endsection


