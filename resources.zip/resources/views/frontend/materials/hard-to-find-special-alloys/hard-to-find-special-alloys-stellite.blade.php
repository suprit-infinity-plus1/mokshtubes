@extends('layouts.master')

@section('title', 'Stellite Metal | Moksh Tubes – Durable & High Strength')
@section('meta_description',
    'Stellite alloys at MokshTubes deliver exceptional hardness, wear and corrosion resistance
    for cutting tools, valves, machinery & high-stress applications.')
@section('meta_keywords',
    'Stellite alloy, high hardness alloy, wear resistant alloy, corrosion resistant alloy, cutting
    tools alloy, valves alloy, industrial machinery alloy, durable Stellite')
@section('og_image',
    asset('assets/images/hard-to-find-and-special-alloys/hard-to-find-and-special-alloys-stellite.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/hard-to-find-and-special-alloys/hard-to-find-and-special-alloys-stellite.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Stellite Alloy <br> Durable High Strength Metal</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        Stellite Alloy is a cobalt-based alloy known for its exceptional durability, high strength, and
                        outstanding resistance to wear, heat, and corrosion. It maintains hardness at elevated temperatures
                        and performs reliably in harsh environments, making it ideal for cutting tools, valve components,
                        bearings, and industrial wear-resistant applications.
                    </p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Stellite Alloys
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/hard-to-find-and-special-alloys/hard-to-find-and-special-alloys-stellite.webp') }}"
                        alt="Stellite" class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> <a href="{{ route('index') }}">MOKSH TUBES & FITTINGS
                                    LLP</a></strong> is a trusted manufacturer,
                            supplier, exporter, importer, and stockist of<strong class="text-black"> Stellite
                                Alloys</strong> in a variety of forms including
                            Rods, Bars, <a href="{{ route('products.pipes-tubes') }}">Tubes</a>, Welding Wires, Electrodes,
                            Sheets, Plates, and custom components made to
                            order. We specialize in Stellite 6, Stellite 12, Stellite 21, and other grades used for
                            wear-resistant and high-temperature
                        </p>
                        <p> <strong class="text-black">Stellite</strong> is a
                            family of cobalt-chromium-based superalloys
                            engineered to resist wear, corrosion, and high-temperature degradation. Originally developed for
                            cutting tools, Stellite alloys have become indispensable in industries requiring reliable
                            performance under extreme mechanical and thermal stress. These alloys are known for their
                            exceptional hardness, non-magnetic properties, high-temperature oxidation resistance, and
                            ability to retain cutting edges and structural integrity in harsh environments.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Hard To Find Special Alloy Stellite Datasheet</h3>
            <p class="mb-3">
                Get the complete Hard To Find Special Alloy Stellite datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

{{-- 
<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>Material Summary – Stellite® Alloys</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Material Type</td>
                                    <td>Cobalt-Chromium Superalloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Primary Elements</td>
                                    <td>Co, Cr, W, C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Strength Mechanism</td>
                                    <td>Solid Solution + Carbide Hardening</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hardness Range</td>
                                    <td>40 – 70 HRC (grade dependent)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Wear Resistance</td>
                                    <td>Exceptional</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Galling Resistance</td>
                                    <td>Excellent</td>
                                </tr>
                                <tr class="t-row">
                                    <td>High-Temperature Stability</td>
                                    <td>Up to ~800 – 1000 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Corrosion Resistance</td>
                                    <td>Excellent</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Property</td>
                                    <td>Non-Magnetic</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Weldability</td>
                                    <td>Excellent (Hard-facing & Overlay)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition – Stellite® 6 (Typical)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Cobalt (Co)</td>
                                    <td>Balance</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>27 – 32</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Tungsten (W)</td>
                                    <td>4.0 – 6.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>0.9 – 1.4</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Nickel (Ni)</td>
                                    <td>≤ 3.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>≤ 3.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon (Si)</td>
                                    <td>≤ 1.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese (Mn)</td>
                                    <td>≤ 1.0</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            📌 Exact chemistry varies by Stellite® grade (6, 12, 21, etc.).
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Physical Properties of Stellite® 6
                </h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Imperial Units</th>
                            <th>Metric Units</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Density</td>
                            <td>0.335 lb/in³</td>
                            <td>9.3 g/cm³</td>
                        </tr>
                        <tr class="t-row">
                            <td>Melting Point</td>
                            <td>2375 – 2600 °F</td>
                            <td>1300 – 1425 °C</td>
                        </tr>
                        <tr class="t-row">
                            <td>Hardness (As-Cast)</td>
                            <td>43 – 48 HRC</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Magnetic Permeability</td>
                            <td>Non-magnetic</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Thermal Conductivity</td>
                            <td>—</td>
                            <td>~11 W/m·K</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Heat Treatment -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-10">
                    <h4 class="text-center mb-3" style="color:#db7227;">
                        Heat Treatment & Processing of Stellite® Alloys
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Process</th>
                                    <th>Temperature Range</th>
                                    <th>Purpose</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Casting / Forging</td>
                                    <td>1150 – 1250 °C</td>
                                    <td>Primary shape formation</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Solution Treatment</td>
                                    <td>1150 – 1200 °C</td>
                                    <td>Homogenizes microstructure</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>650 – 800 °C</td>
                                    <td>Reduces residual stresses</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hard-facing / Overlay Welding</td>
                                    <td>Controlled heat input</td>
                                    <td>Surface wear protection</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Grinding & Finishing</td>
                                    <td>—</td>
                                    <td>Final dimensional accuracy</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            📌 Stellite® alloys do not require conventional hardening; hardness comes from carbide
                            precipitation.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties of Stellite® Alloys
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Annealed</th>
                            <th>Hot-Finished</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>620 – 830 MPa</td>
                            <td>827 – 1034 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>414 – 620 MPa</td>
                            <td>690 – 896 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation</td>
                            <td>15 – 25%</td>
                            <td>10 – 15%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Brinell Hardness</td>
                            <td>350 – 500</td>
                            <td>500 – 700</td>
                        </tr>
                        <tr class="t-row">
                            <td>Rockwell Hardness</td>
                            <td>40 – 60 HRC</td>
                            <td>55 – 70 HRC</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="available-forms">
        <div class="container">
            <div class="section-title center">
                <h2>Available Forms & Size Range – Stellite® Alloys</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Product Form</th>
                            <th>Typical Size Range</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Round Bars / Rods</td>
                            <td>Ø6 – Ø200 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Flat Bars & Plates</td>
                            <td>3 – 80 mm thickness</td>
                        </tr>
                        <tr class="t-row">
                            <td>Sheets</td>
                            <td>1 – 20 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Pipes & Tubes</td>
                            <td>OD 10 – 150 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Welding Rods / Wires</td>
                            <td>Ø2.0 – Ø6.0 mm</td>
                        </tr>
                        <tr class="t-row">
                            <td>Electrodes</td>
                            <td>AWS standard sizes</td>
                        </tr>
                        <tr class="t-row">
                            <td>Cast Components</td>
                            <td>As per drawing</td>
                        </tr>
                        <tr class="t-row">
                            <td>Hard-faced Parts</td>
                            <td>Custom overlay thickness</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Stellite</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Stellite</strong> is commonly supplied as:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        We supply Stellite materials in accordance with the most stringent industry standards: </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Outstanding wear and galling resistance</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Retains hardness at elevated temperatures</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Excellent resistance to corrosion and oxidation</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Non-magnetic and stable in extreme conditions</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Available in both cast and wrought forms</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Stellite</h2>
                <p><strong class="text-black">Stellite</strong> is widely used in applications that demand resistance to
                    wear, corrosion, and extreme temperatures. These include:</p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>Stellite® Alloy Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹6,000 – ₹18,000 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is Stellite and why is it used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Stellite is a cobalt-chromium superalloy designed for extreme wear, corrosion, and
                                    high temperature resistance, making it ideal for aerospace, oil & gas, power generation,
                                    and cutting tool applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Which forms of Stellite products are available?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Stellite is supplied as seamless and welded pipes, tubes, sheets, plates, coils, strips,
                                    round/flat/hex/square bars, pipe fittings, flanges, fasteners, welding wires,
                                    electrodes, and custom fabricated components.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key advantages of Stellite?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Stellite offers excellent wear and galling resistance, maintains hardness at high
                                    temperatures, resists corrosion and oxidation, is non magnetic, and is available in both
                                    cast and wrought forms.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>In which industries is Stellite commonly used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Stellite is widely used in aerospace (turbine blades, vanes), valve and pump components,
                                    oil & gas and petrochemical equipment, power generation (boilers, turbines), medical and
                                    dental tools, and cutting tools and dies.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS for Stellite alloys?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    We provide specialized hard-to-find Stellite alloys, high-quality cobalt-based stock,
                                    custom fabrication and welding services, in-house quality control, metallurgical
                                    testing, fast delivery, and global export capabilities.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    Contact <strong>Moksh Tubes & Fittings LLP</strong> —your expert partner for high-performance cobalt
                    alloys.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades – Stellite® Alloys</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Grade</th>
                            <th>AWS</th>
                            <th>ASTM</th>
                            <th>ISO / Other</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Stellite 6</td>
                            <td>ERCoCr-A</td>
                            <td>ASTM B659</td>
                            <td>ISO CoCr-A</td>
                        </tr>
                        <tr class="t-row">
                            <td>Stellite 12</td>
                            <td>ERCoCr-B</td>
                            <td>ASTM B560</td>
                            <td>ISO CoCr-B</td>
                        </tr>
                        <tr class="t-row">
                            <td>Stellite 21</td>
                            <td>ERCoCr-E</td>
                            <td>ASTM F90</td>
                            <td>ISO CoCr-E</td>
                        </tr>
                        <tr class="t-row">
                            <td>Cast Grades</td>
                            <td>—</td>
                            <td>ASTM A494</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Electrodes</td>
                            <td>ECoCr-A / B</td>
                            <td>AWS A5.13</td>
                            <td>—</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
            {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                "@type": "Question",
                "name": "What is Stellite and why is it used?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Stellite is a cobalt-chromium superalloy designed for extreme wear, corrosion, and high temperature resistance, making it ideal for aerospace, oil & gas, power generation, and cutting tool applications."
                }
                },
                {
                "@type": "Question",
                "name": "Which forms of Stellite products are available?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Stellite is supplied as seamless and welded pipes, tubes, sheets, plates, coils, strips, round/flat/hex/square bars, pipe fittings, flanges, fasteners, welding wires, electrodes, and custom fabricated components."
                }
                },
                {
                "@type": "Question",
                "name": "What are the key advantages of Stellite?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Stellite offers excellent wear and galling resistance, maintains hardness at high temperatures, resists corrosion and oxidation, is non magnetic, and is available in both cast and wrought forms."
                }
                },
                {
                "@type": "Question",
                "name": "In which industries is Stellite commonly used?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Stellite is widely used in aerospace (turbine blades, vanes), valve and pump components, oil & gas and petrochemical equipment, power generation (boilers, turbines), medical and dental tools, and cutting tools and dies."
                }
                },
                {
                "@type": "Question",
                "name": "Why choose MOKSH TUBES & FITTINGS for Stellite alloys?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We provide specialized hard-to-find Stellite alloys, high-quality cobalt-based stock, custom fabrication and welding services, in-house quality control, metallurgical testing, fast delivery, and global export capabilities."
                }
                }
            ]
            }

        @endverbatim
    </script>
@endsection


