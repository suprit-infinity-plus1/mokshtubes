@extends('layouts.master')

@section('title', 'Incoloy 020 – Elite Acid-Resistant Super Alloy')
@section('meta_description',
    'Incoloy 020 ensures superior resistance to sulfuric acid and harsh chemicals—delivering
    long service life in challenging industrial environments.')
@section('meta_keywords',
    'Incoloy 020, Incoloy 020 Pipes, Incoloy 020 Tubes, Incoloy 020 Fittings, Acid Resistant
    Incoloy 020, Corrosion Resistant Incoloy 020, Sulfuric Acid Resistant Incoloy 020, Chemical Processing Incoloy 020,
    Industrial Incoloy 020 Alloy, High Performance Incoloy 020')
@section('og_image', asset('assets/images/incoloy/incoloy-020.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area" style="background-image: url(/assets/images/incoloy/incoloy-020.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Incoloy 020 <br> High-Performance Industrial Alloy</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        INCOLOY® Alloy 020 (UNS N08020 / W.Nr. 2.4660) is a high-performance nickel-iron-chromium alloy
                        designed for superior corrosion resistance in sulfuric acid and other aggressive chemical
                        environments. It offers excellent resistance to pitting, crevice corrosion, and chloride-induced
                        stress corrosion cracking, and is stabilized with niobium to prevent intergranular corrosion in
                        welded structures. Below is the complete datasheet including composition, properties, heat
                        treatment, and applications.

                        <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Incoloy 020 / Alloy 020 / UNS N08020 / W.Nr. 2.4660 </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/incoloy/incoloy-020.webp') }}" alt="incoloy-020"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <a href="{{ route('materials.incoloy') }}" class="text-black"><strong>INCOLOY 020</strong></a>
                            is a corrosion-resistant nickel-iron-chromium alloy designed specifically to handle sulfuric
                            acid and other aggressive chemical environments.
                            With the addition of copper and molybdenum, this alloy offers exceptional resistance to pitting,
                            crevice corrosion, and chloride-induced stress corrosion cracking.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black">MOKSH TUBES & FITTINGS LLP</strong> is a trusted
                            manufacturer, exporter, supplier, importer, and stockist of INCOLOY 020 in multiple forms
                            including <a href="{{ route('products.pipes-tubes') }}">pipes & tubes</a>, fittings, flanges,
                            fasteners, sheets, plates, bars, rods, coils, wire mesh, and custom-fabricated products.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Incoloy 020 Datasheet</h3>
            <p class="mb-3">
                Get the complete Incoloy 020 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>INCOLOY Alloy 020 Specifications</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>INCOLOY® Alloy 020 / UNS N08020 / W.Nr. 2.4660</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>Nickel-Iron-Chromium Corrosion-Resistant Alloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Chemical Composition</td>
                                    <td>
                                        Ni 36–38%, Fe 39–41%, Cr 19–21%, Cu 1%, Mo 0.5–1.0%,
                                        Nb 0.3–0.7%, C ≤ 0.03%, Mn ≤ 1%, Si ≤ 1%, S ≤ 0.015%
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>Annealed, Solution Treated, Cold Worked</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Annealing, Stress Relieving</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Tensile, Hardness, Chemical, Corrosion, NDT on request</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2 (Mill Test Certificate available)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- col-lg-8 -->

            </div> <!-- row -->
        </div> <!-- container -->
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of Incoloy 020</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Nickel (Ni)</td>
                                    <td>32.0 – 38.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>19.0 – 21.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>Balance</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Molybdenum (Mo)</td>
                                    <td>2.0 – 3.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Copper (Cu)</td>
                                    <td>3.0 – 4.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese (Mn)</td>
                                    <td>≤ 2.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon (Si)</td>
                                    <td>≤ 1.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>≤ 0.02</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Technical Composition of Incoloy 020</h2>
            </div>
            <!-- Mechanical Properties Table -->
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <h3 class="text-center mb-3" style="color: #db7227;">Physical Properties of Incoloy 020
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial Units</th>
                                    <th>Metric Units</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.292 lb/in³</td>
                                    <td>8.08 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Shear Modulus</td>
                                    <td>11 × 10³ ksi</td>
                                    <td>76 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Young’s Modulus</td>
                                    <td>28 × 10³ ksi</td>
                                    <td>193 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat</td>
                                    <td>0.12 Btu/lb•°F</td>
                                    <td>500 J/kg•°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Electrical Resistivity</td>
                                    <td>651 ohm·circ mil/ft</td>
                                    <td>1.08 µΩ·m</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Thermal Conductivity</td>
                                    <td>85 Btu·in/ft²·h·°F</td>
                                    <td>12.3 W/m·°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Coefficient of Thermal Expansion (77–212°F)</td>
                                    <td>8.2 × 10⁻⁶ in/in·°F</td>
                                    <td>14.7 µm/m·°C (25–100°C)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Mechanical Properties Table -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color: #db7227;">Heat Treatment of Incoloy 020
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Heat Treatment Process</th>
                                    <th>Temperature Range</th>
                                    <th>Cooling / Procedure</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Annealing / Solution Treatment</td>
                                    <td>1040 – 1120°C</td>
                                    <td>Rapid water quench or air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>600 – 650°C</td>
                                    <td>Hold for 1–2 hours, then air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Softening (Optional)</td>
                                    <td>980 – 1050°C</td>
                                    <td>Furnace cool for maximum ductility</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hot Working Prep</td>
                                    <td>980 – 1120°C</td>
                                    <td>Heat uniformly before forming</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Recovery / Recrystallization</td>
                                    <td>700 – 900°C</td>
                                    <td>Air cool</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Mechanical Properties of Incoloy 020</h2>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Cold Reduction (%)</th>
                            <th>Yield Strength (ksi)</th>
                            <th>Yield Strength (MPa)</th>
                            <th>Tensile Strength (ksi)</th>
                            <th>Tensile Strength (MPa)</th>
                            <th>Elongation (%)</th>
                            <th>Hardness (Rockwell)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="t-row">
                            <td>0%</td>
                            <td>44.4</td>
                            <td>306</td>
                            <td>95.8</td>
                            <td>661</td>
                            <td>38</td>
                            <td>B83</td>
                        </tr>
                        <tr class="t-row">
                            <td>20%</td>
                            <td>111.0</td>
                            <td>765</td>
                            <td>119.8</td>
                            <td>826</td>
                            <td>13</td>
                            <td>C23</td>
                        </tr>
                        <tr class="t-row">
                            <td>30%</td>
                            <td>124.3</td>
                            <td>857</td>
                            <td>131.5</td>
                            <td>907</td>
                            <td>8</td>
                            <td>C28</td>
                        </tr>
                        <tr class="t-row">
                            <td>40%</td>
                            <td>127.5</td>
                            <td>879</td>
                            <td>135.0</td>
                            <td>931</td>
                            <td>7</td>
                            <td>C27</td>
                        </tr>
                        <tr class="t-row">
                            <td>50%</td>
                            <td>139.5</td>
                            <td>962</td>
                            <td>147.5</td>
                            <td>1017</td>
                            <td>4</td>
                            <td>C30</td>
                        </tr>
                        <tr class="t-row">
                            <td>60%</td>
                            <td>139.9</td>
                            <td>965</td>
                            <td>149.3</td>
                            <td>1029</td>
                            <td>5</td>
                            <td>C31</td>
                        </tr>
                    </tbody>
                </table>
                {{-- <p class="mt-3 text-center">
                    After quenching & tempering, 1055 steel hardness can reach 45–55 HRC depending on cooling media.
                </p> --}}

            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5" id="available forms">
                <h2>Available Forms & Size Range</h2>
            </div>

            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6 text-center">
                        We supply Incoloy 020 in the following product forms and dimensions:
                    </p>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="p-4 bg-white rounded shadow-sm border-start border-4" style="border-color:#db7227;">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Product Form</th>
                                    <th>Size Range / Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Round Bars</td>
                                    <td>10 mm – 350 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Flat, Square &amp; Hex Bars</td>
                                    <td>Custom sizes up to 250 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sheets &amp; Plates</td>
                                    <td>1.5 mm – 100 mm (Width 600 – 2500 mm)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Coils &amp; Strips</td>
                                    <td>0.3 mm – 8 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Seamless &amp; Welded Pipes / Tubes</td>
                                    <td>OD 6 mm – 273 mm, WT 1 – 25 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Forged Blocks, Rings, Bushings &amp; Components</td>
                                    <td>Custom per drawing</td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products"  class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Incoloy 020</h2>
            </div>

            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">INCOLOY 020</strong>, is available in a variety of standard mill product
                        forms used in high-performance corrosion-resistant applications. These include:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        This alloy meets several recognized industry standards, including:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Excellent resistance to sulfuric acid and other strong acids</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>High resistance to pitting and crevice corrosion</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Resists stress corrosion cracking in chloride-bearing environments</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Maintains corrosion resistance even after welding</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Strong mechanical properties and good workability</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Ideal for highly acidic and mixed chemical media environments</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="applications"  class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of INCOLOY 020</h2>
                <p class="text-center pb-3"><strong class="text-dark">INCOLOY 020</strong> is a premium
                    nickel-iron-chromium alloy engineered for superior corrosion resistance, especially in aggressive
                    chemical environments involving sulfuric acid, chlorides, and mixed acids. Its balanced composition with
                    copper and molybdenum makes it particularly effective against pitting, crevice corrosion, and stress
                    corrosion cracking. This makes Alloy 020 a preferred material across industries that require durability,
                    safety, and long-term reliability under corrosive and acidic conditions.
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>INCOLOY Alloy 020 Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong>  ₹900 – ₹1,500 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by size, OD, thickness, and condition.)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq"  class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is Incoloy 020 and what makes it unique?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 020, also known as Alloy 20, is a nickel-iron-chromium alloy specifically
                                    designed to resist sulfuric acid and other aggressive chemical environments. With the
                                    addition of copper and molybdenum, it provides excellent resistance to pitting, crevice
                                    corrosion, and chloride-induced stress corrosion cracking, making it a preferred
                                    material for industries handling highly corrosive media.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key properties of Incoloy 020 alloy?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 020 exhibits outstanding corrosion resistance, strong mechanical properties, and
                                    excellent workability. It maintains resistance even after welding and delivers superior
                                    protection against sulfuric acid, nitric acid, chlorides, and mixed chemical
                                    environments. Its tensile strength can reach up to 149 ksi, with excellent ductility and
                                    hardness, ensuring durability and long service life in critical applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Where is Incoloy 020 commonly used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 020 is widely used in the chemical processing industry for heat exchangers,
                                    reactors, piping, and storage tanks handling strong acids. It is also utilized in
                                    pharmaceutical and food processing industries, oil and gas facilities, marine
                                    environments, pulp and paper plants, pollution control systems, acid recovery units, and
                                    power generation equipment, where resistance to acidic and chloride rich environments is
                                    essential.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What types of Incoloy 020 products are available?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP supplies Incoloy 020 in multiple forms including seamless and
                                    welded pipes, tubes, sheets, plates, coils, bars, fittings, flanges, fasteners, wire
                                    mesh, and custom fabricated components. All products comply with ASTM, ASME, and
                                    international standards to ensure high performance, reliability, and compatibility with
                                    demanding industrial requirements.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 020 materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted global supplier of Incoloy 020, offering a wide
                                    inventory, quick delivery, and custom machining solutions. With deep expertise in
                                    nickel-based and corrosion-resistant alloys, the company ensures ISO certified quality
                                    assurance, competitive pricing, and full compliance with international standards, making
                                    it a reliable partner for industries that demand long-lasting corrosion resistance and
                                    operational safety.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    <strong>Moksh Tubes & Fittings LLP</strong>Your trusted partner for INCOLOY 020 and high-performance
                    alloy solutions.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades</h2>
            </div>
            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>N08020</td>
                        </tr>
                        <tr class="t-row">
                            <td>W.Nr (DIN)</td>
                            <td>2.4660</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>B166 (Seamless Pipe), B167 (Tube), B168 (Plate, Sheet, Strip), B564 (Forgings)</td>
                        </tr>
                        <tr class="t-row">
                            <td>EN</td>
                            <td>NiCr20FeNb</td>
                        </tr>
                        <tr class="t-row">
                            <td>BS</td>
                            <td>NA 25</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS</td>
                            <td>SUS 820N</td>
                        </tr>
                        <tr class="t-row">
                            <td>GOST</td>
                            <td>ХН80МФ</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
            {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                        "@type": "Question",
                        "name": "What is Incoloy 020 and what makes it unique?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Incoloy 020, also known as Alloy 20, is a nickel-iron-chromium alloy specifically designed to resist sulfuric acid and other aggressive chemical environments. With the addition of copper and molybdenum, it provides excellent resistance to pitting, crevice corrosion, and chloride-induced stress corrosion cracking, making it a preferred material for industries handling highly corrosive media."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "What are the key properties of Incoloy 020 alloy?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Incoloy 020 exhibits outstanding corrosion resistance, strong mechanical properties, and excellent workability. It maintains resistance even after welding and delivers superior protection against sulfuric acid, nitric acid, chlorides, and mixed chemical environments. Its tensile strength can reach up to 149 ksi, with excellent ductility and hardness, ensuring durability and long service life in critical applications."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "Where is Incoloy 020 commonly used?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Incoloy 020 is widely used in the chemical processing industry for heat exchangers, reactors, piping, and storage tanks handling strong acids. It is also utilized in pharmaceutical and food processing industries, oil and gas facilities, marine environments, pulp and paper plants, pollution control systems, acid recovery units, and power generation equipment, where resistance to acidic and chloride rich environments is essential."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "What types of Incoloy 020 products are available?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "MOKSH TUBES & FITTINGS LLP supplies Incoloy 020 in multiple forms including seamless and welded pipes, tubes, sheets, plates, coils, bars, fittings, flanges, fasteners, wire mesh, and custom fabricated components. All products comply with ASTM, ASME, and international standards to ensure high performance, reliability, and compatibility with demanding industrial requirements."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 020 materials?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "MOKSH TUBES & FITTINGS LLP is a trusted global supplier of Incoloy 020, offering a wide inventory, quick delivery, and custom machining solutions. With deep expertise in nickel-based and corrosion-resistant alloys, the company ensures ISO certified quality assurance, competitive pricing, and full compliance with international standards, making it a reliable partner for industries that demand long-lasting corrosion resistance and operational safety."
                        }
                    }
                ]
            }

        @endverbatim
    </script>
@endsection


