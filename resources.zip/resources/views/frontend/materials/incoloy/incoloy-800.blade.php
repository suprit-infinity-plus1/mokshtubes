@extends('layouts.master')

@section('title', 'Incoloy 800 | High-Temperature Strength & Oxidation Shield')
@section('meta_description',
    'Incoloy 800 offers remarkable stability and corrosion resistance at high heat—ideal for
    furnace equipment, heat exchangers, and industrial systems.')
@section('meta_keywords',
    'Incoloy 800, Incoloy 800 Pipes, Incoloy 800 Tubes, Incoloy 800 Fittings, Heat Resistant
    Incoloy 800, High Temperature Incoloy 800, Oxidation Resistant Incoloy 800, Furnace Equipment Incoloy 800, Heat
    Exchanger Incoloy 800, Industrial Incoloy 800 Alloy')
@section('og_image', asset('assets/images/incoloy/incoloy-800.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area" style="background-image: url(/assets/images/incoloy/incoloy-800.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Incoloy 800 <br> High Temperature Strength & Resistance</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        INCOLOY® 800 (UNS N08800) is a nickel-iron-chromium alloy known for excellent resistance to
                        oxidation and carburization at elevated temperatures. It offers high strength, good corrosion
                        resistance, and long-term stability in chemical and industrial environments.

                        <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview"  class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To incoloy 800 / Alloy 800 / UNS N08800 </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/incoloy/incoloy-800.webp') }}" alt="Inconel 800"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> is a <a
                                href="{{ route('materials.nickel-Based-Superalloys') }}">supplier</a>,
                            exporter, importer and stockist of a wide range of <a
                                href="{{ route('materials.incoloy') }}">INCOLOY 800</a> (UNS N08800) products including
                            <a href="{{ route('products.pipes-tubes') }}">Pipes & Tubes</a>, Pipe Fittings, Flanges,
                            Fasteners, Sheets & Plates, Coils, Wires, Round Bars,
                            Flat Bars, Angles, Channels, Welding Rods, Wire Mesh, and other Custom and Hard to Find <strong
                                class="text-black">
                                INCOLOY 800 </strong><a href="{{ route('products') }}">Products</a>.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black">INCOLOY 800</strong class="text-black"> is a nickel-iron-chromium
                            alloy designed for high temperature strength and excellent resistance to oxidation,
                            carburization, and sulfidation. The alloy retains its structural integrity at elevated
                            temperatures, making it ideal for heat exchangers, reformer tubes, superheaters, and nuclear
                            steam generator components.<strong class="text-black"> INCOLOY 800 </strong> shows good
                            corrosion resistance in many aqueous
                            environments, maintaining its mechanical strength even after prolonged exposure to high
                            temperatures.
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Incoloy 800 Datasheet</h3>
            <p class="mb-3">
                Get the complete Incoloy 800 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>INCOLOY 800 Specifications</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>INCOLOY® 800 / UNS N08800</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>Nickel-Iron-Chromium Alloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Chemical Composition</td>
                                    <td>
                                        Ni 30–35%, Fe 39.5–45%, Cr 19–23%,
                                        C ≤ 0.10%, Mn ≤ 1.5%, Si ≤ 1.0%
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>Annealed, Hot Rolled, Cold Drawn, Solution Treated</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Annealing, Stress Relieving, Solution Treatment</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Tensile, Hardness, Chemical, Corrosion, NDT on request</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2 (Mill Test Certificate available)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- col-lg-8 -->

            </div> <!-- row -->
        </div> <!-- container -->
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of Incoloy 800</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>INCOLOY® 800</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Nickel (Ni)</td>
                                    <td>30.0 – 35.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>19.0 – 23.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>39.5 min.</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>0.08 max.</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aluminum (Al)</td>
                                    <td>0.15 – 0.60</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Titanium (Ti)</td>
                                    <td>0.15 – 0.60</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Al + Ti</td>
                                    <td>0.30 – 1.20</td>
                                </tr>
                                <tr class="t-row">
                                    <td>ASTM Grain Size</td>
                                    <td>Special</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Technical Composition of Incoloy 800</h2>
            </div>
            <!-- Mechanical Properties Table -->
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <h3 class="text-center mb-3" style="color: #db7227;">Physical Properties of Incoloy 800
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial Units</th>
                                    <th>Metric Units</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.287 lb/in³</td>
                                    <td>7.94 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Range</td>
                                    <td>2475–2525 °F</td>
                                    <td>1357–1385 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat (32–212°F / 0–100°C)</td>
                                    <td>0.11 Btu/lb•°F</td>
                                    <td>460 J/kg•°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Permeability at 200 Oe (15.9 kA/m)</td>
                                    <td>1.014 (Annealed)</td>
                                    <td>1.009 (Hot-Rolled)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Curie Temperature</td>
                                    <td>-175 °F</td>
                                    <td>-115 °C</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Mechanical Properties Table -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color: #db7227;">Heat Treatment of INCOLOY® 800 (UNS N08800)
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Heat Treatment Process</th>
                                    <th>Temperature Range</th>
                                    <th>Cooling / Procedure</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Annealing</td>
                                    <td>1090 – 1150°C</td>
                                    <td>Furnace cool slowly</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Solution Treatment</td>
                                    <td>1038 – 1110°C</td>
                                    <td>Rapid water or air quench</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>870 – 950°C</td>
                                    <td>Hold 1–2 hours, then air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aging / Hardening (Optional)</td>
                                    <td>700 – 800°C</td>
                                    <td>Air cool</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Mechanical Properties of Incoloy 800</h2>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property / Condition</th>
                            <th>80°F (25°C)</th>
                            <th>800°F (425°C)</th>
                            <th>1000°F (540°C)</th>
                            <th>1200°F (650°C)</th>
                            <th>1300°F (705°C)</th>
                            <th>1400°F (760°C)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="t-row">
                            <td><strong>Tensile Strength (ksi) – Annealed</strong></td>
                            <td>138</td>
                            <td>120</td>
                            <td>119</td>
                            <td>110</td>
                            <td>97</td>
                            <td>66</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Tensile Strength (MPa) – Annealed</strong></td>
                            <td>952</td>
                            <td>827</td>
                            <td>821</td>
                            <td>758</td>
                            <td>669</td>
                            <td>455</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Yield Strength (ksi) – Annealed</strong></td>
                            <td>85.5</td>
                            <td>74.1</td>
                            <td>73.7</td>
                            <td>58.7</td>
                            <td>46.3</td>
                            <td>34.5</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Yield Strength (MPa) – Annealed</strong></td>
                            <td>590</td>
                            <td>511</td>
                            <td>508</td>
                            <td>405</td>
                            <td>319</td>
                            <td>238</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Hardness (BHN) – Annealed</strong></td>
                            <td>250</td>
                            <td>172</td>
                            <td>178</td>
                            <td>176</td>
                            <td>174</td>
                            <td>149</td>
                        </tr>

                        <tr class="t-row table-secondary text-center">
                            <td colspan="7"><strong>Hot-Rolled Condition</strong></td>
                        </tr>

                        <tr class="t-row">
                            <td><strong>Tensile Strength (ksi) – Hot Rolled</strong></td>
                            <td>198</td>
                            <td>170</td>
                            <td>161</td>
                            <td>145</td>
                            <td>120</td>
                            <td>91</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Tensile Strength (MPa) – Hot Rolled</strong></td>
                            <td>1365</td>
                            <td>1172</td>
                            <td>1110</td>
                            <td>1000</td>
                            <td>827</td>
                            <td>627</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Yield Strength (ksi) – Hot Rolled</strong></td>
                            <td>96.4</td>
                            <td>84.5</td>
                            <td>84.0</td>
                            <td>65.3</td>
                            <td>53.5</td>
                            <td>44.5</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Yield Strength (MPa) – Hot Rolled</strong></td>
                            <td>665</td>
                            <td>583</td>
                            <td>579</td>
                            <td>450</td>
                            <td>369</td>
                            <td>307</td>
                        </tr>
                        <tr class="t-row">
                            <td><strong>Hardness (BHN) – Hot Rolled</strong></td>
                            <td>445</td>
                            <td>359</td>
                            <td>361</td>
                            <td>333</td>
                            <td>323</td>
                            <td>284</td>
                        </tr>
                    </tbody>
                </table>
                {{-- <p class="mt-3 text-center">
                    After quenching & tempering, 1055 steel hardness can reach 45–55 HRC depending on cooling media.
                </p> --}}

            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5" id="available forms">
                <h2>Available Forms & Size Range</h2>
            </div>

            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6 text-center">
                        We supply Incoloy 800 in the following product forms and dimensions:
                    </p>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="p-4 bg-white rounded shadow-sm border-start border-4" style="border-color:#db7227;">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Product Form</th>
                                    <th>Size Range / Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Round Bars</td>
                                    <td>6 mm – 300 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Flat, Square &amp; Hex Bars</td>
                                    <td>Custom sizes up to 250 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sheets &amp; Plates</td>
                                    <td>1 mm – 100 mm (Width 500 – 2500 mm)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Coils &amp; Strips</td>
                                    <td>0.3 mm – 10 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Seamless &amp; Welded Pipes / Tubes</td>
                                    <td>OD 6 mm – 168 mm, WT 1 – 16 mm</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Forged Blocks, Rings, Bushings &amp; Components</td>
                                    <td>Custom per drawing</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Incoloy 800</h2>
            </div>

            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">INCOLOY 800 </strong>, (UNS N08800 / Werkstoff Nr. 1.4876) is a
                        high performance material designed for exceptional strength and resistance to oxidation and
                        carburization at elevated temperatures. Recognized by NACE MR0175 for oil and gas service, this
                        alloy is ideal for critical applications across power generation, petrochemical processing, nuclear
                        energy, and heat treatment industries.
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        We offer INCOLOY 800 in a wide range of product forms, including:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section  id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>High temperature strength and structural stability</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Excellent resistance to oxidation, carburization, and sulfidation</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Good corrosion resistance in aqueous environments</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Reliable performance under cyclic thermal conditions</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Excellent fabricability and weldability</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of INCOLOY 800</h2>
                <p class="text-center pb-3"><strong class="text-dark">INCOLOY 800</strong> is widely used in
                    high temperature industrial applications requiring exceptional resistance to oxidation, carburization,
                    and thermal fatigue. Its stability and strength under prolonged exposure to elevated temperatures make
                    it ideal for components exposed to harsh heat and chemical environments. Key application areas include:
                </p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>INCOLOY® 800 Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹1,100 – ₹1,800 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by size, OD, thickness, and condition)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is Incoloy 800 and what makes it special?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 800, also known as UNS N08800, is a nickel iron chromium alloy designed to
                                    deliver exceptional strength and stability at high temperatures. It offers outstanding
                                    resistance to oxidation, carburization, and sulfidation while retaining mechanical
                                    integrity under prolonged thermal exposure. This makes it highly reliable for
                                    applications such as heat exchangers, reformer tubes, superheaters, and nuclear steam
                                    generator components.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key properties of Incoloy 800 alloy?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 800 exhibits superior resistance to high-temperature oxidation and
                                    carburization, combined with good corrosion resistance in aqueous environments. It
                                    offers excellent structural stability, reliable performance under cyclic thermal
                                    conditions, and retains strength even after long service at elevated temperatures. The
                                    alloy also provides excellent weldability and fabricability, making it suitable for
                                    demanding industrial environments.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Where is Incoloy 800 commonly used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 800 is widely used across industries that demand long-term performance under
                                    extreme heat and corrosive conditions. Its applications include heat treatment
                                    equipment, petrochemical and refining systems, nuclear power generation, chemical
                                    processing plants, pulp and paper facilities, industrial ovens, kilns, gas turbines,
                                    heat recovery systems, and offshore or marine engineering where resistance to both heat
                                    and corrosion is critical.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What products are available in Incoloy 800?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    <a href="{{ route('index') }}">MOKSH TUBES & FITTINGS LLP</a> offers Incoloy 800 in a
                                    wide range of products including
                                    seamless and welded pipes, tubes, sheets, plates, coils, round bars, flat bars, pipe
                                    fittings, flanges, fasteners, welding rods, wire mesh, and custom-fabricated components.
                                    All products are manufactured to international standards such as ASTM and ASME, ensuring
                                    durability, reliability, and compliance for high-performance applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 800 materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, supplier, and exporter of Incoloy
                                    800 products with global reach and proven industry expertise. The company maintains a
                                    strong supplier network for premium raw materials, offers customized fabrication
                                    solutions, and ensures strict quality control as per international standards. With a
                                    focus on dependability, customer satisfaction, and competitive pricing, it is the
                                    preferred partner for industries requiring high-quality Incoloy 800 materials.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    For any inquiries or to request a quote, reach out to <strong>Moksh Tubes & Fittings LLP</strong> your
                    trusted partner for INCOLOY 800 products.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>N08800</td>
                        </tr>
                        <tr class="t-row">
                            <td>W.Nr (DIN)</td>
                            <td>2.4665</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>B407 (Bars, Rods), B408 (Pipe, Tube), B409 (Sheets, Plates, Coils)</td>
                        </tr>
                        <tr class="t-row">
                            <td>EN</td>
                            <td>NiFeCr Alloy</td>
                        </tr>
                        <tr class="t-row">
                            <td>BS</td>
                            <td>NA 22</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS</td>
                            <td>SUS 800</td>
                        </tr>
                        <tr class="t-row">
                            <td>GOST</td>
                            <td>ХН70ВМЮ</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
            @verbatim
            {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                        "@type": "Question",
                        "name": "What is Incoloy 800 and what makes it special?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Incoloy 800, also known as UNS N08800, is a nickel iron chromium alloy designed to deliver exceptional strength and stability at high temperatures. It offers outstanding resistance to oxidation, carburization, and sulfidation while retaining mechanical integrity under prolonged thermal exposure. This makes it highly reliable for applications such as heat exchangers, reformer tubes, superheaters, and nuclear steam generator components."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "What are the key properties of Incoloy 800 alloy?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Incoloy 800 exhibits superior resistance to high-temperature oxidation and carburization, combined with good corrosion resistance in aqueous environments. It offers excellent structural stability, reliable performance under cyclic thermal conditions, and retains strength even after long service at elevated temperatures. The alloy also provides excellent weldability and fabricability, making it suitable for demanding industrial environments."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "Where is Incoloy 800 commonly used?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "Incoloy 800 is widely used across industries that demand long-term performance under extreme heat and corrosive conditions. Its applications include heat treatment equipment, petrochemical and refining systems, nuclear power generation, chemical processing plants, pulp and paper facilities, industrial ovens, kilns, gas turbines, heat recovery systems, and offshore or marine engineering where resistance to both heat and corrosion is critical."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "What products are available in Incoloy 800?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "MOKSH TUBES & FITTINGS LLP offers Incoloy 800 in a wide range of products including seamless and welded pipes, tubes, sheets, plates, coils, round bars, flat bars, pipe fittings, flanges, fasteners, welding rods, wire mesh, and custom-fabricated components. All products are manufactured to international standards such as ASTM and ASME, ensuring durability, reliability, and compliance for high-performance applications."
                        }
                    },
                    {
                        "@type": "Question",
                        "name": "Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 800 materials?",
                        "acceptedAnswer": {
                            "@type": "Answer",
                            "text": "MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, supplier, and exporter of Incoloy 800 products with global reach and proven industry expertise. The company maintains a strong supplier network for premium raw materials, offers customized fabrication solutions, and ensures strict quality control as per international standards. With a focus on dependability, customer satisfaction, and competitive pricing, it is the preferred partner for industries requiring high-quality Incoloy 800 materials."
                        }
                    }
                ]
            }

        @endverbatim
    </script>
@endsection


