@extends('layouts.master')

@section('title', 'Incoloy 800H and 800HT | Enhanced Heat-Resistant Alloy')
@section('meta_description',
    'With superior creep and rupture strength, Incoloy 800H and 800HT thrives in petrochemical,
    heat treatment, and power generation applications.')
@section('meta_keywords',
    'Incoloy 800H, Incoloy 800HT, Incoloy 800H Pipes, Incoloy 800HT Pipes, Incoloy 800H Tubes,
    Incoloy 800HT Tubes, Incoloy 800H Fittings, Incoloy 800HT Fittings, Heat Resistant Incoloy 800H, Heat Resistant Incoloy
    800HT, High Temperature Incoloy 800H, High Temperature Incoloy 800HT, Creep Resistant Incoloy 800H, Creep Resistant
    Incoloy 800HT, Petrochemical Incoloy 800H, Power Generation Incoloy 800HT')
@section('og_image', asset('assets/images/incoloy/incoloy-800h_800ht.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area" style="background-image: url(/assets/images/incoloy/incoloy-800h_800ht.webp)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Incoloy 800H / 800HT <br> High Strength & Heat Resistance</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        INCOLOY® 800H / 800HT (UNS N08810 / N08811) is a high-temperature nickel-iron-chromium alloy
                        designed for excellent oxidation and corrosion resistance in elevated-temperature environments.
                        Known for its strength, creep resistance, and stability at high temperatures, it is widely used in
                        petrochemical, power generation, and chemical processing industries. Below is the complete datasheet
                        including composition, properties, heat treatment, and applications.</p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Incoloy 800H / 800HT / UNS N08810 /N08811</h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/incoloy/incoloy-800h_800ht.webp') }}" alt="incoloy-800h_800ht"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> INCOLOY 800H and 800HT</strong> are high-performance alloys designed
                            for superior strength and corrosion resistance in high-temperature environments. These alloys
                            are modifications of <a href="{{ route('materials.incoloy') }}">INCOLOY 800</a>, specifically
                            developed to improve creep and stress rupture
                            properties at elevated temperatures.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black">INCOLOY 800H</strong class="text-black"> (UNS N08810) and<strong
                                class="text-black"> 800HT</strong> (UNS
                            N08811) offer excellent resistance to oxidation, carburization, and sulfidation. Their enhanced
                            mechanical properties make them ideal for structural components exposed to long-term high-heat
                            conditions. With controlled carbon, <a
                                href="{{ route('materials.aluminium-Alloys') }}">aluminum</a>, and <a
                                href="{{ route('materials.titanium') }}">titanium</a> contents, these
                            alloys maintain their
                            strength and metallurgical stability even above 600°C (1110°F), making them a top choice in
                            heat-treating, petrochemical, and power generation sectors.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Incoloy 800H 800HT Datasheet</h3>
            <p class="mb-3">
                Get the complete Incoloy 800H 800HT datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>INCOLOY® 800H / 800HT Specifications (UNS N08810 / N08811)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>INCOLOY® 800H / 800HT / UNS N08810 / N08811</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>Nickel-Iron-Chromium High-Temperature Alloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Chemical Composition</td>
                                    <td>Ni 30–35%, Fe 39–45%, Cr 19–23%, C ≤ 0.10%, Mn ≤ 1%, Si ≤ 1%, Cu ≤ 0.5%, Al ≤ 0.5%,
                                        Ti ≤ 0.5%</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>Annealed, Hot Rolled, Solution Treated</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Annealing, Stress Relieving</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Tensile, Hardness, Chemical, Corrosion, NDT on request</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2 (Mill Test Certificate available)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of INCOLOY® 800H / 800HT</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>800H</th>
                                    <th>800HT</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Nickel (Ni)</td>
                                    <td>30.0 – 35.0</td>
                                    <td>30.0 – 35.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>19.0 – 23.0</td>
                                    <td>19.0 – 23.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>39.5 min.</td>
                                    <td>39.5 min.</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>0.05 – 0.10</td>
                                    <td>0.06 – 0.10</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aluminum (Al)</td>
                                    <td>0.15 – 0.60</td>
                                    <td>0.25 – 0.60</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Titanium (Ti)</td>
                                    <td>0.15 – 0.60</td>
                                    <td>0.25 – 0.60</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Al + Ti</td>
                                    <td>0.30 – 1.20</td>
                                    <td>0.85 – 1.20</td>
                                </tr>
                                <tr class="t-row">
                                    <td>ASTM Grain Size</td>
                                    <td>5 or coarser</td>
                                    <td>5 or coarser</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
           <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Technical Composition of Incoloy 800H-800HT</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                     <h3 class="text-center mb-3" style="color: #db7227;">Physical Properties of INCOLOY® 800H / 800HT
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial Units</th>
                                    <th>Metric Units</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.287 lb/in³</td>
                                    <td>7.94 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Range</td>
                                    <td>2475–2525 °F</td>
                                    <td>1357–1385 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat</td>
                                    <td>0.11 Btu/lb·°F</td>
                                    <td>460 J/kg·°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Permeability</td>
                                    <td>1.014 (Annealed)</td>
                                    <td>1.009 (Hot Rolled)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Curie Temperature</td>
                                    <td>–175 °F</td>
                                    <td>–115 °C</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color: #db7227;">Heat Treatment of INCOLOY® 800H / 800HT (UNS N08810 / N08811)
                    </h4>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Heat Treatment Process</th>
                                    <th>Temperature Range</th>
                                    <th>Cooling / Procedure</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Annealing / Solution Treatment</td>
                                    <td>1038–1093°C</td>
                                    <td>Furnace or air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>870–900°C</td>
                                    <td>Hold 1–2 hours, air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aging / Hardening</td>
                                    <td>700–800°C</td>
                                    <td>Air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hot Working Prep</td>
                                    <td>1038–1093°C</td>
                                    <td>Uniform heating before forming</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties of Incoloy 800H / 800HT (Annealed)
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Temperature</th>
                            <th>Tensile Strength (MPa)</th>
                            <th>Yield Strength (MPa)</th>
                            <th>Hardness (BHN)</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>25 °C (80 °F)</td>
                            <td>379</td>
                            <td>207</td>
                            <td>145</td>
                        </tr>
                        <tr class="t-row">
                            <td>425 °C (800 °F)</td>
                            <td>~207</td>
                            <td>~124</td>
                            <td>~100</td>
                        </tr>
                        <tr class="t-row">
                            <td>540 °C (1000 °F)</td>
                            <td>~172</td>
                            <td>~103</td>
                            <td>~90</td>
                        </tr>
                        <tr class="t-row">
                            <td>650 °C (1200 °F)</td>
                            <td>~138</td>
                            <td>~83</td>
                            <td>~85</td>
                        </tr>
                        <tr class="t-row">
                            <td>705 °C (1300 °F)</td>
                            <td>~124</td>
                            <td>~69</td>
                            <td>~80</td>
                        </tr>
                        <tr class="t-row">
                            <td>760 °C (1400 °F)</td>
                            <td>~117</td>
                            <td>~62</td>
                            <td>~75</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5">
                <h2>Available Forms & Size Range</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark text-center">
                            <tr class="t-row">
                                <th>Product Form</th>
                                <th>Size Range / Description</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr class="t-row">
                                <td>Round Bars</td>
                                <td>10 mm – 350 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Flat, Square & Hex Bars</td>
                                <td>Custom up to 250 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Sheets & Plates</td>
                                <td>1.5 – 100 mm (600–2500 mm width)</td>
                            </tr>
                            <tr class="t-row">
                                <td>Coils & Strips</td>
                                <td>0.3 – 8 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Seamless & Welded Pipes/Tubes</td>
                                <td>OD 6–273 mm, WT 1–25 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Forged Components</td>
                                <td>Custom per drawing</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section  id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Incoloy 800H / 800HT</h2>
            </div>

            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Incoloy 800H / 800HT</strong>, are high-performance, high-temperature
                        austenitic alloys designed for exceptional structural stability and oxidation resistance in
                        demanding environments. These alloys, known for their superior creep and stress rupture strength,
                        are widely used in industries such as petrochemical processing, power generation, and heat
                        treatment. Supplied in a wide variety of product forms, INCOLOY® 800H/800HT meets numerous
                        international standards and specifications, making them suitable for critical applications in
                        extreme service conditions.
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        This alloy meets several recognized industry standards, including:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses"  class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Excellent strength and creep resistance at elevated temperatures</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Outstanding resistance to oxidation, carburization, and sulfidation</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Stable metallurgy and corrosion resistance in high-temperature chemical exposure</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Good weldability and formability</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Long service life in extreme industrial environments</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section  id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of INCOLOY 800H / 800HT</h2>
                <p class="text-center pb-3"><strong class="text-dark">INCOLOY 800H / 800HT</strong> is a high-temperature
                    alloy widely used across industries where long-term strength, metallurgical stability, and resistance to
                    oxidation and carburization are critical. Designed for elevated-temperature service, these alloys are
                    ideal for structural and pressure-bound components exposed to prolonged thermal exposure and corrosive
                    gases.
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>INCOLOY® 800H / 800HT Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹950 – ₹1,500 per kg
            </p>
            <p class="text-center mb-2">
                ( Price varies by size, OD, thickness, and condition)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section  id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are Incoloy 800H and 800HT alloys?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 800H (UNS N08810) and Incoloy 800HT (UNS N08811) are high-performance
                                    nickel iron chromium alloys specifically developed to enhance creep strength and stress
                                    rupture resistance in high-temperature environments. They are modified versions of
                                    Incoloy 800, engineered with controlled carbon, aluminum, and titanium levels to deliver
                                    excellent metallurgical stability and long-term strength above 600°C, making them ideal
                                    for extreme industrial applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key properties of Incoloy 800H and 800HT?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Both Incoloy 800H and 800HT offer excellent resistance to oxidation, carburization, and
                                    sulfidation under prolonged exposure to elevated temperatures. These alloys provide
                                    superior creep resistance, reliable structural integrity, and stable mechanical
                                    properties in aggressive chemical and thermal environments. Their good weldability and
                                    formability further increase their suitability for demanding high-temperature
                                    applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Where are Incoloy 800H and 800HT commonly used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 800H and 800HT are widely used across industries requiring long-term strength
                                    and corrosion resistance at elevated temperatures. Typical applications include heat
                                    treatment equipment, petrochemical furnaces, reformer tubes, superheaters, boiler
                                    components, nuclear reactor supports, chemical processing plants, industrial kilns, gas
                                    turbines, and aerospace combustion systems. Their durability makes them a preferred
                                    choice for critical service conditions.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What product forms are available in Incoloy 800H and 800HT?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP supplies Incoloy 800H and 800HT in a wide variety of product
                                    forms, including seamless and welded pipes, tubes, sheets, plates, coils, bars, pipe
                                    fittings, flanges, fasteners, and custom-fabricated components. All products are
                                    manufactured to international standards such as ASTM and ASME, ensuring quality,
                                    consistency, and performance in high-pressure, high temperature systems.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 800H and 800HT materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, supplier, and exporter of Incoloy
                                    800H and 800HT products, offering ISO and ASTM-compliant materials across global
                                    markets. With extensive inventory, fast delivery, and customized solutions, the company
                                    ensures top quality products tailored to critical engineering applications. Its
                                    expertise in high performance nickel alloys, combined with strong customer support,
                                    makes it the preferred choice for industries worldwide.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    <strong>Moksh Tubes & Fittings LLP</strong> Your trusted partner in high-performance alloy solutions.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>N08810 / N08811</td>
                        </tr>
                        <tr class="t-row">
                            <td>DIN (W.Nr)</td>
                            <td>2.4858 / 2.4860</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>B408, B407</td>
                        </tr>
                        <tr class="t-row">
                            <td>EN</td>
                            <td>NiCr20Fe</td>
                        </tr>
                        <tr class="t-row">
                            <td>BS</td>
                            <td>NA 21</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS</td>
                            <td>SUS 800H / 800HT</td>
                        </tr>
                        <tr class="t-row">
                            <td>GOST</td>
                            <td>ХН80МФ</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
            {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                "@type": "Question",
                "name": "What are Incoloy 800H and 800HT alloys?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Incoloy 800H (UNS N08810) and Incoloy 800HT (UNS N08811) are high-performance nickel iron chromium alloys specifically developed to enhance creep strength and stress rupture resistance in high-temperature environments. They are modified versions of Incoloy 800, engineered with controlled carbon, aluminum, and titanium levels to deliver excellent metallurgical stability and long-term strength above 600°C, making them ideal for extreme industrial applications."
                }
                },
                {
                "@type": "Question",
                "name": "What are the key properties of Incoloy 800H and 800HT?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Both Incoloy 800H and 800HT offer excellent resistance to oxidation, carburization, and sulfidation under prolonged exposure to elevated temperatures. These alloys provide superior creep resistance, reliable structural integrity, and stable mechanical properties in aggressive chemical and thermal environments. Their good weldability and formability further increase their suitability for demanding high-temperature applications."
                }
                },
                {
                "@type": "Question",
                "name": "Where are Incoloy 800H and 800HT commonly used?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Incoloy 800H and 800HT are widely used across industries requiring long-term strength and corrosion resistance at elevated temperatures. Typical applications include heat treatment equipment, petrochemical furnaces, reformer tubes, superheaters, boiler components, nuclear reactor supports, chemical processing plants, industrial kilns, gas turbines, and aerospace combustion systems. Their durability makes them a preferred choice for critical service conditions."
                }
                },
                {
                "@type": "Question",
                "name": "What product forms are available in Incoloy 800H and 800HT?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MOKSH TUBES & FITTINGS LLP supplies Incoloy 800H and 800HT in a wide variety of product forms, including seamless and welded pipes, tubes, sheets, plates, coils, bars, pipe fittings, flanges, fasteners, and custom-fabricated components. All products are manufactured to international standards such as ASTM and ASME, ensuring quality, consistency, and performance in high-pressure, high temperature systems."
                }
                },
                {
                "@type": "Question",
                "name": "Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 800H and 800HT materials?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MOKSH TUBES & FITTINGS LLP is a trusted manufacturer, supplier, and exporter of Incoloy 800H and 800HT products, offering ISO and ASTM-compliant materials across global markets. With extensive inventory, fast delivery, and customized solutions, the company ensures top quality products tailored to critical engineering applications. Its expertise in high performance nickel alloys, combined with strong customer support, makes it the preferred choice for industries worldwide."
                }
                }
            ]
            }

        @endverbatim
    </script>
@endsection


