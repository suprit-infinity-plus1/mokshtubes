@extends('layouts.master')

@section('title', ' Incoloy 925 | Superior Strength & Sour Gas Protection')
@section('meta_description',
    'Incoloy 925 combines high strength with outstanding corrosion resistance—perfect for oil &
    gas well parts and demanding marine environments.')
@section('meta_keywords',
    'Incoloy 925, Incoloy 925 Pipes, Incoloy 925 Tubes, Incoloy 925 Fittings, High Strength
    Incoloy 925, Corrosion Resistant Incoloy 925, Sour Gas Resistant Incoloy 925, Oil & Gas Industry Incoloy 925, Marine
    Environment Incoloy 925, Industrial Incoloy 925 Alloy')
@section('canonical', url('materials/incoloy/incoloy-925'))
@section('og_image', asset('assets/images/incoloy/incoloy-925.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area" style="background-image: url(/assets/images/incoloy/incoloy-925.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Incoloy 925 <br> High Strength & Corrosion Resistant Alloy</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        INCOLOY® 925 (UNS N09925) is a nickel-iron-cobalt alloy designed for outstanding corrosion
                        resistance in both oxidizing and reducing environments, including acidic and chloride-containing
                        media. Known for its high strength, excellent resistance to stress corrosion cracking, and
                        durability, it is widely used in chemical processing, marine, and pharmaceutical industries. Below
                        is the complete datasheet including composition, properties, heat treatment, and applications.

                        <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Incoloy 925 / Alloy 925 / UNS N09925 </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/incoloy/incoloy-925.webp') }}" alt="incoloy-925"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> <a href="{{ route('index') }}">MOKSH TUBES & FITTINGS
                                    LLP</a></strong> is a trusted global
                            manufacturer, supplier, exporter, importer, and stockist of high quality INCOLOY 925 (UNS
                            N09925) <a href="{{ route('products') }}">products</a>. We offer a complete portfolio including
                            <a href="{{ route('products.pipes-tubes') }}">Pipes & Tubes</a>, Pipe Fittings, Flanges,
                            Fasteners, Sheets & Plates, Coils, Wires, Round Bars, Flat Bars, Welding Rods, Wire Mesh, and
                            <a href="{{ route('materials.nickel-Based-Superalloys') }}">nickel</a> other Custom Fabricated
                            Components crafted from this versatile alloy.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black">INCOLOY 925</strong class="text-black"> is a precipitation-hardenable
                            <a href="{{ route('materials.nickel-Based-Superalloys') }}">nickel</a> iron chromium alloy
                            engineered for superior strength and resistance in extreme
                            environments. Enriched with molybdenum, copper, <a
                                href="{{ route('materials.titanium') }}">titanium</a>, and <a
                                href="{{ route('materials.aluminium-Alloys') }}">aluminum</a>, it delivers excellent
                            protection against stress corrosion cracking, pitting, and crevice corrosion—especially in harsh
                            sour gas (H2S) conditions. This alloy combines toughness with excellent mechanical properties,
                            making it ideal for use in offshore oil platforms, deep wells, chemical processing systems, and
                            marine applications.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Incoloy 925 Datasheet</h3>
            <p class="mb-3">
                Get the complete Incoloy 925 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>INCOLOY® 925 Specifications (UNS N09925)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>INCOLOY® 925 / UNS N09925</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>Nickel-Iron-Cobalt Corrosion-Resistant Alloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Chemical Composition</td>
                                    <td>Ni 42%, Fe 21%, Co 17%, Cr 9%, Mo 2.5%, Cu 1%, Ti 0.5%, C ≤ 0.05%, Mn ≤ 1%, Si ≤ 1%
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>Annealed, Cold Drawn, Solution Treated</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Annealing, Stress Relieving</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Tensile, Hardness, Chemical, Corrosion, NDT on request</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of INCOLOY® 925</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Nickel (Ni)</td>
                                    <td>42.0 – 46.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>19.5 – 23.5</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>Balance</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Molybdenum (Mo)</td>
                                    <td>2.5 – 3.5</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Copper (Cu)</td>
                                    <td>1.5 – 3.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Titanium (Ti)</td>
                                    <td>1.9 – 2.4</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aluminum (Al)</td>
                                    <td>0.1 – 0.5</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese (Mn)</td>
                                    <td>1.0 max</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon (Si)</td>
                                    <td>0.5 max</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>0.03 max</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sulfur (S)</td>
                                    <td>0.01 max</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">Technical Composition  of INCOLOY® 925</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <h3 class="text-center mb-3" style="color: #db7227;">Physical Properties of INCOLOY® 925
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial Units</th>
                                    <th>Metric Units</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.292 lb/in³</td>
                                    <td>8.08 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Range</td>
                                    <td>2392–2490 °F</td>
                                    <td>1311–1366 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Electrical Resistivity</td>
                                    <td>701 ohm·cir mil/ft</td>
                                    <td>1.17 µΩ·m</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Permeability</td>
                                    <td>1.001</td>
                                    <td>—</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Heat Treatment -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color:#db7227;">
                        Heat Treatment of INCOLOY® 925 (UNS N09925)
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Heat Treatment Process</th>
                                    <th>Temperature Range</th>
                                    <th>Cooling / Procedure</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Annealing</td>
                                    <td>1050–1150°C</td>
                                    <td>Furnace cool slowly</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Solution Treatment</td>
                                    <td>1050–1100°C</td>
                                    <td>Water quench</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>650–750°C</td>
                                    <td>Hold 1–2 hours, air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Cold Working / Hardening</td>
                                    <td>600–700°C</td>
                                    <td>Air cool</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties of INCOLOY® 925
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Typical Values</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>685 – 1189 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>271 – 832 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation</td>
                            <td>18 – 56%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Reduction of Area</td>
                            <td>25 – 76%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Impact Strength</td>
                            <td>35 ft·lbf (4.85 kgf·m)</td>
                        </tr>
                        <tr class="t-row">
                            <td>Hardness</td>
                            <td>Rockwell B to C (26–38 HRC)</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5">
                <h2>Available Forms & Size Range</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark text-center">
                            <tr class="t-row">
                                <th>Product Form</th>
                                <th>Size Range / Description</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr class="t-row">
                                <td>Round Bars</td>
                                <td>6 mm – 300 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Flat, Square & Hex Bars</td>
                                <td>Custom up to 200 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Sheets & Plates</td>
                                <td>1 – 100 mm (500–2500 mm width)</td>
                            </tr>
                            <tr class="t-row">
                                <td>Coils & Strips</td>
                                <td>0.3 – 6 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Pipes & Tubes</td>
                                <td>OD 6–168 mm, WT 1–16 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Forged Components</td>
                                <td>Custom per drawing</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products"  class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Incoloy 925</h2>
            </div>

            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">INCOLOY 925 </strong>, is designated as UNS N09925. Designations and
                        specifications for the product include NACE MR-01-75, ASME Boiler and Pressure Vessel Code Case 2218
                        Section VIII Division 1, and Special Metals Corporation internal specification HA 46. Alloy 925 is
                        available as tube, round bar, flat bar and forging stock.
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        This alloy meets several recognized industry standards, including:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses"   class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Superior resistance to chloride-induced stress corrosion cracking</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Excellent pitting and crevice corrosion resistance in sour environments</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>High strength and durability under extreme pressure and temperature</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Good weldability and formability for complex fabrications</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Long service life with reduced maintenance in aggressive service conditions</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of INCOLOY 925</h2>
                <p class="text-center pb-3"><strong class="text-dark">INCOLOY 925</strong> is widely utilized in severe
                    service environments where corrosion, pressure, and temperature are constant challenges. Key
                    applications include:
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>INCOLOY® 925 Price per kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹1,200 – ₹2,000 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is Incoloy 925 and why is it used in critical industries?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 925 (UNS N09925) is a precipitation-hardenable nickel iron chromium alloy
                                    enhanced with molybdenum, copper, titanium, and aluminum. It is designed to deliver
                                    exceptional resistance to stress corrosion cracking, pitting, and crevice corrosion,
                                    particularly in sour gas (H2S) environments. With a balance of high strength and
                                    corrosion resistance, Incoloy 925 is a preferred material for demanding industries such
                                    as oil and gas, chemical processing, power generation, and marine engineering.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the main properties of Incoloy 925?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 925 offers a unique combination of mechanical strength and corrosion resistance,
                                    performing reliably under extreme pressures and high temperatures. It provides
                                    outstanding resistance to chloride-induced stress corrosion cracking and maintains
                                    durability in aggressive sour gas and seawater environments. Along with its superior
                                    toughness, the alloy offers good weldability, formability, and long service life, making
                                    it ideal for harsh industrial applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the common applications of Incoloy 925?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Incoloy 925 is widely used in industries that demand both strength and corrosion
                                    resistance. In the oil and gas sector, it is utilized for downhole tubing, hangers,
                                    valves, and other sour service equipment. In chemical processing, it is found in heat
                                    exchangers, tanks, and piping systems exposed to acidic and chloride rich fluids. It is
                                    also deployed in marine engineering for seawater handling equipment, in desalination
                                    plants for saltwater filtration systems, and in power generation for turbine and piping
                                    components.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What product forms are available in Incoloy 925?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP manufactures and supplies Incoloy 925 in a comprehensive
                                    range of forms, including seamless and welded pipes, tubes, sheets, plates, coils, bars,
                                    welding rods, wire mesh, flanges, fasteners, pipe fittings, and custom-fabricated
                                    components. All products are crafted to meet international standards such as NACE
                                    MR-01-75 and ASME specifications, ensuring quality and reliability in mission critical
                                    operations.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 925 products?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted global supplier of Incoloy 925 materials, with
                                    expertise in manufacturing precision engineered products for industries such as oil and
                                    gas, chemical processing, and marine applications. By sourcing premium grade raw
                                    materials, offering fast turnaround times, and providing custom fabrication support, the
                                    company ensures superior product performance and customer satisfaction. Their strong
                                    quality assurance and global track record make them a reliable partner for Incoloy 925
                                    solutions.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section  id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    <strong>Moksh Tubes & Fittings LLP</strong> Your trusted partner for high-performance alloy solutions.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>N09925</td>
                        </tr>
                        <tr class="t-row">
                            <td>DIN (W.Nr)</td>
                            <td>2.4856</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>B443, B444, B446</td>
                        </tr>
                        <tr class="t-row">
                            <td>EN</td>
                            <td>NiFeCoCrMo Alloy</td>
                        </tr>
                        <tr class="t-row">
                            <td>BS</td>
                            <td>NA 25</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS</td>
                            <td>SUS 925</td>
                        </tr>
                        <tr class="t-row">
                            <td>GOST</td>
                            <td>ХН60ВМФ</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
            {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                "@type": "Question",
                "name": "What is Incoloy 925 and why is it used in critical industries?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Incoloy 925 (UNS N09925) is a precipitation-hardenable nickel iron chromium alloy enhanced with molybdenum, copper, titanium, and aluminum. It is designed to deliver exceptional resistance to stress corrosion cracking, pitting, and crevice corrosion, particularly in sour gas (H2S) environments. With a balance of high strength and corrosion resistance, Incoloy 925 is a preferred material for demanding industries such as oil and gas, chemical processing, power generation, and marine engineering."
                }
                },
                {
                "@type": "Question",
                "name": "What are the main properties of Incoloy 925?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Incoloy 925 offers a unique combination of mechanical strength and corrosion resistance, performing reliably under extreme pressures and high temperatures. It provides outstanding resistance to chloride-induced stress corrosion cracking and maintains durability in aggressive sour gas and seawater environments. Along with its superior toughness, the alloy offers good weldability, formability, and long service life, making it ideal for harsh industrial applications."
                }
                },
                {
                "@type": "Question",
                "name": "What are the common applications of Incoloy 925?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Incoloy 925 is widely used in industries that demand both strength and corrosion resistance. In the oil and gas sector, it is utilized for downhole tubing, hangers, valves, and other sour service equipment. In chemical processing, it is found in heat exchangers, tanks, and piping systems exposed to acidic and chloride rich fluids. It is also deployed in marine engineering for seawater handling equipment, in desalination plants for saltwater filtration systems, and in power generation for turbine and piping components."
                }
                },
                {
                "@type": "Question",
                "name": "What product forms are available in Incoloy 925?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MOKSH TUBES & FITTINGS LLP manufactures and supplies Incoloy 925 in a comprehensive range of forms, including seamless and welded pipes, tubes, sheets, plates, coils, bars, welding rods, wire mesh, flanges, fasteners, pipe fittings, and custom-fabricated components. All products are crafted to meet international standards such as NACE MR-01-75 and ASME specifications, ensuring quality and reliability in mission critical operations."
                }
                },
                {
                "@type": "Question",
                "name": "Why choose MOKSH TUBES & FITTINGS LLP for Incoloy 925 products?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MOKSH TUBES & FITTINGS LLP is a trusted global supplier of Incoloy 925 materials, with expertise in manufacturing precision engineered products for industries such as oil and gas, chemical processing, and marine applications. By sourcing premium grade raw materials, offering fast turnaround times, and providing custom fabrication support, the company ensures superior product performance and customer satisfaction. Their strong quality assurance and global track record make them a reliable partner for Incoloy 925 solutions."
                }
                }
            ]
            }

        @endverbatim
    </script>
@endsection


