@extends('layouts.master')

@section('title', 'Zirconium 705 | High-Performance Zirconium Alloy')
@section('meta_description',
    'Zirconium 705 alloy offering exceptional corrosion resistance and strength for demanding
    nuclear and chemical processes.')
@section('meta_keywords',
    'Zirconium 705, High Performance Zirconium, Corrosion Resistant Zirconium, Zirconium 705
    Pipes, Zirconium 705 Tubes, Zirconium 705 Sheets, Chemical Processing Zirconium, Nuclear Industry Zirconium, Industrial
    Zirconium')
@section('og_image', asset('assets/images/zirconium/zirconium-705.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area" style="background-image: url(/assets/images/zirconium/zirconium-705.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Zirconium 705 <br> High-Performance & Corrosion Resistant Alloy</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        high-strength zirconium alloy known for its excellent corrosion resistance, superior mechanical
                        strength, and outstanding performance in aggressive chemical and extreme corrosion environments.
                        Below is the complete datasheet including chemical composition, mechanical properties, physical
                        properties, heat treatment, and applications.

                    </p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Zirconium 705 / UNS R60705
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/zirconium/zirconium-705.webp') }}" alt="Zirconium 705"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> we specialize in manufacturing,
                            supplying, exporting, importing, and stocking a wide range of<strong class="text-black">
                                Zirconium 705 (UNS R60705)
                                <a href="{{ route('products') }}">products</a></strong>. Our comprehensive lineup includes
                            Pipes & Tubes, Fittings, Flanges, Fasteners, Sheets,
                            Plates, Coils, Wires, Bars, Welding Rods, and custom-built components—made for performance in
                            demanding environments.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black"><a href="{{ route('materials.zirconium') }}">Zirconium
                                    705</a></strong> is a high-purity zirconium alloy noted for its remarkable resistance to
                            strong acids, alkalis, and hot water environments. It combines excellent ductility, weldability,
                            and mechanical strength, making it ideal for applications where corrosion resistance and
                            material purity are critical.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Zicrnium 705 Datasheet</h3>
            <p class="mb-3">
                Get the complete Zicrnium 705 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>Specifications of Zirconium 705 (UNS R60705)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>Zirconium 705 / UNS R60705</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>High-Purity Zirconium Alloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Standards</td>
                                    <td>ASTM B551, ASTM B523, ASME SB-551</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Forms</td>
                                    <td>Pipes, Tubes, Plates, Sheets, Coils, Rods, Bars, Wire, Fittings, Flanges, Fasteners
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>PMI, Mechanical, Chemical, Hardness</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of Zirconium 705 (UNS R60705)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Max. Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Zirconium (Zr)</td>
                                    <td>≥ 99.05</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hafnium (Hf)</td>
                                    <td>≤ 0.15</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Oxygen (O)</td>
                                    <td>≤ 0.17</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Nitrogen (N)</td>
                                    <td>≤ 0.025</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hydrogen (H)</td>
                                    <td>≤ 0.005</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>≤ 0.03</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>≤ 0.15</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Tin (Sn)</td>
                                    <td>≤ 0.03</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            Zirconium 705 performance comes from controlled alloying and extremely low oxygen,
                            nitrogen, and hydrogen levels.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">Technical Composition of Zirconium 705</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                      <h3 class="text-center mb-3" style="color: #db7227;">Physical Properties of Zirconium 705
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial</th>
                                    <th>Metric</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.236 lb/in³</td>
                                    <td>6.51 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Range</td>
                                    <td>3370 – 3390 °F</td>
                                    <td>1855 – 1865 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat</td>
                                    <td>0.064 Btu/lb·°F</td>
                                    <td>270 J/kg·°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Permeability (200 Oe)</td>
                                    <td>~1.01</td>
                                    <td>—</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Character</td>
                                    <td>Non-magnetic</td>
                                    <td>Non-magnetic</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Heat Treatment -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color:#db7227;">
                        Heat Treatment of Zirconium 705
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Process</th>
                                    <th>Temperature Range</th>
                                    <th>Purpose</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>540 – 650 °C</td>
                                    <td>Remove residual stresses</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Annealing</td>
                                    <td>700 – 900 °C</td>
                                    <td>Improve ductility & corrosion resistance</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Vacuum Annealing</td>
                                    <td>—</td>
                                    <td>Ultra-high purity applications</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Recrystallization Annealing</td>
                                    <td>850 – 950 °C</td>
                                    <td>Restore properties after cold work</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            📌 Proper argon shielding is critical during heat treatment to prevent contamination.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties of Zirconium 705
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Product Form</th>
                            <th>Tensile Strength (MPa)</th>
                            <th>Yield Strength (MPa)</th>
                            <th>Elongation (%)</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tubing (Annealed)</td>
                            <td>793</td>
                            <td>469</td>
                            <td>34</td>
                        </tr>
                        <tr class="t-row">
                            <td>Tubing (Cold Drawn)</td>
                            <td>1035</td>
                            <td>931</td>
                            <td>14</td>
                        </tr>
                        <tr class="t-row">
                            <td>Bar (Annealed)</td>
                            <td>724</td>
                            <td>345</td>
                            <td>42</td>
                        </tr>
                        <tr class="t-row">
                            <td>Plate (Annealed)</td>
                            <td>690</td>
                            <td>358</td>
                            <td>42</td>
                        </tr>
                        <tr class="t-row">
                            <td>Sheet (Annealed)</td>
                            <td>793</td>
                            <td>448</td>
                            <td>37</td>
                        </tr>
                    </tbody>
                </table>

                <p class="text-center mt-3">
                    Zirconium 705 delivers exceptional strength while maintaining ductility — rare among reactive metals.
                </p>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5">
                <h2>Available Forms & Size Range – Zirconium 705</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <ul class="list-unstyled text-center">
                        <li>✔ Seamless & Welded Pipes</li>
                        <li>✔ Heat Exchanger, Boiler & U-Bend Tubes</li>
                        <li>✔ Capillary & Coiled Tubing</li>
                        <li>✔ Sheets, Plates & Coils</li>
                        <li>✔ Strips & Foils</li>
                        <li>✔ Round, Flat & Hex Bars</li>
                        <li>✔ Wire & Welding Rods</li>
                        <li>✔ Pipe Fittings & Flanges (All ASME Types)</li>
                        <li>✔ Fasteners & Custom-Manufactured Components</li>
                    </ul>

                    <p class="text-center mt-3">
                        All products comply with ASTM B551 / B523 and ASME SB-551 specifications.
                    </p>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Zirconium 705</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Zirconium 705</strong> is stocked or fabricated to your specifications in
                        the following formats:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Zirconium 705 products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Superior Corrosion Resistance – Stunning performance in acid and caustic environments</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>High Strength + Flexibility – Outstanding mechanical properties at room and moderate heat</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Highly Fabricable – Easily welded, formed, and machined</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Ultra‑Clean Purity – Ideal for pharmaceutical, semiconductor, and biotech systems</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Non‑Magnetic & Biocompatible – Great for medical and cleanroom processes</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Low Neutron Cross‑Section – Preferred in nuclear applications</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Zirconium 705</h2>
                <p class="text-center pb-3"><strong class="text-dark">Zirconium 705</strong> is the go-to alloy when
                    reliability and purity outweigh all other requirements:
                </p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>Zirconium 705 Price (India)</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹6,000 – ₹12,500 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is Zirconium 705 and where is it used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Zirconium 705 is a high purity zirconium alloy known for exceptional corrosion
                                    resistance in strong acids, alkalis, and hot water. It is widely applied in chemical
                                    processing, nuclear reactors, pharmaceuticals, marine systems, and medical devices where
                                    purity, durability, and mechanical strength are critical.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key properties of Zirconium 705?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Zirconium 705 provides high tensile and yield strength, excellent ductility, outstanding
                                    weldability, non magnetic behavior, and low neutron absorption. These characteristics
                                    make it ideal for nuclear, medical, and high-purity industrial applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Which Zirconium 705 products are available?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP supplies Zirconium 705 in a variety of forms including
                                    seamless and welded pipes, tubes, sheets, plates, coils, bars, flanges, fittings,
                                    fasteners, welding rods, and custom-fabricated components tailored to your project
                                    requirements.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>How resistant is Zirconium 705 to corrosion?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Zirconium 705 exhibits superior corrosion resistance in strong acids such as nitric and
                                    sulfuric, caustic solutions, seawater, and high purity water systems. Its chemical
                                    stability ensures reliability for long term industrial and marine applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for Zirconium 705?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    We specialize in high-purity zirconium alloys with ASTM/ASME certified manufacturing,
                                    access to globally sourced raw materials, and custom fabrication solutions. Our
                                    Zirconium 705 products ensure consistent quality, traceability, and dependable supply
                                    for demanding industrial projects.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    <strong>Moksh Tubes & Fittings LLP</strong> Let our team help you source exactly what you need, when you
                    need it.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
            {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                "@type": "Question",
                "name": "What is Zirconium 705 and where is it used?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Zirconium 705 is a high purity zirconium alloy known for exceptional corrosion resistance in strong acids, alkalis, and hot water. It is widely applied in chemical processing, nuclear reactors, pharmaceuticals, marine systems, and medical devices where purity, durability, and mechanical strength are critical."
                }
                },
                {
                "@type": "Question",
                "name": "What are the key properties of Zirconium 705?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Zirconium 705 provides high tensile and yield strength, excellent ductility, outstanding weldability, non magnetic behavior, and low neutron absorption. These characteristics make it ideal for nuclear, medical, and high-purity industrial applications."
                }
                },
                {
                "@type": "Question",
                "name": "Which Zirconium 705 products are available?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MOKSH TUBES & FITTINGS LLP supplies Zirconium 705 in a variety of forms including seamless and welded pipes, tubes, sheets, plates, coils, bars, flanges, fittings, fasteners, welding rods, and custom-fabricated components tailored to your project requirements."
                }
                },
                {
                "@type": "Question",
                "name": "How resistant is Zirconium 705 to corrosion?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Zirconium 705 exhibits superior corrosion resistance in strong acids such as nitric and sulfuric, caustic solutions, seawater, and high purity water systems. Its chemical stability ensures reliability for long term industrial and marine applications."
                }
                },
                {
                "@type": "Question",
                "name": "Why choose MOKSH TUBES & FITTINGS LLP for Zirconium 705?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "We specialize in high-purity zirconium alloys with ASTM/ASME certified manufacturing, access to globally sourced raw materials, and custom fabrication solutions. Our Zirconium 705 products ensure consistent quality, traceability, and dependable supply for demanding industrial projects."
                }
                }
            ]
            }

        @endverbatim
    </script>
@endsection


