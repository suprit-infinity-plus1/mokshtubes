@extends('layouts.master')

@section('title', 'Haynes Superalloys 160 - High Strength Heat Resistant')
@section('meta_description',
    'High-strength Haynes Alloy 160 for extreme heat resistance and corrosion protection.
    Available in various industry-grade forms.')
@section('meta_keywords',
    'Haynes Superalloys 160, Haynes Alloy 160, High Strength Haynes, Heat Resistant Haynes,
    Corrosion Resistant Haynes, Industrial Haynes Alloys, Chemical Processing Haynes, Power Industry Haynes, Aerospace
    Haynes Alloys, Marine Industry Haynes')
@section('og_image', asset('assets/images/haynes/haynes-alloy-160.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area" style="background-image: url(/assets/images/haynes/haynes-alloy-160.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Haynes Superalloy 160 <br> High Strength Heat & Corrosion Resistance</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        Haynes Superalloy 160 is a high-performance nickel-based alloy engineered for exceptional strength,
                        oxidation resistance, and corrosion protection at elevated temperatures. It delivers excellent
                        thermal stability, wear resistance, and durability, making it well suited for gas turbines,
                        aerospace components, chemical processing equipment, and other demanding high-heat industrial
                        applications.

                    </p>
                    <!-- End extra content -->

                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Haynes Superalloys 160 / UNS N07160
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/haynes/haynes-alloy-160.webp') }}" alt="Haynes-160"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> is a leading manufacturer,
                            supplier, exporter, importer, and stockist of a broad range of<strong class="text-black"> Haynes
                                160 (UNS N07160) <a href="{{ route('products') }}">products</a></strong>.
                            including Pipes & Tubes, Pipe Fittings, Flanges, Fasteners, Sheets & Plates, Coils, Wires, Round
                            Bars, Flat Bars, Angles, Channels, Welding Rods, Wire Mesh, and other custom and hard-to-find
                            Haynes 160 products.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black"><a href="{{ route('materials.haynes-Superalloys') }}">Haynes
                                    Superalloys 160</a></strong class="text-black"> is a nickel-chromium-iron alloy known
                            for its
                            excellent resistance to oxidation and carburization in highly aggressive environments. It offers
                            outstanding high-temperature strength and corrosion resistance, making it an ideal choice for
                            demanding industrial applications.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Haynes Superalloys 160 Datasheet</h3>
            <p class="mb-3">
                Get the complete Haynes Superalloys 160 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>HAYNES 160® Specifications (UNS N07160 / Alloy 160)</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>Haynes 160® / Alloy 160 / UNS N07160</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>Nickel–Chromium–Iron High-Temperature Alloy</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Forms Available</td>
                                    <td>Hot Rolled, Cold Rolled, Annealed</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Solution Annealed</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Tensile, Hardness, Chemical, PMI, UT</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Standards</td>
                                    <td>ASTM B435, B572, B619, B622, B626</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of HAYNES 160®</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <p class="text-center mb-3">
                        The alloy’s performance is driven by its carefully controlled chemistry.
                    </p>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Nickel (Ni)</td>
                                    <td>Balance</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>22.0 – 24.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Iron (Fe)</td>
                                    <td>17.0 – 20.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese (Mn)</td>
                                    <td>≤ 1.0</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon (Si)</td>
                                    <td>≤ 0.35</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>≤ 0.10</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aluminum (Al)</td>
                                    <td>≤ 0.30</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Titanium (Ti)</td>
                                    <td>≤ 0.30</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Phosphorus (P)</td>
                                    <td>≤ 0.015</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sulfur (S)</td>
                                    <td>≤ 0.015</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">Technical Composition of HAYNES 160®</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <h3 class="text-center mb-3" style="color: #db7227;">Physical Properties of HAYNES 160®
                    </h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial Units</th>
                                    <th>Metric Units</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.304 lb/in³</td>
                                    <td>8.43 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Range</td>
                                    <td>2560 – 2700 °F</td>
                                    <td>1404 – 1482 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat</td>
                                    <td>0.12 Btu/lb·°F</td>
                                    <td>502 J/kg·°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Magnetic Permeability</td>
                                    <td>~1.02</td>
                                    <td>—</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Heat Treatment -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color:#db7227;">
                        Heat Treatment of HAYNES 160® (UNS N07160)
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Process</th>
                                    <th>Temperature Range</th>
                                    <th>Cooling Method</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Solution Annealing</td>
                                    <td>2150–2250 °F (1175–1230 °C)</td>
                                    <td>Rapid air cool or water quench</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>1500–1700 °F (815–925 °C)</td>
                                    <td>Air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Weld Annealing</td>
                                    <td>2150 °F (1175 °C)</td>
                                    <td>Recommended after welding</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Aging Treatment</td>
                                    <td>Not required</td>
                                    <td>Naturally stable alloy</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            📌 HAYNES 160® is typically supplied in the annealed condition and does not require
                            precipitation hardening.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties of HAYNES 160® (Annealed)
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Plate</th>
                            <th>Bar / Rod</th>
                            <th>Sheet</th>
                            <th>Tube (Cold Drawn)</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>112 ksi / 774 MPa</td>
                            <td>111 ksi / 767 MPa</td>
                            <td>110 ksi / 758 MPa</td>
                            <td>111 ksi / 767 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>46 ksi / 321 MPa</td>
                            <td>45 ksi / 314 MPa</td>
                            <td>51 ksi / 353 MPa</td>
                            <td>45 ksi / 314 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation</td>
                            <td>66%</td>
                            <td>68%</td>
                            <td>63 – 68%</td>
                            <td>~68%</td>
                        </tr>
                        <tr class="t-row">
                            <td>Reduction of Area</td>
                            <td>73%</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Modulus of Elasticity</td>
                            <td>211 GPa</td>
                            <td>211 GPa</td>
                            <td>Same as plate</td>
                            <td>—</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5">
                <h2>Available Forms & Size Range – HAYNES 160®</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark text-center">
                            <tr class="t-row">
                                <th>Product Form</th>
                                <th>Size Range / Description</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr class="t-row">
                                <td>Round Bars</td>
                                <td>6 mm – 200 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Sheets & Plates</td>
                                <td>0.5 – 50 mm, width up to 2000 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Coils & Strips</td>
                                <td>0.1 – 6 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Pipes & Tubes</td>
                                <td>OD 6 – 219 mm, WT 1 – 18 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Welding Rods & Wire</td>
                                <td>0.8 – 5 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Forged Components</td>
                                <td>Custom per drawing</td>
                            </tr>
                            <tr class="t-row">
                                <td>Fittings & Flanges</td>
                                <td>All ASME classes</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Haynes Superalloys 160</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Haynes Superalloys 160</strong> is offered in numerous product forms
                        meeting ASTM, ASME, and other standards:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Haynes Superalloys 160 products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Excellent oxidation and carburization resistance up to 1100°C (2000°F)</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Strong high-temperature strength and durability</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Outstanding corrosion resistance in oxidizing and reducing environments</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Good fabricability and weldability</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Resistance to thermal fatigue and creep</h5>
                    </div>
                </div>
                {{-- <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Economical compared to other titanium grades with higher alloy content</h5>
                    </div>
                </div> --}}
            </div>
        </div>
    </section>

<section id="applications"  class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Haynes Superalloys 160</h2>
                <p class="text-center pb-3"><strong class="text-dark">Haynes Superalloys 160</strong> Commonly used in
                    industries requiring reliable performance under extreme conditions:
                </p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>Haynes 160® Price Per Kg in India</h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹3,800 – ₹10,500 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is Haynes 160 and why is it important in high-temperature industries?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Haynes 160 (UNS N07160) is a nickel chromium iron superalloy designed for excellent
                                    resistance to oxidation and carburization in aggressive environments. It combines
                                    outstanding high temperature strength, durability, and corrosion resistance, making it
                                    widely used in industries that operate under extreme thermal and chemical conditions.
                                    Its ability to resist thermal fatigue and creep makes it an ideal choice for aerospace,
                                    power generation, chemical processing, and furnace applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the main properties of Haynes 160 alloy?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Haynes 160 offers excellent mechanical and thermal properties with a tensile strength of
                                    around 112 ksi, yield strength of 46 ksi, and elongation of up to 68%. It has a density
                                    of 8.43 g/cm³, a melting point between 1404–1482°C, and provides resistance to oxidation
                                    and carburization up to 1100°C (2000°F). Along with superior fabricability and
                                    weldability, this alloy ensures long term stability and performance under harsh
                                    operating conditions.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Which industries commonly use Haynes 160 products?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Haynes 160 is extensively used in aerospace for high-temperature components such as
                                    combustion chambers and heat shields, in industrial furnaces and heat treating equipment
                                    for burner parts and retorts, and in chemical processing for reactors, vessels, and
                                    piping that handle corrosive media. It also plays a crucial role in power generation for
                                    gas turbine parts and boiler components, as well as in environmental control systems
                                    that manage flue gas and exhaust streams.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What types of Haynes 160 products are available from MOKSH TUBES & FITTINGS LLP?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP offers a complete range of Haynes 160 products including
                                    seamless and welded pipes, tubes, sheets, plates, coils, bars, flanges, pipe fittings,
                                    fasteners, wire mesh, welding rods, and custom-fabricated components. All products are
                                    manufactured in compliance with ASTM, ASME, and other international standards, ensuring
                                    superior quality and long-lasting performance for critical industrial applications.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for Haynes 160 materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a leading global supplier with extensive expertise in
                                    nickel based superalloys like Haynes 160. The company ensures premium quality through
                                    strict quality assurance, global sourcing of raw materials, and adherence to
                                    international standards. With custom manufacturing options, timely delivery, and
                                    dedicated technical support, MOKSH TUBES & FITTINGS LLP provides reliable solutions that
                                    meet the demands of industries operating under extreme conditions.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section  id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    <strong>Moksh Tubes & Fittings LLP</strong> your dependable partner for specialty alloys.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>Equivalent Grades of HAYNES 160®</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>N07160</td>
                        </tr>
                        <tr class="t-row">
                            <td>W.Nr.</td>
                            <td>2.4060 (Reference)</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASTM</td>
                            <td>B435, B572, B619, B622, B626</td>
                        </tr>
                        <tr class="t-row">
                            <td>ASME</td>
                            <td>SB435, SB572, SB619, SB622, SB626</td>
                        </tr>
                        <tr class="t-row">
                            <td>ISO</td>
                            <td>NiCrFe Alloy</td>
                        </tr>
                        <tr class="t-row">
                            <td>Trade Name</td>
                            <td>Haynes® 160®</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
            {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                "@type": "Question",
                "name": "What is Haynes 160 and why is it important in high-temperature industries?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Haynes 160 (UNS N07160) is a nickel chromium iron superalloy designed for excellent resistance to oxidation and carburization in aggressive environments. It combines outstanding high temperature strength, durability, and corrosion resistance, making it widely used in industries that operate under extreme thermal and chemical conditions. Its ability to resist thermal fatigue and creep makes it an ideal choice for aerospace, power generation, chemical processing, and furnace applications."
                }
                },
                {
                "@type": "Question",
                "name": "What are the main properties of Haynes 160 alloy?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Haynes 160 offers excellent mechanical and thermal properties with a tensile strength of around 112 ksi, yield strength of 46 ksi, and elongation of up to 68%. It has a density of 8.43 g/cm³, a melting point between 1404–1482°C, and provides resistance to oxidation and carburization up to 1100°C (2000°F). Along with superior fabricability and weldability, this alloy ensures long term stability and performance under harsh operating conditions."
                }
                },
                {
                "@type": "Question",
                "name": "Which industries commonly use Haynes 160 products?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Haynes 160 is extensively used in aerospace for high-temperature components such as combustion chambers and heat shields, in industrial furnaces and heat treating equipment for burner parts and retorts, and in chemical processing for reactors, vessels, and piping that handle corrosive media. It also plays a crucial role in power generation for gas turbine parts and boiler components, as well as in environmental control systems that manage flue gas and exhaust streams."
                }
                },
                {
                "@type": "Question",
                "name": "What types of Haynes 160 products are available from MOKSH TUBES & FITTINGS LLP?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MOKSH TUBES & FITTINGS LLP offers a complete range of Haynes 160 products including seamless and welded pipes, tubes, sheets, plates, coils, bars, flanges, pipe fittings, fasteners, wire mesh, welding rods, and custom-fabricated components. All products are manufactured in compliance with ASTM, ASME, and other international standards, ensuring superior quality and long-lasting performance for critical industrial applications."
                }
                },
                {
                "@type": "Question",
                "name": "Why choose MOKSH TUBES & FITTINGS LLP for Haynes 160 materials?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "MOKSH TUBES & FITTINGS LLP is a leading global supplier with extensive expertise in nickel based superalloys like Haynes 160. The company ensures premium quality through strict quality assurance, global sourcing of raw materials, and adherence to international standards. With custom manufacturing options, timely delivery, and dedicated technical support, MOKSH TUBES & FITTINGS LLP provides reliable solutions that meet the demands of industries operating under extreme conditions."
                }
                }
            ]
            }

        @endverbatim
    </script>
@endsection


