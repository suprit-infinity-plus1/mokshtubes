@extends('layouts.master')

@section('title', '4340 Alloy Steel | High Tensile Strength Alloy')
@section('meta_description',
    '4340 Alloy Steel delivers superior toughness and fatigue resistance for demanding
    engineering applications.')
@section('meta_keywords',
    '4340 Alloy Steel, high tensile strength steel, tough steel, fatigue resistant steel, alloy
    steel for critical applications, industrial alloy steel')

@section('og_image', asset('assets/images/engineering-steels/engineering-steels-4340.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/engineering-steels/engineering-steels-4340.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>High Performance 4340 Alloy Steel for Engineering<br>High-Strength Low Alloy Steel</h1>

                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        High-Strength Low Alloy Steel is a specialized alloy steel grade known for exceptional strength,
                        toughness, and durability, widely used in aerospace, automotive, and heavy engineering applications.
                        Below is the complete datasheet including composition, properties, heat treatment, and
                        applications.<br>High Strength • Excellent Toughness • Ideal for Aerospace, Automotive & Heavy
                        Engineering
                    </p>


                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Engineering Steel 4340 / AISI 4340 Steel
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/engineering-steels/engineering-steels-4340.webp') }}" alt="EN 4340"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-3 text-justify">
                            <strong>Moksh Tubes & Fittings LLP</strong> is a reliable supplier, exporter, importer, and
                            stockist of
                            <strong>EN 4130 Alloy Steel (AISI 4130 / Cr-Mo Steel)</strong>, offering a wide range of pipes,
                            tubes, bars, plates,
                            and fittings for various engineering and industrial applications. 4130 alloy steel is a highly
                            versatile low-alloy
                            grade valued for its high strength, excellent toughness, superior weldability, and strong
                            fatigue resistance.
                            With an exceptional strength-to-weight ratio, it is widely used in aerospace structures,
                            motorsport chassis and roll cages,
                            high-pressure tubing, oilfield tools, and critical mechanical components operating under
                            demanding service conditions.
                        </p>

                        <p class="fs-6 text-justify">
                            Whether used in aircraft components, racing frames, drill pipes, hydraulic assemblies, or other
                            high-stress engineering applications,
                            <strong>4130 alloy steel delivers consistent and dependable performance</strong> under heavy
                            loads, vibration, pressure, and extreme environments.
                            We supply EN 4130 in multiple forms including
                            <strong>
                                <a href="{{ url('products/bars-rods/round-bars') }}">round bars</a>,
                                <a href="{{ url('products/bars-rods/flat-bars') }}"> flat bars</a>,
                                hex bars, square bars, plates, sheets, coils, strips, seamless pipes,
                                <a href="{{ url('products/pipes-tubes/welded-pipes') }}">welded tubes</a>,
                                forged blocks, rings, and custom-machined components.
                            </strong>
                            Material is available in annealed, normalized, quenched & tempered, hot-rolled, and cold-drawn
                            conditions.
                            All products are sourced from certified mills and supplied with
                            <strong>EN 10204 3.1 / 3.2 certification</strong>, ensuring complete traceability, reliability,
                            and quality for industrial and engineering use.
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Engineering Steels 4340 Datasheet</h3>
            <p class="mb-3">
                Get the complete Engineering Steels 4340 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>4340 Alloy Steel Specifications</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>AISI 4340 / UNS G43400 / EN 24 / 1.6511</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>High-Strength Low Alloy Steel (Ni-Cr-Mo Alloy)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Chemical Composition</td>
                                    <td>Ni 1.65–2.00%, Cr 0.70–0.90%, Mo 0.20–0.30%, C 0.38–0.43%, Mn 0.60–0.80%, Si
                                        0.15–0.30%</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>Annealed, Normalized, Hardened & Tempered, Hot Rolled, Forged</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Hardening, Tempering, Stress Relieving</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Tensile, Hardness, Impact, Chemical Analysis, UT (Optional)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- col-lg-8 -->

            </div> <!-- row -->
        </div> <!-- container -->
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Carbon</td>
                                    <td>0.38 – 0.43</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese</td>
                                    <td>0.60 – 0.80</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Phosphorus</td>
                                    <td>0.035</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon</td>
                                    <td>0.15 – 0.35</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Nickel</td>
                                    <td>1.65 – 2.00</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium</td>
                                    <td>0.70 – 0.90</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Molybdenum</td>
                                    <td>0.20 – 0.30</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sulfur</td>
                                    <td>0.040</td>
                                </tr>
                            </tbody>
                        </table>
                        <p class="mt-3 text-center">
                            4340 alloy steel gets its unique toughness from the combined Ni-Cr-Mo alloying.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Technical Composition</h2>
            </div>

            <!-- Physical Properties Table -->
            <div class="row justify-content-center mb-5">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color: #db7227;">Physical Properties</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial</th>
                                    <th>Metric</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.284 lb/in³</td>
                                    <td>7.85 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Point</td>
                                    <td>2600 °F</td>
                                    <td>1427 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Elastic Modulus</td>
                                    <td>29.7 ×10³ ksi</td>
                                    <td>205 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Bulk Modulus</td>
                                    <td>20.3 ×10³ ksi</td>
                                    <td>140 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Shear Modulus</td>
                                    <td>11.6 ×10³ ksi</td>
                                    <td>80 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Thermal Conductivity</td>
                                    <td>309 BTU·in/hr·ft²·°F</td>
                                    <td>44.5 W/m·K</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Poisson’s Ratio</td>
                                    <td>0.27–0.30</td>
                                    <td>—</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Thermal Expansion</td>
                                    <td>6.8 µin/in·°F</td>
                                    <td>12.3 µm/m·°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat</td>
                                    <td>0.114 BTU/lb·°F</td>
                                    <td>0.475 J/g·°C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Electrical Resistivity</td>
                                    <td>0.0000248 Ω·cm</td>
                                    <td>—</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center mb-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color: #db7227;">Heat Treatment of 4340 Steel</h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th>Heat Treatment Process</th>
                                    <th>Temperature Range</th>
                                    <th>Cooling / Procedure</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td><strong>Annealing</strong></td>
                                    <td>790–870°C</td>
                                    <td>Furnace cool</td>
                                </tr>

                                <tr class="t-row">
                                    <td><strong>Normalizing</strong></td>
                                    <td>830–900°C</td>
                                    <td>Air cool</td>
                                </tr>

                                <tr class="t-row">
                                    <td><strong>Hardening</strong></td>
                                    <td>830–860°C</td>
                                    <td>Oil or polymer quench</td>
                                </tr>

                                <tr class="t-row">
                                    <td><strong>Tempering</strong></td>
                                    <td>400–650°C</td>
                                    <td>Depends on required hardness</td>
                                </tr>

                                <tr class="t-row">
                                    <td><strong>Stress Relieving</strong></td>
                                    <td>540–650°C</td>
                                    <td>Hold 1–2 hours</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Mechanical Properties of 4340 Alloy Steel (Quenched &
                    Tempered)</h2>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Annealed</th>
                            <th>Hot Finished</th>
                            <th>Cold Drawn</th>
                            <th>Hot Rolled</th>
                            <th>Sheet</th>
                        </tr>
                    </thead>

                    <tbody class="text-center">

                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>930–1080 MPa</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>

                        <tr class="t-row">
                            <td>Yield Strength</td>
                            <td>745–930 MPa</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>

                        <tr class="t-row">
                            <td>Elongation (%)</td>
                            <td>12–16%</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>

                        <tr class="t-row">
                            <td>Hardness</td>
                            <td>28–34 HRC</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>

                        <tr class="t-row">
                            <td>Impact Toughness</td>
                            <td>Excellent</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                            <td>—</td>
                        </tr>

                    </tbody>
                </table>

                <p class="mt-3 text-center">
                    4340 steel shows excellent toughness and high strength after quenching & tempering.
                </p>

            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5" id="available forms">
                <h2>Available Forms & Size Range</h2>
            </div>

            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6 text-center">
                        We supply Alloy Steel 4340 in the following product forms and dimensions:
                    </p>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="p-4 bg-white rounded shadow-sm border-start border-4" style="border-color:#db7227;">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 40%;">Product Form</th>
                                    <th>Size Range / Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Round Bars</td>
                                    <td>16 mm – 600 mm</td>
                                </tr>
                                <tr>
                                    <td>Flat, Square & Hex Bars</td>
                                    <td>Custom sizes</td>
                                </tr>
                                <tr>
                                    <td>Sheets & Plates</td>
                                    <td>3 mm – 200 mm</td>
                                </tr>
                                <tr>
                                    <td>Forgings</td>
                                    <td>Blocks, rings, bushings, custom shapes</td>
                                </tr>
                                <tr>
                                    <td>Tubes</td>
                                    <td>OD 20 mm – 219 mm</td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Engineering Steel 4340</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Engineering Steel 4340</strong> is typically available in:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Engineering Steel 4340 products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <!-- Product Image Cards (Bootstrap Grid) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section  id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>High strength and toughness with good fatigue resistance</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Excellent wear and impact resistance</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Good hardenability and ability to maintain mechanical properties after heat treatment</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Versatile and widely used in critical structural and mechanical parts</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Engineering Steel 4340</h2>
                <p class="text-center pb-3"><strong class="text-dark">Engineering Steel 4340</strong> is widely used in:
                    in:
                </p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <h2>4340 Steel Price per kg in India</h2>
            <p>Price varies based on size, OD, thickness, and heat-treatment condition.</p>
            <p><strong>Typical Range:</strong> ₹160 – ₹260 per kg (Indicative only)</p>
            <p>Contact us for exact quotation based on size and quantity.</p>
        </div>
    </section>
--}}

<section id="faq"  class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is EN 4340 steel and why is it used in industries?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN 4340 is a high strength, low-alloy steel containing nickel, chromium, and molybdenum,
                                    which provide superior toughness, hardenability, and wear resistance.
                                    Known for its excellent fatigue strength and ability to perform under high stress, 4340
                                    is widely used in aerospace, automotive, oil and gas, and heavy machinery industries
                                    where strength, impact resistance, and durability are critical.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key chemical and mechanical properties of EN 4340 steel?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN 4340 steel has a chemical composition that includes 0.38–0.43% carbon, 1.65–2.00%
                                    nickel, 0.70–0.90% chromium, and 0.20–0.30% molybdenum, along with manganese, silicon,
                                    phosphorus, and sulfur in controlled amounts.
                                    It exhibits tensile strength between 930–1080 MPa, yield strength of 745–930 MPa,
                                    elongation of 12–16%, and hardness of 28–34 HRC.
                                    With excellent impact toughness and fatigue resistance, EN 4340 provides outstanding
                                    performance in demanding environments.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What EN 4340 steel products are supplied by MOKSH TUBES & FITTINGS LLP?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP offers a wide range of EN 4340 steel products including
                                    seamless and welded pipes, tubes, sheets, plates, coils, strips, round bars, hex bars,
                                    flat bars, square bars, pipe fittings, flanges, fasteners, and custom-fabricated
                                    components.
                                    All products are manufactured to meet international quality standards and can be
                                    supplied in both standard and customized dimensions to suit industry-specific
                                    requirements.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the major applications of EN 4340 steel?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN 4340 steel is extensively used in aerospace and defense for aircraft landing gear,
                                    structural parts, and high-strength fasteners.
                                    In the automotive industry, it is applied in crankshafts, axles, gears, and drive shafts
                                    exposed to heavy loads.
                                    Heavy machinery and industrial equipment use EN 4340 for shafts, bolts, and connecting
                                    rods requiring durability and fatigue resistance,
                                    while the oil and gas industry applies it in drill collars, valve components, and
                                    high-pressure equipment.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for EN 4340 steel materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted global supplier and exporter of EN 4340 alloy
                                    steel with a comprehensive stock in multiple forms and sizes.
                                    The company provides customized cutting, forging, and processing services backed by
                                    expert technical support.
                                    With stringent quality control, international certifications, reliable worldwide
                                    deliveries, and competitive pricing,
                                    MOKSH TUBES & FITTINGS LLP ensures superior EN 4340 steel solutions tailored to diverse
                                    industrial needs.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>Blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    For inquiries or to request a quote for 4340 alloy steel products, contact <strong> Moksh Tubes
                        & Fittings
                        LLP </strong> — your reliable partner for premium engineering steels.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- datasheet --}}

{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades — Alloy Steel 4340</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered text-center">
                    <thead class="table-dark">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="t-row">
                            <td>AISI / SAE</td>
                            <td>4340</td>
                        </tr>
                        <tr class="t-row">
                            <td>EN</td>
                            <td>34CrNiMo6 / 1.6582</td>
                        </tr>
                        <tr class="t-row">
                            <td>DIN</td>
                            <td>34CrNiMo6</td>
                        </tr>
                        <tr class="t-row">
                            <td>BS (British)</td>
                            <td>817M40</td>
                        </tr>
                        <tr class="t-row">
                            <td>AFNOR (France)</td>
                            <td>35NCD16</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS (Japan)</td>
                            <td>SNCM439</td>
                        </tr>
                        <tr class="t-row">
                            <td>GB (China)</td>
                            <td>40CrNiMoA</td>
                        </tr>
                        <tr class="t-row">
                            <td>ISO</td>
                            <td>34CrNiMo6</td>
                        </tr>
                        <tr class="t-row">
                            <td>GOST (Russia)</td>
                            <td>30ХГСА / 30KhGSA</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>Export Destinations</h2>
            </div>

            <p class="text-center mb-2">
                We export Alloy Steel 4340 to:
            </p>

            <p class="text-center fs-5">
                UAE, Saudi Arabia, Qatar, Oman, Kuwait, Bahrain, Turkey, Europe, USA, Canada, Singapore,
                Malaysia, Indonesia, South Africa, Nigeria.
            </p>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
                {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                    "@type": "Question",
                    "name": "What is EN 4340 steel and why is it used in industries?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN 4340 is a high strength, low-alloy steel containing nickel, chromium, and molybdenum, which provide superior toughness, hardenability, and wear resistance. Known for its excellent fatigue strength and ability to perform under high stress, 4340 is widely used in aerospace, automotive, oil and gas, and heavy machinery industries where strength, impact resistance, and durability are critical."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What are the key chemical and mechanical properties of EN 4340 steel?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN 4340 steel has a chemical composition that includes 0.38–0.43% carbon, 1.65–2.00% nickel, 0.70–0.90% chromium, and 0.20–0.30% molybdenum, along with manganese, silicon, phosphorus, and sulfur in controlled amounts. It exhibits tensile strength between 930–1080 MPa, yield strength of 745–930 MPa, elongation of 12–16%, and hardness of 28–34 HRC. With excellent impact toughness and fatigue resistance, EN 4340 provides outstanding performance in demanding environments."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What EN 4340 steel products are supplied by MOKSH TUBES & FITTINGS LLP?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "MOKSH TUBES & FITTINGS LLP offers a wide range of EN 4340 steel products including seamless and welded pipes, tubes, sheets, plates, coils, strips, round bars, hex bars, flat bars, square bars, pipe fittings, flanges, fasteners, and custom-fabricated components. All products are manufactured to meet international quality standards and can be supplied in both standard and customized dimensions to suit industry-specific requirements."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What are the major applications of EN 4340 steel?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN 4340 steel is extensively used in aerospace and defense for aircraft landing gear, structural parts, and high-strength fasteners. In the automotive industry, it is applied in crankshafts, axles, gears, and drive shafts exposed to heavy loads. Heavy machinery and industrial equipment use EN 4340 for shafts, bolts, and connecting rods requiring durability and fatigue resistance, while the oil and gas industry applies it in drill collars, valve components, and high-pressure equipment."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "Why choose MOKSH TUBES & FITTINGS LLP for EN 4340 steel materials?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "MOKSH TUBES & FITTINGS LLP is a trusted global supplier and exporter of EN 4340 alloy steel with a comprehensive stock in multiple forms and sizes. The company provides customized cutting, forging, and processing services backed by expert technical support. With stringent quality control, international certifications, reliable worldwide deliveries, and competitive pricing, MOKSH TUBES & FITTINGS LLP ensures superior EN 4340 steel solutions tailored to diverse industrial needs."
                    }
                    }
                ]
                }

            @endverbatim
    </script>
@endsection


