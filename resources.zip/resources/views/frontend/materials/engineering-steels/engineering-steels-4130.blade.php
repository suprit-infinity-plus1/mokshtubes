@extends('layouts.master')

@section('title', '4130 Alloy Steel | Chromium-Molybdenum Steel')
@section('meta_description',
    '4130 Alloy Steel offering high strength, toughness, and weldability for aerospace,
    automotive, and industrial applications.')
@section('meta_keywords',
    '4130 Alloy Steel, chromium-molybdenum steel, high strength steel, tough steel, weldable
    steel, aerospace steel, automotive steel, industrial alloy steel')

@section('og_image', asset('assets/images/engineering-steels/engineering-steels-4130.webp'))
@section('og_type', 'article')
@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/engineering-steels/engineering-steels-4130.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>4130 Alloy Steel (AISI 4130 / EN 4130)<br> Chromium-Molybdenum Steel</h1>
                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        High-Strength Low Alloy Steel is a specialized alloy steel grade known for exceptional strength,
                        toughness, and durability, widely used in aerospace, automotive, and heavy engineering applications.
                        Below is the complete datasheet including composition, properties, heat treatment, and applications.
                        High Strength • Excellent Toughness • Ideal for Aerospace, Automotive & Heavy Engineering

                    </p>


                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section  id="overview" class="sec-padd-top sec-padd-bottom bg-light" id="overview">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Engineering Steel 4130 / AISI 4130 Steel
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/engineering-steels/engineering-steels-4130.webp') }}" alt="EN 4130"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black">MOKSH TUBES & FITTINGS LLP</strong> is a reliable supplier,
                            exporter, importer, and stockist of <strong class="text-black">EN 4130 steel products</strong>
                            including pipes, <a href="{{ route('products.pipes-tubes') }}">tubes</a>, bars, plates,
                            and fittings.
                        </p>

                        <p class="fs-6 mb-3" style="text-align: justify;">
                            <strong class="text-black">4130 Alloy Steel</strong>, also known as AISI 4130,
                            Chromium-Molybdenum Steel, or Cr-Mo Steel, is a versatile low-alloy steel known for its
                            high strength, toughness, weldability, and fatigue resistance. Its excellent
                            strength-to-weight ratio makes it ideal for aerospace structures, motorsport frames,
                            high-pressure tubing, and critical engineering components.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            Whether used in aircraft parts, roll cages, drill pipes, or high-stress mechanical
                            components, 4130 alloy steel delivers consistent performance under load and offers
                            exceptional durability after heat treatment. Its combination of strength, workability,
                            and reliability makes it a preferred choice for OEMs, engineering companies,
                            fabrication units, and industrial manufacturers.
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Engineering Steels 4130 Datasheet</h3>
            <p class="mb-3">
                Get the complete Engineering Steels 4130 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            {{-- <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf
                <div class="row justify-content-center">
                    <input type="hidden" name="pdf" value="en_4130.pdf">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>
                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            📥 Get Datasheet
                        </button>
                    </div>
                </div>
            </form> --}}
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>4340 Alloy Steel Specifications</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>AISI 4340 / UNS G43400 / EN 24 / 1.6511</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>High-Strength Low Alloy Steel (Ni-Cr-Mo Alloy)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Typical Chemical Composition</td>
                                    <td>C 0.38–0.43%, Mn 0.60–0.80%, Si 0.15–0.30%, Cr 0.70–0.90%, Ni 1.65–2.00%, Mo
                                        0.20–0.30%</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>Annealed, Normalized, Hardened & Tempered, Hot Rolled, Forged</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Heat Treatment</td>
                                    <td>Quenching & Tempering, Normalizing, Stress Relieving</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Tensile, Hardness, Impact, Chemical Analysis, UT (Optional)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2 (Mill Test Certificate Available)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- col-lg-8 -->
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

<section class="sec-padd-top sec-padd-bottom" id="composition">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of 4130 Alloy Steel</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Carbon</td>
                                    <td>0.28 – 0.33</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese</td>
                                    <td>0.40 – 0.60</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Phosphorus</td>
                                    <td>0.035</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sulfur</td>
                                    <td>0.040</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium</td>
                                    <td>0.80 – 1.10</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Molybdenum</td>
                                    <td>0.15 – 0.25</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon</td>
                                    <td>0.15 – 0.35</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Technical Composition</h2>
            </div>

            <!-- Physical Properties Table -->
            <div class="row justify-content-center mb-5">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color: #db7227;">Physical Properties</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Imperial</th>
                                    <th>Metric</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>0.283 lb/in³</td>
                                    <td>7.83 g/cm³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Point</td>
                                    <td>2500 – 2550 °F</td>
                                    <td>1370 – 1400 °C</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Modulus of Elasticity(Tension)</td>
                                    <td>29,000 ksi</td>
                                    <td>200 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Modulus of Elasticity(Torsion)</td>
                                    <td>11,600 ksi</td>
                                    <td>80 GPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Poisson's Ratio</td>
                                    <td>0.29</td>
                                    <td>-</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Thermal Conductivity</td>
                                    <td>42 W/m·K</td>
                                    <td>42 W/m·K</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat Capacity</td>
                                    <td>460 J/kg·K</td>
                                    <td>460 J/kg·K</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center mb-5" id="heat-treatment">
                <div class="col-lg-8">
                    <h4 class="text-center mb-3" style="color: #db7227;">Heat Treatment of 1045 Steel</h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th class="text-center">Heat Treatment Process</th>
                                    <th class="text-center">Temperature Range</th>
                                    <th class="text-center">Cooling / Procedure</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class = "t-row">
                                    <td><strong>Annealing</strong></td>
                                    <td>790–870°C</td>
                                    <td>slow furnance cool</td>
                                </tr>

                                <tr class = "t-row">
                                    <td><strong>Normalizing</strong></td>
                                    <td>830–860°C</td>
                                    <td>Air cool</td>
                                </tr>

                                <tr class = "t-row">
                                    <td><strong>Hardening</strong></td>
                                    <td>800–820°C</td>
                                    <td>Quench in polymer or oil</td>
                                </tr>

                                <tr class = "t-row">
                                    <td><strong>Tempering</strong></td>
                                    <td>400–650°C</td>
                                    <td>Reheat depending on required hardness</td>
                                </tr>

                                <tr class = "t-row">
                                    <td><strong>Stress Relieving</strong></td>
                                    <td>540–650°C</td>
                                    <td>Hold for 1–2 hours</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <p class="fs-6 mb-3" style="text-align: justify;">After quenching & tempering, 4130 steel develops
                    exceptional fatigue strength, improved hardness, and enhanced
                    mechanical stability for high-stress engineering applications.</p>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Mechanical Properties</h2>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Annealed</th>
                            <th>Hot-Finished</th>
                            <th>Cold Drawn</th>
                            <th>Hot-rolled</th>
                            <th>Sheet</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength (ksi / MPa)</td>
                            <td>85–105 ksi / 586–724 MPa</td>
                            <td>90–115 ksi / 620–793 MPa</td>
                            <td>95–130 ksi / 655–896 MPa</td>
                            <td>85–110 ksi / 586–758 MPa</td>
                            <td>80–105 ksi / 552–724 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>55–70 ksi / 379–483 MPa</td>
                            <td>60–95 ksi / 414–655 MPa</td>
                            <td>65–105 ksi / 448–724 MPa</td>
                            <td>55–80 ksi / 379–552 MPa</td>
                            <td>50–75 ksi / 345–517 MPa</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation (%)</td>
                            <td>20–30</td>
                            <td>15–25</td>
                            <td>15–20</td>
                            <td>20–25</td>
                            <td>20–30</td>
                        </tr>
                        <tr class="t-row">
                            <td>Brinell Hardness (3000 kg)</td>
                            <td>150–200</td>
                            <td>180–240</td>
                            <td>200–260</td>
                            <td>150–210</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Rockwell Hardness (B / C)</td>
                            <td>80–90 B</td>
                            <td>85–95 B</td>
                            <td>85–95 B</td>
                            <td>80–90 B</td>
                            <td>80–90 B</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5" id="available forms">
                <h2>Available Forms &amp; Size Range</h2>
            </div>

            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6 text-center">
                        We supply AISI 4340 Alloy Steel in the following product forms and dimensions:
                    </p>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="p-4 bg-white rounded shadow-sm border-start border-4" style="border-color:#db7227;">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 40%;">Product Form</th>
                                    <th>Size Range / Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Round Bars</td>
                                    <td>16 mm – 600 mm</td>
                                </tr>
                                <tr>
                                    <td>Flat, Square &amp; Hex Bars</td>
                                    <td>Custom sizes</td>
                                </tr>
                                <tr>
                                    <td>Sheets &amp; Plates</td>
                                    <td>3 mm – 200 mm</td>
                                </tr>
                                <tr>
                                    <td>Forgings</td>
                                    <td>Blocks, rings, bushings, custom shapes</td>
                                </tr>
                                <tr>
                                    <td>Tubes (Seamless &amp; Welded)</td>
                                    <td>OD 20 mm – 219 mm</td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Engineering Steel 4130</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Engineering Steel 4130</strong> is typically available in:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Engineering Steel 4130 products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses"  class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Excellent strength-to-weight ratio</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Good weldability and machinability</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>High fatigue resistance and toughness</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>meCan be heat-treated for enhanced mechanical properties</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>High strength-to-weight ratio ideal for structural applications</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Excellent machinability and weldability</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Outstanding fatigue resistance</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Heat treatable for superior mechanical performance</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Reliable for aerospace, motorsport, and oilfield operations</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section  id="applications" class="sec-padd-top sec-padd-bottom" id="applications">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Engineering Steel 4130</h2>
                <p class="text-center pb-3"><strong class="text-dark">Engineering Steel 4130</strong> is widely used in:
                </p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light" id="price">
        <div class="container text-center">
            <h2>4130 Steel Price per kg in India</h2>
            <p>Typical Price Range:
                ₹150 – ₹280 per kg (Varies by size, wall thickness, and heat-treatment condition).</p>

            <p>Contact us for exact quotation based on size and quantity.</p>
        </div>
    </section>
--}}

<section  id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is EN 4130 steel and why is it widely used?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN 4130, also known as AISI 4130, is a low-alloy steel containing chromium and
                                    molybdenum, which provide excellent strength, toughness, and weldability.
                                    It is valued for its high strength-to-weight ratio and fatigue resistance, making it
                                    suitable for demanding structural and mechanical applications.
                                    Due to its ability to be heat-treated for enhanced mechanical properties, EN 4130 is
                                    extensively used in aerospace, automotive, and oil & gas industries.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the chemical and mechanical properties of EN 4130 steel?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN 4130 steel has a chemical composition that includes carbon (0.28–0.33%), manganese
                                    (0.40–0.60%), chromium (0.80–1.10%), and molybdenum (0.15–0.25%),
                                    along with small amounts of silicon, phosphorus, and sulfur.
                                    Mechanically, it offers tensile strength between 552–896 MPa and yield strength between
                                    345–724 MPa, depending on the product form and heat treatment.
                                    With elongation up to 30% and hardness ranging from 150–260 Brinell, EN 4130 is strong,
                                    ductile, and highly versatile.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What EN 4130 steel products are offered by MOKSH TUBES & FITTINGS LLP?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP supplies a complete range of EN 4130 steel products including
                                    seamless and welded pipes, tubes, sheets, plates, coils, strips, bars,
                                    pipe fittings, flanges, fasteners, and custom-fabricated components.
                                    All products are manufactured to international standards and can be customized in terms
                                    of dimensions, thickness, and heat treatment to meet specific industry requirements.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the key applications of EN 4130 steel?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN 4130 steel is widely used in aerospace and aviation for manufacturing aircraft
                                    components, engine mounts, and landing gear parts.
                                    In the automotive and motorsport industry, it is used for roll cages, chassis, drive
                                    shafts, and suspension parts that require strength and fatigue resistance.
                                    It is also extensively used in the oil & gas industry for pipelines, high-pressure
                                    tubing, and equipment exposed to extreme environments,
                                    as well as in mechanical engineering for gears, bolts, and machinery components.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for EN 4130 steel materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a trusted supplier of high-quality EN 4130 steel products
                                    with a wide inventory and the ability to provide customized solutions.
                                    The company has strong expertise in alloy steel manufacturing and ensures compliance
                                    with international standards.
                                    With global supply capabilities, timely deliveries, competitive pricing, and dedicated
                                    customer support,
                                    MOKSH TUBES & FITTINGS LLP is a reliable partner for industries requiring durable and
                                    high-performance EN 4130 steel materials.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    For inquiries or quotations on EN 4130 steel products, contact <strong> Moksh Tubes & Fittings
                        LLP </strong> — your reliable partner for chromium-molybdenum alloy steels.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades</h2>
            </div>

            <div class="table-responsive col-lg-8 mx-auto">
                <table class="table table-bordered text-center">
                    <thead class="table-dark">
                        <tr class = "t-row" class = "t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class = "t-row">
                            <td>EN</td>
                            <td>25CrMo4 / EN 4130</td>
                        </tr>
                        <tr class = "t-row">
                            <td>AISI / SAE</td>
                            <td>4130</td>
                        </tr>
                        <tr class = "t-row">
                            <td>DIN</td>
                            <td>1.7218</td>
                        </tr>
                        <tr class = "t-row">
                            <td>JIS</td>
                            <td>SCM430</td>
                        </tr>
                        <tr class = "t-row">
                            <td>GB</td>
                            <td>30CrMo</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection


@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
                {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                    "@type": "Question",
                    "name": "What is EN 4130 steel and why is it widely used?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN 4130, also known as AISI 4130, is a low-alloy steel containing chromium and molybdenum, which provide excellent strength, toughness, and weldability. It has a high strength-to-weight ratio and fatigue resistance, making it suitable for demanding structural and mechanical applications in aerospace, automotive, and oil & gas industries."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What are the chemical and mechanical properties of EN 4130 steel?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN 4130 steel contains carbon (0.28–0.33%), manganese (0.40–0.60%), chromium (0.80–1.10%), and molybdenum (0.15–0.25%), with small amounts of silicon, phosphorus, and sulfur. It offers tensile strength between 552–896 MPa and yield strength between 345–724 MPa, depending on heat treatment, with elongation up to 30% and hardness from 150–260 Brinell."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What EN 4130 steel products are offered by MOKSH TUBES & FITTINGS LLP?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "MOKSH TUBES & FITTINGS LLP provides seamless and welded pipes, tubes, sheets, plates, coils, strips, bars, pipe fittings, flanges, fasteners, and custom-fabricated EN 4130 steel components. All are made to international standards and customizable in dimensions, thickness, and heat treatment."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What are the key applications of EN 4130 steel?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN 4130 steel is used in aerospace for aircraft components and landing gear, in automotive and motorsport for chassis, roll cages, and drive shafts, and in oil & gas for pipelines and high-pressure equipment. It’s also applied in mechanical engineering for gears, bolts, and machinery components."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "Why choose MOKSH TUBES & FITTINGS LLP for EN 4130 steel materials?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "MOKSH TUBES & FITTINGS LLP is a trusted supplier of EN 4130 steel with a wide product range, customization options, and global supply capability. The company ensures compliance with international standards, offers competitive pricing, timely delivery, and strong customer support."
                    }
                    }
                ]
            }

        @endverbatim
    </script>
@endsection


