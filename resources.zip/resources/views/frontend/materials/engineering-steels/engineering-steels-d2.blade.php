@extends('layouts.master')

@section('title', 'D2 Tool Steel | High Carbon, High Chromium Alloy')
@section('meta_description',
    'D2 Tool Steel offering exceptional wear resistance and toughness for cutting tools, dies,
    and industrial applications.')
@section('meta_keywords',
    'D2 Tool Steel, high carbon steel, high chromium steel, wear resistant steel, tough tool
    steel, cutting tools steel, die steel, industrial tool steel')

@section('og_image', asset('assets/images/engineering-steels/engineering-steels-d2.webp'))
@section('og_type', 'article')

@section('content')
<section class="breadcrumb-area"
        style="background-image: url(/assets/images/engineering-steels/engineering-steels-d2.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Premium D2 Tool Steel for Industrial Applications<br>High-Carbon, High-Chromium Tool Steel</h1>
                    <!-- Add your extra content here -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        D2 Engineering Steel (EN D2 / AISI D2) is a high-carbon, high-chromium tool steel known for
                        excellent wear resistance, high hardness, and toughness. Below is the complete datasheet including
                        composition, properties, heat treatment, and applications.
                    </p>


                    <!-- End extra content -->

                </div>
            </div>
        </div>
    </section>

<div class="sticky-top bg-white border-bottom material-tabs  w-100">
        <div class="container">
            <a href="#overview">Overview</a> |
            <a href="#specification">Specifications</a> |
            <a href="#composition">Chemical Composition</a> |
            <a href="#mechanical">Mechanical Properties</a> |
            <a href="#price">Advantages</a> |
            <a href="#applications">Applications</a> |
            <a href="#faq">FAQ</a> |
            <a href="#contact-us">Contact Us</a>
        </div>
    </div>

<section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction To Engineering Steel D2 Tool
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/engineering-steels/engineering-steels-d2.webp') }}" alt="ENd2"
                        class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                            <strong class="text-black"> MOKSH TUBES & FITTINGS LLP</strong> is a leading manufacturer,
                            supplier, exporter, importer, and stockist of<strong class="tex-black"> D2 steel
                                products</strong> including bars, plates, sheets,<a
                                href="{{ route('products.pipes-tubes') }}"> tubes</a> and precision ground tooling
                            materials.
                        </p>

                        <p class="fs-6" style="text-align: justify;">
                            <strong class="text-black">EN D2</strong class="text-black">, is a high-carbon, high-chromium,
                            air-hardening tool steel known for its excellent wear resistance, toughness, and ability to
                            maintain a sharp edge. It is classified as a cold work tool steel and is commonly used in
                            applications requiring high abrasion resistance and moderate toughness. Its high chromium
                            content provides good corrosion resistance compared to other tool steels, making it suitable for
                            tools exposed to mild corrosive environments.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Engineering Steels D2 Datasheet</h3>
            <p class="mb-3">
                Get the complete Engineering Steels D2 datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

<section class="sec-padd-top" id="specification">
        <div class="container">
            <div class="section-title center">
                <h2>D2 Tool Steel Specifications</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Grade</td>
                                    <td>AISI D2 / UNS T30402 / X153CrMoV12 / 1.2379</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Type</td>
                                    <td>High-Carbon, High-Chromium Cold-Work Tool Steel</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Testing</td>
                                    <td>Hardness, Tensile (limited), Charpy Impact, Microstructure, Chemical Analysis, UT
                                        (Optional)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Conditions</td>
                                    <td>Annealed, Spheroidized Annealed, Hardened & Tempered, Precision Ground, ESR
                                        (Optional)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Certification</td>
                                    <td>EN 10204 3.1 / 3.2</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section id="composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Chemical Composition of D2 Tool Steel</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Carbon (C)</td>
                                    <td>1.40 – 1.60</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Chromium (Cr)</td>
                                    <td>11.00 – 13.00</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Manganese (Mn)</td>
                                    <td>0.60 – 0.90</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Vanadium (V)</td>
                                    <td>0.80 – 1.20</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Molybdenum (Mo)</td>
                                    <td>0.70 – 1.20</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Silicon (Si)</td>
                                    <td>0.20 – 0.60</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Phosphorus (P)</td>
                                    <td>≤ 0.03</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sulfur (S)</td>
                                    <td>≤ 0.03</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            High chromium and carbon form hard carbides, giving D2 exceptional wear resistance and edge
                            retention.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="properties" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">Physical Properties of D2 Tool Steel</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Metric</th>
                                    <th>Imperial</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Density</td>
                                    <td>7.7 g/cm³</td>
                                    <td>0.28 lb/in³</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Melting Range</td>
                                    <td>1115 – 1165 °C</td>
                                    <td>2040 – 2130 °F</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Elastic Modulus (Tension)</td>
                                    <td>200 GPa</td>
                                    <td>29,000 ksi</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Elastic Modulus (Torsion)</td>
                                    <td>79 GPa</td>
                                    <td>11,500 ksi</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Poisson’s Ratio</td>
                                    <td>0.28</td>
                                    <td>—</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Thermal Conductivity</td>
                                    <td>18 W/m·K</td>
                                    <td>—</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specific Heat</td>
                                    <td>460 J/kg·K</td>
                                    <td>—</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Heat Treatment -->
            <div class="row justify-content-center mt-5" id="heat-treatment">
                <div class="col-lg-10">
                    <h4 class="text-center mb-3" style="color:#db7227;">
                        Heat Treatment of D2 Tool Steel
                    </h4>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Process</th>
                                    <th>Temperature Range</th>
                                    <th>Cooling Method</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td>Annealing</td>
                                    <td>845 – 885 °C</td>
                                    <td>Slow furnace cool to 600 °C, then air cool</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Spheroidize Annealing</td>
                                    <td>870 – 900 °C</td>
                                    <td>Controlled slow cooling</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Preheating</td>
                                    <td>450–500 °C → 800–850 °C</td>
                                    <td>Two-stage preheat</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Hardening (Austenitizing)</td>
                                    <td>1010 – 1040 °C</td>
                                    <td>Air / forced air / vacuum quench</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Tempering</td>
                                    <td>150 – 560 °C</td>
                                    <td>Air cool, double temper recommended</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Stress Relieving</td>
                                    <td>600 – 650 °C</td>
                                    <td>Hold 1–2 hours</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Normalizing</td>
                                    <td colspan="2">Not applicable for D2 tool steel</td>
                                </tr>
                            </tbody>
                        </table>

                        <p class="mt-3 text-center">
                            D2 achieves high hardness with minimal distortion due to its air-hardening nature.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
--}}

<section class="sec-padd-top sec-padd-bottom" id="mechanical">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color:#174268;">
                    Mechanical Properties of D2 Tool Steel (Typical)
                </h2>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Property</th>
                            <th>Annealed</th>
                            <th>Hardened & Tempered</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>Tensile Strength</td>
                            <td>620–724 MPa</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Yield Strength (0.2%)</td>
                            <td>482–586 MPa</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Elongation (%)</td>
                            <td>8–12</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Brinell Hardness</td>
                            <td>200–230 HB</td>
                            <td>—</td>
                        </tr>
                        <tr class="t-row">
                            <td>Rockwell Hardness</td>
                            <td>—</td>
                            <td>58–62 HRC</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

{{-- 
<section class="sec-padd-top sec-padd-bottom bg-light" id="related grades">
        <div class="container">
            <div class="section-title center mt-5">
                <h2>Available Forms & Size Range – D2 Tool Steel</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <table class="table table-bordered table-striped align-middle">
                        <thead class="table-dark text-center">
                            <tr class="t-row">
                                <th>Product</th>
                                <th>Size / Range</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr class="t-row">
                                <td>Round Bars</td>
                                <td>16 mm – 500 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Flat / Square / Hex Bars</td>
                                <td>Custom sizes (precision ground / hot rolled)</td>
                            </tr>
                            <tr class="t-row">
                                <td>Sheets & Plates</td>
                                <td>2 – 200 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Forgings</td>
                                <td>Blocks, rings, discs, bushings</td>
                            </tr>
                            <tr class="t-row">
                                <td>Tubes</td>
                                <td>Custom-made, OD 20 – 150 mm</td>
                            </tr>
                            <tr class="t-row">
                                <td>Precision Ground Stock</td>
                                <td>1.5 – 80 mm thick, widths up to 400 mm</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
--}}

@php
        $products = [
            [
                'name' => 'Pipes',
                'url' => 'products/pipes-tubes/seamless-pipes',
                'image' => 'assets/images/all-product/seamless-pipes-10.webp',
            ],
            [
                'name' => 'Tubes',
                'url' => 'products/pipes-tubes/welded-pipes',
                'image' => 'assets/images/all-product/welded-pipes-tubes-1.webp',
            ],
            [
                'name' => 'Sheets',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Plates',
                'url' => 'products/sheets-plates-coils/sheets-and-plates',
                'image' => 'assets/images/all-product/Sheets-Plates.webp',
            ],
            [
                'name' => 'Flanges',
                'url' => 'products/flanges/flanges-and-gaskets',
                'image' => 'assets/images/engineering-steels/engineering-steels-4130.webp',
            ],
            [
                'name' => 'Bars',
                'url' => 'products/bars-rods',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6063.webp',
            ],
            [
                'name' => 'Fittings',
                'url' => 'products/pipe-fittings',
                'image' => 'assets/images/aluminium-alloys/aluminium-alloys-6012.webp',
            ]
        ];
    @endphp

<section id="products" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Products in Engineering Steel D2</h2>
            </div>
            <!-- Highlighted Paragraph -->
            <div class="row justify-content-center mb-4" style="text-align: justify;">
                <div class="col-lg-10">
                    <p class="fs-6">
                        <strong class="text-dark">Engineering Steel D2</strong> is typically available in:
                    </p>
                </div>
            </div>

            <!-- Emphasized Line -->
            <div class="row justify-content-center mb-3">
                <div class="col-lg-10">
                    <p class="fw-bold fs-5 text-center my-4" style="color: #174268;">
                        Engineering Steel D2 products are produced to the following global standards:
                    </p>
                </div>
            </div>

            <!-- Product Image Cards (Now centered and responsive) -->
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4 justify-content-center">
                @foreach ($products as $product)
                    <div class="col d-flex">
                        <a href="{{ url($product['url']) }}" class="text-decoration-none w-100">
                            <div class="product-card h-100">
                                <img src="{{ asset($product['image']) }}" alt="{{ $product['name'] }}"
                                    class="img-fluid w-100">
                                <h6 class="product-card-title text-center mt-0 py-4">{{ $product['name'] }}</h6>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

<section id="uses" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Uses and Advantages</h2>
            </div>

            <div class="row g-4 mt-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Exceptional wear resistance and edge retention</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-droplet-half"></i></div>
                        <h5>Good toughness compared to other high-carbon tool steels</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-thermometer-high"></i></div>
                        <h5>Moderate corrosion resistance due to high chromium content</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Can be air-hardened with minimal distortion</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card">
                        <div class="advantage-icon"><i class="bi bi-building-gear"></i></div>
                        <h5>Excellent dimensional stability during heat treatment</h5>
                    </div>
                </div>
            </div>
    </section>

<section id="applications" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications of Engineering Steel D2</h2>
                <p class="text-center pb-3"><strong class="text-dark">Engineering Steel D2</strong> is widely used in:</p>
            </div>

                        <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-gear-wide-connected"></i></div>
                        <h5>Chemical Processing</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-water"></i></div>
                        <h5>Marine</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Pharmaceutical</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-thermometer-half"></i></div>
                        <h5>Heat Exchangers</h5>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon"><i class="bi bi-lightning-charge"></i></div>
                        <h5>Power Plants</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

                        <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-award-fill"></i></div>
                        <h5>ISO Certified</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-file-earmark-check"></i></div>
                        <h5>MTC 3.1</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast Delivery</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe2"></i></div>
                        <h5>Worldwide Export</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-cash-coin"></i></div>
                        <h5>Competitive Price</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section id="price" class="sec-padd-top sec-padd-bottom bg-light py-5">
        <div class="container">
            <div class="section-title text-center mb-4">
                <h2>D2 Tool Steel Price in India </h2>
            </div>

            <p class="text-center fs-5">
                <strong>Typical Range:</strong> ₹180 – ₹320 per kg
            </p>
            <p class="text-center mb-2">
                (Price varies by OD, wall thickness, form, and finish)
            </p>

            <p class="text-center fs-5">
                Contact us for exact quotation based on size and quantity.
            </p>
        </div>
    </section>
--}}

<section id="faq" class="faq-content-area sec-padd2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!-- Q1 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is EN D2 steel and why is it important in toolmaking?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN D2 is a high-carbon, high-chromium, air-hardening cold work tool steel renowned for
                                    its exceptional wear resistance, toughness, and edge retention.
                                    With a high chromium content of 11–13%, it offers moderate corrosion resistance compared
                                    to other tool steels, making it suitable for applications where tools face both abrasive
                                    wear and mild corrosive conditions.
                                    Due to its ability to maintain dimensional stability during heat treatment, EN D2 is a
                                    preferred choice in toolmaking and industrial applications requiring long lasting
                                    performance.
                                </p>
                            </div>
                        </div>

                        <!-- Q2 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the chemical and mechanical properties of EN D2 steel?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN D2 steel has a chemical composition of 1.40–1.60% carbon, 11–13% chromium, 0.70–1.20%
                                    molybdenum, 0.80–1.20% vanadium, along with controlled amounts of silicon, manganese,
                                    phosphorus, and sulfur.
                                    In terms of mechanical properties, it offers tensile strength of 90–105 ksi (620–724
                                    MPa), yield strength of 70–85 ksi (482–586 MPa), elongation of 8–12%, and hardness of
                                    58–62 HRC after heat treatment.
                                    These properties provide a balance of hardness, strength, and wear resistance that make
                                    EN D2 suitable for high performance tooling and industrial use.
                                </p>
                            </div>
                        </div>

                        <!-- Q3 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What D2 steel products are offered by MOKSH TUBES & FITTINGS LLP?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP supplies a wide range of EN D2 steel products including
                                    seamless and welded pipes, precision tubes, sheets, plates, coils, strips, round bars,
                                    flat bars, square bars, and hex bars.
                                    Additionally, the company manufactures pipe fittings, flanges, fasteners, and
                                    custom fabricated components designed to meet global quality standards.
                                    All products are available in standard and customized specifications to fulfill diverse
                                    industry requirements.
                                </p>
                            </div>
                        </div>

                        <!-- Q4 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the common applications of EN D2 tool steel?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    EN D2 steel is widely used in cold work tooling applications such as dies, punches,
                                    blanking tools, shear blades, and cutting tools that require high wear resistance.
                                    It is also popular in the production of industrial knives and blades for paper, leather,
                                    plastic, and metal cutting.
                                    In mold-making, EN D2 is used for plastic molds and extrusion dies due to its ability to
                                    withstand wear and maintain stability.
                                    Furthermore, it is applied in manufacturing wear resistant machine parts like shafts,
                                    rollers, and dies for heavy duty operations.
                                </p>
                            </div>
                        </div>

                        <!-- Q5 -->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Why choose MOKSH TUBES & FITTINGS LLP for D2 steel materials?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    MOKSH TUBES & FITTINGS LLP is a reliable manufacturer, supplier, and exporter of EN D2
                                    tool steel with large stock availability in multiple sizes and forms.
                                    The company provides precision cutting, heat-treatment guidance, and custom processing
                                    to meet industry-specific needs.
                                    With strong technical expertise, competitive pricing, and a commitment to quality and
                                    timely delivery, MOKSH TUBES & FITTINGS LLP ensures that clients worldwide receive
                                    durable and high performance D2 steel solutions.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

{{-- 
<section class="blog-section sec-padd2">
        <div class="container">
            <div class="section-title">
                <h2>blogs</h2>
            </div>
            <div class="row">
                @foreach ($blogs as $blog)
                    <!-- {{ dd($blog) }} -->
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="default-blog-news wow fadeInUp animated">

                            <figure class="img-holder mb-0">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <img src="{{ asset('storage/' . $blog->cover_image) }}" alt="{{ $blog->title }}"
                                        loading="lazy">
                                </a>
                                <figcaption class="overlay">
                                    <div class="box">
                                        <div class="content">
                                            <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                                <i class="fa fa-link" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                    </div>
                                </figcaption>
                            </figure>
                            <div class="lower-content">
                                <a href="{{ route('frontend.single-blog', $blog->slug) }}">
                                    <h5>{{ Str::limit($blog->title, 30) }}</h5>
                                </a>

                                <div class="post-meta">
                                    by {{ $blog->author ?? 'Admin' }} |
                                    {{ $blog->created_at->format('F d, Y') }}
                                </div>

                                <!--<div class="text">-->
                                <!--</div>-->
                                {!! \Str::limit(strip_tags($blog->content, '<i>'), 120) !!}

                                <div class="link">
                                    <a href="{{ route('frontend.single-blog', $blog->slug) }}" class="default_link">
                                        Read More <i class="fa fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
--}}

<section id="contact-us" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    For inquiries or to request a quote for D2 tool steel products, contact<strong> Moksh Tubes & Fittings
                        LLP</strong> — your dependable partner for high-performance tool steels.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>

    <!-- Extra Sections (Commented Out) -->
{{-- 
<section class="sec-padd-top sec-padd-bottom" id="international">
        <div class="container">
            <div class="section-title center">
                <h2>International Standards & Equivalent Grades — D2 Tool Steel</h2>
            </div>

            <div class="table-responsive col-lg-10 mx-auto">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark text-center">
                        <tr class="t-row">
                            <th>Standard</th>
                            <th>Equivalent Grade</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr class="t-row">
                            <td>AISI / SAE</td>
                            <td>D2</td>
                        </tr>
                        <tr class="t-row">
                            <td>UNS</td>
                            <td>T30402</td>
                        </tr>
                        <tr class="t-row">
                            <td>EN</td>
                            <td>X153CrMoV12 / 1.2379</td>
                        </tr>
                        <tr class="t-row">
                            <td>DIN</td>
                            <td>1.2379</td>
                        </tr>
                        <tr class="t-row">
                            <td>BS</td>
                            <td>BD2</td>
                        </tr>
                        <tr class="t-row">
                            <td>AFNOR</td>
                            <td>Z160CDV12</td>
                        </tr>
                        <tr class="t-row">
                            <td>JIS</td>
                            <td>SKD11</td>
                        </tr>
                        <tr class="t-row">
                            <td>GB</td>
                            <td>Cr12Mo1V1</td>
                        </tr>
                        <tr class="t-row">
                            <td>GOST</td>
                            <td>Х12МФ (Kh12MF)</td>
                        </tr>
                        <tr class="t-row">
                            <td>ISO</td>
                            <td>160CrMoV12</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
--}}

{{-- blog section start --}}

{{-- blog section end --}}

@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
                {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": [
                    {
                    "@type": "Question",
                    "name": "What is EN D2 steel and why is it important in toolmaking?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN D2 is a high-carbon, high-chromium, air-hardening cold work tool steel renowned for its exceptional wear resistance, toughness, and edge retention. With a high chromium content of 11–13%, it offers moderate corrosion resistance compared to other tool steels, making it suitable for applications where tools face both abrasive wear and mild corrosive conditions. Due to its ability to maintain dimensional stability during heat treatment, EN D2 is a preferred choice in toolmaking and industrial applications requiring long lasting performance."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What are the chemical and mechanical properties of EN D2 steel?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN D2 steel has a chemical composition of 1.40–1.60% carbon, 11–13% chromium, 0.70–1.20% molybdenum, 0.80–1.20% vanadium, along with controlled amounts of silicon, manganese, phosphorus, and sulfur. It offers tensile strength of 90–105 ksi, yield strength of 70–85 ksi, elongation of 8–12%, and hardness of 58–62 HRC after heat treatment."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What D2 steel products are offered by MOKSH TUBES & FITTINGS LLP?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "MOKSH TUBES & FITTINGS LLP supplies EN D2 steel products including seamless and welded pipes, precision tubes, sheets, plates, coils, strips, round bars, flat bars, square bars, and hex bars. They also offer pipe fittings, flanges, fasteners, and custom fabricated components in standard and custom specifications."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "What are the common applications of EN D2 tool steel?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "EN D2 steel is used in cold work tooling like dies, punches, blanking tools, shear blades, and cutting tools. It’s also common in industrial knives, mold making, and wear-resistant parts such as shafts and rollers."
                    }
                    },
                    {
                    "@type": "Question",
                    "name": "Why choose MOKSH TUBES & FITTINGS LLP for D2 steel materials?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "MOKSH TUBES & FITTINGS LLP is a trusted manufacturer and exporter of EN D2 steel with large stock availability. They provide precision cutting, heat-treatment guidance, and custom processing, ensuring quality, performance, and timely delivery."
                    }
                    }
                ]
                }

            @endverbatim
    </script>
@endsection


