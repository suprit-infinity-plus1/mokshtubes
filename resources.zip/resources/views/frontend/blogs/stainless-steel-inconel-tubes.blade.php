@extends('layouts.master')

@section('title', 'Stainless Steel vs Inconel Tubes | Moksh Tubes')

@section(
    'meta_description',
    'Compare stainless steel and Inconel tubes — composition, strength, cost, and applications.
    Moksh Tubes offers certified solutions worldwide.'
)


@section('content')
    <!--Start breadcrumb area-->

    <section class="breadcrumb-area" style="background-image: url(images/background/3.jpg);">
        <div class="container text-center">
            <h1>Stainless Steel vs Inconel Tubes</h1>
        </div>
    </section>
    <!--End breadcrumb area-->




    <section id="blog-area" class="blog-with-sidebar-area blog-single-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12">
                    <div class="blog-post">
                        <div class="single-blog-post">
                            <div class="img-holder">
                                <img src="/assets/images/blogs/Inconel-vs-Stainless-Steel.jpg" alt="Inconel vs Stainless Steel">
                            </div>
                            <div class="text-holder">
                                <div class="blog-title text-start">
                                    <h2>Stainless Steel vs Inconel Tubes</h2>
                                </div>
                                <div class="text">
                                    <p>
                                        Choosing between stainless steel and <a
                                            href="{{ route('materials.incoloy') }}">Inconel</a> tubes depends heavily on
                                        your
                                        industrial
                                        needs, environmental conditions, and budget. Both materials offer unique advantages
                                        suited for specific applications. This guide compares their key characteristics,
                                        helping you make an informed decision.
                                    </p>
                                </div>


                                <section class="sec-padd-top">
                                    <div class="container">
                                        <div class="section-title center">
                                            <h2>Composition Comparison</h2>
                                        </div>

                                        <div class="row justify-content-center">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped align-middle">
                                                        <thead class="table-dark text-center">
                                                            <tr class="t-row">
                                                                <th>Material</th>
                                                                <th>Nickel</th>
                                                                <th>Chromium</th>
                                                                <th>Iron</th>
                                                                <th>Carbon</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-center">
                                                            <tr class="t-row">
                                                                <td>Stainless Steel (304 Grade)</td>
                                                                <td>8 - 10.5%</td>
                                                                <td>18 - 20%</td>
                                                                <td>Balance</td>
                                                                <td>0.08%</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Inconel (600 Grade)</td>
                                                                <td>72 - 78%</td>
                                                                <td>14 - 17%</td>
                                                                <td>Balance</td>
                                                                <td>N/A</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <section class="sec-padd-top">
                                    <div class="container">
                                        <div class="section-title center">
                                            <h2 style="color: #174268;">Mechanical Properties</h2>
                                        </div>

                                        <!-- Mechanical Properties Table -->
                                        <div class="row justify-content-center mb-5">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped align-middle">
                                                        <thead class="table-dark text-center">
                                                            <tr class="t-row">
                                                                <th>Property</th>
                                                                <th>Stainless Steel 304</th>
                                                                <th>Inconel 600</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-center">
                                                            <tr class="t-row">
                                                                <td>Tensile Strength</td>
                                                                <td>520 MPa</td>
                                                                <td>690 MPa</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Yield Strength</td>
                                                                <td>215 MPa</td>
                                                                <td>275 MPa</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Elongation</td>
                                                                <td>40%</td>
                                                                <td>40%</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Hardness</td>
                                                                <td>70 HRB</td>
                                                                <td>90 HRB</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Fabrication & Cost Considerations Table -->

                                        <div class="row justify-content-center">
                                            <div class="col-lg-12">
                                                <div class="section-title center mb-5">
                                                    <h2 style="color: #174268;">Fabrication & Cost
                                                        Considerations</h2>
                                                </div>
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped align-middle">
                                                        <thead class="table-dark text-center">
                                                            <tr class="t-row">
                                                                <th>Aspect</th>
                                                                <th>Stainless Steel</th>
                                                                <th>Inconel</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-center">
                                                            <tr class="t-row">
                                                                <td>Machinability</td>
                                                                <td>Easy to machine and weld</td>
                                                                <td>Difficult; requires specialized tooling</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Fabrication Cost</td>
                                                                <td>Low to moderate</td>
                                                                <td>High (5-10x more expensive)</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <section class="sec-padd-top">
                                    <div class="container">
                                        <div class="section-title center">
                                            <h2>Performance Characteristics</h2>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-6 col-lg-6">
                                                <div class="advantage-card">
                                                    <div class="advantage-icon"><i class="fas fa-thermometer-half"></i>
                                                    </div>
                                                    <h3 class="h4">Temperature Resistance</h3>
                                                    <ul>
                                                        <li><strong>Stainless Steel:</strong> Maintains strength up to
                                                            ~870°C (1600°F)</li>
                                                        <li><strong>Inconel:</strong> Maintains integrity up to ~1093°C
                                                            (2000°F)</li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <div class="col-sm-6 col-lg-6">
                                                <div class="advantage-card">
                                                    <div class="advantage-icon"><i class="fas fa-shield-alt"></i></div>
                                                    <h3 class="h4">Corrosion Resistance</h3>
                                                    <ul>
                                                        <li><strong>Stainless Steel:</strong> Good general corrosion
                                                            resistance; best for
                                                            mild to moderate environments.</li>
                                                        <li><strong>Inconel:</strong> Superior resistance to acids,
                                                            saltwater, chlorides;
                                                            ideal for harsh chemical and marine environment</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <section class="sec-padd-top">
                                    <div class="container">
                                        <div class="section-title center">
                                            <h2>Recommended Applications</h2>
                                        </div>

                                        <div class="row justify-content-center">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped align-middle">
                                                        <thead class="table-dark text-center">
                                                            <tr class="t-row">
                                                                <th>Stainless Steel Tubes</th>
                                                                <th>Inconel Tubes</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-center">
                                                            <tr class="t-row">
                                                                <td>Food processing equipment</td>
                                                                <td>Aerospace (jet engines, gas turbines)</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Construction and structural components</td>
                                                                <td>Chemical processing (extreme conditions)</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Chemical processing (moderate conditions)</td>
                                                                <td>Power generation</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Household and kitchen appliances</td>
                                                                <td>Heat exchangers</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>General industrial equipment</td>
                                                                <td>Marine engineering</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td></td>
                                                                <td>Nuclear industry</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td></td>
                                                                <td>Oil and gas (sour gas environments)</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                                <section class="sec-padd-top">
                                    <div class="container">
                                        <div class="section-title center">
                                            <h2>Material Selection Criteria</h2>
                                        </div>

                                        <div class="row justify-content-center">
                                            <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-striped align-middle">
                                                        <thead class="table-dark text-center">
                                                            <tr class="t-row">
                                                                <th>Choose Stainless Steel When</th>
                                                                <th>Choose Inconel When</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-center">
                                                            <tr class="t-row">
                                                                <td>Cost is a primary concern</td>
                                                                <td>Extreme temperature resistance is crucial</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Operating conditions are moderate</td>
                                                                <td>High corrosion resistance is mandatory</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>Easy fabrication is required</td>
                                                                <td>Performance in harsh environments is critical</td>
                                                            </tr>
                                                            <tr class="t-row">
                                                                <td>General corrosion resistance suffices</td>
                                                                <td>Failure is not an option</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>



                                <!--Start faq content area-->
                                <section class="faq-content-area sec-padd-top">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="accordion-box">
                                                    <div class="blog-title text-ceanter">
                                                        <h2>FAQ's</h2>
                                                    </div>
                                                    <!--Start single accordion box-->
                                                    <div class="accordion accordion-block">
                                                        <div class="accord-btn">
                                                            <h3> What is the main difference between stainless steel and
                                                                Inconel tubes?</h3>
                                                        </div>
                                                        <div class="accord-content">
                                                            <p>Stainless steel contains less nickel and chromium than
                                                                Inconel, making it less resistant to extreme heat and
                                                                corrosion. Inconel is preferred for high-temperature, highly
                                                                corrosive environments.</p>
                                                        </div>
                                                    </div>
                                                    <!--End single accordion box-->
                                                    <!--Start single accordion box-->
                                                    <div class="accordion accordion-block">
                                                        <div class="accord-btn ">
                                                            <h3>When should I use stainless steel tubes instead of Inconel?
                                                            </h3>
                                                        </div>
                                                        <div class="accord-content ">
                                                            <p>Use stainless steel tubes for moderate operating conditions,
                                                                where cost and ease of fabrication are priorities, and
                                                                corrosion levels are not severe.</p>
                                                        </div>
                                                    </div>
                                                    <!--End single accordion box-->
                                                    <!--Start single accordion box-->
                                                    <div class="accordion accordion-block">
                                                        <div class="accord-btn">
                                                            <h3>Are Inconel tubes more expensive than stainless steel tubes?
                                                            </h3>
                                                        </div>
                                                        <div class="accord-content">
                                                            <p>Yes, Inconel tubes cost 5 to 10 times more than stainless
                                                                steel due to their superior performance and specialized
                                                                manufacturing requirements.</p>
                                                        </div>
                                                    </div>
                                                    <!--End single accordion box-->
                                                    <!--Start single accordion box-->
                                                    <div class="accordion accordion-block">
                                                        <div class="accord-btn">
                                                            <h3>Can stainless steel tubes be used in marine environments?
                                                            </h3>
                                                        </div>
                                                        <div class="accord-content">
                                                            <p>Stainless steel offers good corrosion resistance but may be
                                                                vulnerable to certain marine corrosives. Inconel is
                                                                recommended for harsher marine and chemical environments.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <!--End single accordion box-->
                                                    <!--Start single accordion box-->
                                                    <div class="accordion accordion-block">
                                                        <div class="accord-btn">
                                                            <h3>What industries typically use Inconel tubes?
                                                            </h3>
                                                        </div>
                                                        <div class="accord-content">
                                                            <p>Inconel tubes are commonly used in aerospace, power
                                                                generation, chemical processing, marine engineering,
                                                                nuclear, and oil and gas sectors where extreme conditions
                                                                exist.</p>
                                                        </div>
                                                    </div>
                                                    <!--End single accordion box-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <!--End faq content area-->


                                <section class="sec-padd-top ">
                                    <div class="container">
                                        <div class="section-title center">
                                            <h2>Conclusion</h2>
                                        </div>
                                        <div class="row align-items-center">
                                            <div class="col-md-12">
                                                <div class="pe-md-3">
                                                    <p class="fs-6 mb-4 text-justify" style="text-align: justify;">
                                                        Selecting between stainless steel and Inconel tubes hinges on your
                                                        industrial requirements, environmental conditions, and budget
                                                        constraints. Stainless steel is ideal for cost-effective
                                                        applications with moderate conditions, while Inconel excels in
                                                        extreme environments demanding superior strength and corrosion
                                                        resistance.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>


                            </div>
                        </div>
                    </div>
                </div>
                <!--Start sidebar Wrapper-->
                <div class="col-lg-3 col-md-4 col-sm-7 col-xs-12">
                    <div class="sidebar-wrapper black-box">
                        <!--Start single sidebar-->
                        <div class="container ">
                            <div class="row justify-content-center">
                                <div class="col-md-12">
                                    <h4 class="fw-bold mb-4">Products We Offer</h4>
                                    <ul class="list-unstyled mb-4">
                                        <li class="product-item mb-2">
                                            <a href="{{ route('products.pipes-tubes') }}" class="product-link">
                                                <i class="bi bi-box-seam me-2"></i> Pipes & Tubes
                                            </a>
                                        </li>
                                        <li class="product-item mb-2">
                                            <a href="{{ route('products.sheets-plates-coils') }}" class="product-link">
                                                <i class="bi bi-square me-2"></i> Sheets, Plates & Coils
                                            </a>
                                        </li>
                                        <li class="product-item mb-2">
                                            <a href="{{ route('products.bars-rods') }}" class="product-link">
                                                <i class="bi bi-diagram-3 me-2"></i> Bars & Rods
                                            </a>
                                        </li>
                                        <li class="product-item mb-2">
                                            <a href="{{ route('products.special-fabricated') }}" class="product-link">
                                                <i class="bi bi-tools me-2"></i> Special Fabricated
                                            </a>
                                        </li>
                                        <li class="product-item mb-2">
                                            <a href="{{ route('products.pipe-fittings-flanges-fasteners') }}"
                                                class="product-link">
                                                <i class="bi bi-nut me-2"></i> Pipe Fittings, Flanges & Fasteners
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-md-12">
                                    <h4 class="fw-bold mb-4">Categories</h4>
                                    <ul class="list-unstyled mb-4">
                                        <li class="category-item mb-2">
                                            <a  class="category-link">
                                                <i class="bi bi-building me-2"></i> Architecture Plans
                                            </a>
                                        </li>
                                        <li class="category-item mb-2">
                                            <a  class="category-link">
                                                <i class="bi bi-hammer me-2"></i> Construction Projects
                                            </a>
                                        </li>
                                        <li class="category-item mb-2">
                                            <a  class="category-link">
                                                <i class="bi bi-brush me-2"></i> Paintings
                                            </a>
                                        </li>
                                        <li class="category-item mb-2">
                                            <a  class="category-link">
                                                <i class="bi bi-lightning-charge me-2"></i> Electrical Works
                                            </a>
                                        </li>
                                        <li class="category-item mb-2">
                                            <a  class="category-link">
                                                <i class="bi bi-tools me-2"></i> Plumbing Works
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!--End single sidebar-->
                        <!--Start single sidebar-->
                        <div class="single-sidebar">
                            <div class="sec-title">
                                <h3>Recent Blogs</h3>
                            </div>
                            <ul class="recent-post">
                                <li>
                                    <div class="img-holder">
                                        <img src="{{ asset('assets/images/blogs/thumb/why-hastelloy-weighs-more-than-stainless-steel-thumb.webp') }}"
                                            alt="Why Hastelloy Weighs More Than Stainless Steel" loading="lazy">
                                        <div class="overlay-style-two">
                                            <div class="box">
                                                <div class="content">
                                                    <a href="{{ route('blogs.why-hastelloy-weighs-more-than-stainless-steel') }}"
                                                        aria-label="blog: why hastelloy weighs moe than stainless steel">
                                                        <i class="fa fa-link" aria-hidden="true"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="title-holder">
                                        <a href="{{ route('blogs.why-hastelloy-weighs-more-than-stainless-steel') }}">
                                            <h5 class="post-title">
                                                Why Hastelloy Weighs More Than Stainless Steel
                                            </h5>
                                        </a>
                                        <h6 class="post-date">
                                            <i class="icon-calendar-with-spring-binder-and-date-blocks"></i>
                                            august 14, 2025
                                        </h6>
                                    </div>
                                </li>
                                <li>
                                    <div class="img-holder">
                                        <img src="{{ asset('assets/images/blogs/thumb/the-role-of-high-performance-alloys-in-desalination-plants-thumb.webp') }}"
                                            alt="The Role of High-Performance Alloys in Desalination Plants" loading="lazy">
                                        <div class="overlay-style-two">
                                            <div class="box">
                                                <div class="content">
                                                    <a href="{{ route('blogs.the-role-of-high-performance') }}"
                                                        aria-label="blogs: the role of high performance">
                                                        <i class="fa fa-link" aria-hidden="true"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="title-holder">
                                        <a href="{{ route('blogs.the-role-of-high-performance') }}">
                                            <h5 class="post-title">
                                                The Role of High Performance Alloys in Desalination Plants
                                            </h5>
                                        </a>
                                        <h6 class="post-date">
                                            <i class="icon-calendar-with-spring-binder-and-date-blocks"></i>
                                            august 14, 2025
                                        </h6>
                                    </div>
                                </li>
                                <li>
                                    <div class="img-holder">
                                        <img src="{{ asset('assets/images/blogs/thumb/indias-stainless-steel-export-industry-thumb.webp') }}"
                                            alt="India's Stainless Steel Export Industry" loading="lazy">
                                        <div class="overlay-style-two">
                                            <div class="box">
                                                <div class="content">
                                                    <a href="{{ route('blogs.indias-stainless-steel-export-industry') }}"
                                                        aria-label="blog:indias-stainless-steel-export-industry">
                                                        <i class="fa fa-link" aria-hidden="true"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="title-holder">
                                        <a href="{{ route('blogs.indias-stainless-steel-export-industry') }}">
                                            <a href="{{ route('blogs.indias-stainless-steel-export-industry') }}">
                                                <h5 class="post-title">
                                                    India’s Stainless Steel Exports – Moksh Tubes Global Reach
                                                </h5>
                                            </a>
                                            <h6 class="post-date">
                                                <i class="icon-calendar-with-spring-binder-and-date-blocks"></i>
                                                august 14, 2025
                                            </h6>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <!--End single sidebar-->
                        <div class="container my-5">
                            <div class="row justify-content-center">
                                <div class="col-md-12">
                                    <div class="card-body ">
                                        <!-- Heading -->
                                        <div class="section-title">
                                            <h2>Locate <span class="thm-color">Us</span></h2>
                                            {{-- <p>Let’s forge a connection — contact our team today.</p> --}}
                                        </div>


                                        <!-- Contact Info -->
                                        <p class="mb-2"><i class="bi bi-envelope me-2 text-primary"></i>
                                            info@mokshtubes.com</p>
                                        <p class="mb-2"><i class="bi bi-geo-alt me-2 text-danger"></i>
                                            <strong>Office Address:</strong> Hinglaj Bhavan, Gulalwadi Mumbai, Maharashtra.
                                            400004
                                        </p>
                                        <p class="mb-2"><i class="bi bi-geo-alt me-2 text-success"></i>
                                            <strong>Office Address:</strong> 6/A, Ground Floor, Rajwanti Mansion, Khetwadi
                                            Mumbai
                                        </p>
                                        <p class="mb-2"><i class="bi bi-geo-alt me-2 text-info"></i>
                                            <strong>Office Address:</strong> 95/95A, Dawood Baug, Sukhlaji Street,
                                            Kamatipura Mumbai
                                        </p>
                                        <p class="mb-2"><i class="bi bi-geo-alt me-2 text-danger"></i>
                                            <strong>Office Address:</strong> 92E, Plot No. 3, New Tank Bunder, Darukhana,
                                            Mumbai,
                                            Maharashtra- 400 010.
                                        </p>

                                        <!-- Social Icons -->
                                        {{-- <div class="mt-3 text-center">
                                            <a href="https://wa.me/+919769584950"
                                                class="btn btn-outline-success btn-sm rounded-circle me-2"
                                                aria-label="contact us on whatsapp"><i class="bi bi-whatsapp"></i></a>
                                            <a href="https://www.instagram.com/mokshtubesandfittingsllp/"
                                                class="btn btn-outline-dark btn-sm rounded-circle me-2"
                                                aria-label="follow us on instagram"><i class="bi bi-instagram"></i></a>
                                            <a href="https://www.facebook.com/mokshtubes/"
                                                class="btn btn-outline-primary btn-sm rounded-circle me-2"
                                                aria-label="follow us on facebook"><i class="bi bi-facebook"></i></a>
                                            <a href="https://www.linkedin.com/company/moksh-tubes/"
                                                class="btn btn-outline-info btn-sm rounded-circle"
                                                aria-label="follow us on linkedin"><i class="bi bi-linkedin"></i></a>
                                            <a href="https://x.com/Moksh_Tubes"
                                                class="btn btn-outline-info btn-sm rounded-circle"
                                                aria-label="follow us on x"><i class="fab fa-x-twitter"></i></a>

                                        </div> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{-- Start contant form --}}
                        <section class="blog-contact-form">
                            <div class="section-title">
                                <h2>get in <span class="thm-color">touch</span></h2>
                                <p>Let’s forge a connection — contact our team today.</p>
                            </div>

                            <form id="contact-form" name="contact_form" class="default-form" action="{{ url('sendmail') }}"
                                method="post">
                                @csrf
                                <div class="row">
                                    <div class="col-md-12">
                                        <input class="m-1" type="text" name="form_name" placeholder="Your Name*"
                                            required="">
                                    </div>
                                    <div class="col-md-12">
                                        <input class="m-1" type="email" name="form_email" placeholder="Your Mail*"
                                            required="">
                                    </div>
                                    <div class="col-md-12">
                                        <input class="m-1" type="text" name="form_phone" placeholder="Phone">
                                    </div>
                                    <div class="col-md-12">
                                        <input class="m-1" type="text" name="form_subject" placeholder="Subject">
                                    </div>
                                    <div class="col-md-12">
                                        <textarea name="form_message" class="m-1" placeholder="Your Message.."
                                            required=""></textarea>
                                    </div>
                                    <div class="col-md-12">
                                        <input id="form_botcheck" name="form_botcheck" type="hidden" value="">
                                        <button class="thm-btn bg-clr1 m-1" type="submit"
                                            data-loading-text="Please wait...">
                                            send message
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </section>
                        {{-- End contant form --}}

                    </div>
                </div>
                <!--End Sidebar Wrapper-->
            </div>
        </div>
    </section>
    <section class="pt-4 mb-5 col-12">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    AT<strong> Moksh Tubes & Fittings LLP</strong>, we’re dedicated to making
                    your purchases seamless offering expert advice, a wide inventory of
                    certified products, and global support for every order, large or small.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Get in Touch
                </a>
            </div>
        </div>
    </section>



@endsection