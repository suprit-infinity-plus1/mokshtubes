@extends('layouts.master')
@section('title', 'Flange Gaskets – High-Temperature & Chemical Resistant') <!-- 53 characters -->
@section('meta_description', 'Premium flange gaskets from Moksh Tubes — spiral wound, RTJ, rubber, and non-metallic
    types for reliable industrial and high-temperature sealing.') <!-- 153 characters -->
@section('meta_keywords',
    'Flange Gaskets, Industrial Gaskets, Spiral Wound Gaskets, RTJ Gaskets, Rubber Gaskets,
    Chemical Resistant Gaskets, Non-Metallic Gaskets, Sealing Solutions')
@section('og_image', asset('assets/images/product/flangs/Flange-Gaskets.webp'))
@section('og_type', 'article')
@section('content')
    <!--Start breadcrumb area-->
    <section class="breadcrumb-area" style="background-image: url(/assets/images/product/flangs/Flange-Gaskets.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Premium Industrial Flange Gaskets for Sealing</h1> <!-- 52 characters -->
                </div>
            </div>
        </div>
    </section>



    <section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-4">
                <h2 class="fw-bold" style="color: #174268;">Flange & Industrial Gaskets</h2>
            </div>

            <div class="row align-items-center">
                <!-- Left Image -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/product/flangs/Flange-Gaskets.webp') }}"
                        alt="Flange-Industrial-Gaskets" class="img-fluid rounded shadow-sm">
                </div>

                <!-- Right Content -->
                <div class="col-md-6">
                    <p class="fs-6 mb-3 text-justify">
                        Gaskets are essential sealing components used to create a pressure tight seal between two or more
                        mating surfaces, preventing leakage of liquids or gases under various operating conditions.
                    </p>
                    <p class="fs-6 mb-3 text-justify">
                        They are commonly installed between flanges and gaskets, valves, pumps, compressors, and other
                        mechanical connections in industries where high pressure, temperature, and corrosive media are
                        present.
                    </p>
                    <p class="fs-6 text-justify">
                        <a href="{{ route('index') }}">Moksh Tubes & Fittings LLP</a>, we supply a comprehensive range of
                        industrial gaskets and seals – from
                        standard flange gaskets, head gaskets, and rubber gaskets to <a
                            href="{{ url('products/pipe-fittings-flanges-fasteners/custom-fabricated-fittings') }}">custom
                            engineered</a> sealing solutions. We
                        also provide PTFE gaskets, spiral wound gaskets, graphite gaskets, metal gaskets, and non asbestos
                        gaskets.
                </div>
            </div>
        </div>
    </section>

    <section class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Specifications</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody class="text-start">
                                <tr class="t-row">
                                    <td>Category</td>
                                    <td>
                                        Non Metallic (Rubber gaskets, PTFE gaskets, Non Asbestos gaskets, Graphite gaskets)
                                        <br>
                                        Semi Metallic (Spiral Wound gaskets, Corrugated, Kammprofile gaskets) <br>
                                        Metallic (Stainless Steel gaskets, Soft Iron, Inconel)
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Thickness</td>
                                    <td>0.5 mm to 12 mm (special thicknesses on request)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Sizes</td>
                                    <td>½” NB to 72” NB (custom gaskets available for large flanges & vessels)</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Types</td>
                                    <td>
                                        Spiral wound gaskets, Ring Type Joint (RTJ) gaskets, Metal Jacketed, Kammprofile
                                        gaskets,
                                        Soft Cut, Non-asbestos gaskets, Rubber gaskets, PTFE envelope gaskets
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Pressure Class</td>
                                    <td>Class 150 to Class 2500 / PN6 to PN400</td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2 class="fw-bold" style="color: #174268;">Charts</h2>


            </div>
            <!-- Child Title -->
            <div class="section-title center mb-3">
                <h3 class="text-center mb-0" style="color: #db7227;">Weight Chart</h3>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle text-center">
                    <thead class="table-dark">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Nominal Pipe Size (NPS)</th>
                                    <th>Flange Class</th>
                                    <th>Inside Diameter (ID) mm</th>
                                    <th>Outside Diameter (OD) mm</th>
                                    <th>Bolt Circle Dia. (BCD) mm</th>
                                    <th>Number of Bolts</th>
                                    <th>Bolt Hole Dia. mm</th>
                                </tr>
                            </thead>
                            <tbody class="text-start">
                                <tr class="t-row">
                                    <td>½" (DN 15)</td>
                                    <td>150</td>
                                    <td>21.3</td>
                                    <td>47</td>
                                    <td>35</td>
                                    <td>4</td>
                                    <td>16</td>
                                </tr>
                                <tr class="t-row">
                                    <td>¾" (DN 20)</td>
                                    <td>150</td>
                                    <td>26.7</td>
                                    <td>57</td>
                                    <td>43</td>
                                    <td>4</td>
                                    <td>16</td>
                                </tr>
                                <tr class="t-row">
                                    <td>1" (DN 25)</td>
                                    <td>150</td>
                                    <td>33.4</td>
                                    <td>66</td>
                                    <td>51</td>
                                    <td>4</td>
                                    <td>16</td>
                                </tr>
                                <tr class="t-row">
                                    <td>1 ½" (DN 40)</td>
                                    <td>150</td>
                                    <td>48.3</td>
                                    <td>82</td>
                                    <td>73</td>
                                    <td>4</td>
                                    <td>16</td>
                                </tr>
                                <tr class="t-row">
                                    <td>2" (DN 50)</td>
                                    <td>150</td>
                                    <td>60.3</td>
                                    <td>104</td>
                                    <td>92</td>
                                    <td>4</td>
                                    <td>19</td>
                                </tr>
                                <tr class="t-row">
                                    <td>2 ½" (DN 65)</td>
                                    <td>150</td>
                                    <td>73</td>
                                    <td>123</td>
                                    <td>105</td>
                                    <td>4</td>
                                    <td>19</td>
                                </tr>
                                <tr class="t-row">
                                    <td>3" (DN 80)</td>
                                    <td>150</td>
                                    <td>89</td>
                                    <td>133</td>
                                    <td>127</td>
                                    <td>4</td>
                                    <td>19</td>
                                </tr>
                                <tr class="t-row">
                                    <td>4" (DN 100)</td>
                                    <td>150</td>
                                    <td>114</td>
                                    <td>173</td>
                                    <td>157</td>
                                    <td>8</td>
                                    <td>19</td>
                                </tr>
                                <tr class="t-row">
                                    <td>5" (DN 125)</td>
                                    <td>150</td>
                                    <td>141</td>
                                    <td>200</td>
                                    <td>186</td>
                                    <td>8</td>
                                    <td>22</td>
                                </tr>
                                <tr class="t-row">
                                    <td>6" (DN 150)</td>
                                    <td>150</td>
                                    <td>168</td>
                                    <td>228</td>
                                    <td>216</td>
                                    <td>8</td>
                                    <td>22</td>
                                </tr>
                                <tr class="t-row">
                                    <td>8" (DN 200)</td>
                                    <td>150</td>
                                    <td>219</td>
                                    <td>285</td>
                                    <td>270</td>
                                    <td>8</td>
                                    <td>22</td>
                                </tr>
                                <tr class="t-row">
                                    <td>10" (DN 250)</td>
                                    <td>150</td>
                                    <td>273</td>
                                    <td>343</td>
                                    <td>324</td>
                                    <td>12</td>
                                    <td>25</td>
                                </tr>
                                <tr class="t-row">
                                    <td>12" (DN 300)</td>
                                    <td>150</td>
                                    <td>324</td>
                                    <td>406</td>
                                    <td>381</td>
                                    <td>12</td>
                                    <td>25</td>
                                </tr>
                                <tr class="t-row">
                                    <td>14" (DN 350)</td>
                                    <td>150</td>
                                    <td>356</td>
                                    <td>438</td>
                                    <td>413</td>
                                    <td>12</td>
                                    <td>29</td>
                                </tr>
                                <tr class="t-row">
                                    <td>16" (DN 400)</td>
                                    <td>150</td>
                                    <td>406</td>
                                    <td>489</td>
                                    <td>470</td>
                                    <td>16</td>
                                    <td>29</td>
                                </tr>
                                <tr class="t-row">
                                    <td>18" (DN 450)</td>
                                    <td>150</td>
                                    <td>457</td>
                                    <td>546</td>
                                    <td>533</td>
                                    <td>16</td>
                                    <td>32</td>
                                </tr>
                                <tr class="t-row">
                                    <td>20" (DN 500)</td>
                                    <td>150</td>
                                    <td>508</td>
                                    <td>610</td>
                                    <td>584</td>
                                    <td>20</td>
                                    <td>32</td>
                                </tr>
                                <tr class="t-row">
                                    <td>24" (DN 600)</td>
                                    <td>150</td>
                                    <td>610</td>
                                    <td>720</td>
                                    <td>692</td>
                                    <td>20</td>
                                    <td>35</td>
                                </tr>
                            </tbody>
                        </table>

            </div>
        </div>
    </section>




    {{-- Grades Available --}}
    <section class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Grades Available</h2>
            </div>
            <div class="section-title center mb-3">
                <h4 class="text-center mb-0" style="color: #db7227;"><strong>Gaskets</strong> is
                    manufactured in a wide range of grades, ensuring suitability for different applications, environments,
                    and design goals:</h4>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Material</th>
                                    <th>Grades / Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td>Stainless Steel Grades</td>
                                    <td>304, 304L, <a
                                            href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-316') }}">316,
                                            316L</a> <br>
                                        <small>(Used for spiral wound gaskets & metallic gaskets)</small>
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Alloys</td>
                                    <td><a href="{{ route('materials.inconel') }}">Inconel</a>, <a
                                            href="{{ route('materials.monel') }}">Monel</a>, <a
                                            href="{{ route('materials.hastelloy') }}">Hastelloy</a> <br>
                                        <small>(For high temperature gaskets)</small>
                                    </td>
                                </tr>
                                <tr class="t-row">
                                    <td>Soft Materials</td>
                                    <td>Graphite gasket sheet, PTFE gasket sheet, Rubber gasket sheet, Cork gasket sheet,
                                        Foam gaskets</td>
                                </tr>
                                <tr class="t-row">
                                    <td>Specialty</td>
                                    <td>Ceramic gaskets, Butyl gaskets, Polyurethane gaskets, EMI gaskets</td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- Gallery --}}



    {{-- Applications --}}
    <section class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center">
                <h2>Applications</h2>
                <p class="text-center pb-3">
                    <strong class="text-black">Gaskets</strong> is versatile and used across a variety of
                    industries and settings:
                </p>
            </div>

            <div class="row g-4">
                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon">
                            <i class="bi bi-fuel-pump-fill"></i>
                        </div>
                        <h5>Oil, Gas & Petrochemical</h5>
                        <ul>
                            <li>RTJ gaskets</li>
                            <li>Spiral wound gaskets</li>
                            <li>Heat exchanger gaskets</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon">
                            <i class="bi bi-lightning-charge-fill"></i>
                        </div>
                        <h5>Power Generation</h5>
                        <ul>
                            <li>Boiler gaskets</li>
                            <li>Steam gaskets</li>
                            <li>Exhaust manifold gaskets</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon">
                            <i class="bi bi-truck-front-fill"></i>
                        </div>
                        <h5>Marine & Shipbuilding</h5>
                        <ul>
                            <li>Rubber gaskets</li>
                            <li>PTFE gaskets</li>
                            <li>Non-asbestos gaskets</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon">
                            <i class="bi bi-building-gear"></i>
                        </div>
                        <h5>Chemical Industry</h5>
                        <ul>
                            <li>Graphite gaskets</li>
                            <li>PTFE envelope gaskets</li>
                            <li>Acid-resistant gaskets</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon">
                            <i class="bi bi-capsule-pill"></i>
                        </div>
                        <h5>Food & Pharma</h5>
                        <ul>
                            <li>Silicone gaskets</li>
                            <li>PTFE sanitary gaskets</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-12 col-lg-4">
                    <div class="application-card">
                        <div class="application-icon">
                            <i class="bi bi-building"></i>
                        </div>
                        <h5>Construction</h5>
                        <ul>
                            <li>Pipe gaskets</li>
                            <li>Rubber door gaskets</li>
                            <li>Window gaskets</li>
                        </ul>
                    </div>
                </div>
            </div>

            {{-- <p class="text-center pb-3 my-4"><strong class="text-dark">HASTELLOY C-276's</strong> unique combination of
                corrosion resistance, weldability, and mechanical durability makes it a reliable material for
                mission-critical applications where long-term performance is non-negotiable.

            </p> --}}
        </div>
    </section>

    {{-- Uses of Welded Pipes and Tubes --}}




    {{-- why choose us --}}
    <section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>WHY CHOOSE US?</h2>
            </div>

            <div class="row g-4 mt-4">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-layers-fill"></i></div>
                        <h5>Wide Range: Rubber gaskets, PTFE gaskets, spiral wound gaskets, RTJ gaskets, cork gaskets,
                            graphite gaskets.</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-patch-check-fill"></i></div>
                        <h5>Certified Quality: ISO 9001:2015, MTC with full traceability.</h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe-americas"></i></div>
                        <h5>Global Supply: Exporting industrial gaskets across oil & gas, power, and chemical industries.
                        </h5>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-gear-fill"></i></div>
                        <h5>Custom Engineering: Custom gasket manufacturing, die-cut gaskets, cork rubber gasket material.
                        </h5>
                    </div>
                </div>

                <div class="col-sm-12 col-lg-6">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-lightning-fill"></i></div>
                        <h5>Quick Dispatch: Ready stock for urgent needs.</h5>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!--Start faq content area-->
    <section class="faq-content-area sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ's</h2>
                        </div>

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is a gasket?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    A gasket is a mechanical sealing component placed between two surfaces to prevent
                                    leakage of fluids or gases.
                                    Industrial gaskets are widely used in pipelines, heat exchangers, valves, and flanges to
                                    ensure a secure seal under high pressure and temperature.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Which gasket material is best?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    The best gasket material depends on the application. Rubber gaskets work well for
                                    low-temperature sealing,
                                    PTFE gaskets are ideal for chemical resistance, while metal gaskets like spiral wound or
                                    ring-type joints are best for high-pressure, high-temperature environments.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What are the different types of gaskets?</h4>
                            </div>
                            <div class="accord-content">
                                <p>Common types of gaskets include:</p>
                                <ul>
                                    <li>Spiral Wound Gaskets</li>
                                    <li>Ring Type Joint (RTJ) Gaskets</li>
                                    <li>Graphite Gaskets</li>
                                    <li>PTFE Gaskets</li>
                                    <li>Rubber Gaskets</li>
                                    <li>Non-Asbestos Gaskets</li>
                                </ul>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>How do I choose the right gasket for my project?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    To select the right industrial gasket, consider factors like pressure, temperature,
                                    fluid type, and flange design.
                                    Consulting with experts like <b>Mokshtubes Fittings LLP</b> ensures you get the correct
                                    gasket material for long-term performance.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->

                        <!--Start single accordion box-->
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What industries use gaskets?</h4>
                            </div>
                            <div class="accord-content">
                                <p>
                                    Gaskets are essential in industries such as oil & gas, petrochemicals, power generation,
                                    marine, pharmaceuticals,
                                    and food processing, where reliable sealing is critical to safety and efficiency.
                                </p>
                            </div>
                        </div>
                        <!--End single accordion box-->


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End faq content area-->

    <section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Contact Us</h2>
                <p>
                    Looking for gasket manufacturers in India or a reliable gasket supplier?<br>Contact <strong><a
                            href="{{ route('index') }}">Moksh Tubes & Fittings LLP</a></strong>
                </p>
                <!-- Call button -->
                <a href="tel:+919769584950" class="contact-cta-btn">Get in Touch</a>
            </div>
        </div>
    </section>

    <!--End breadcrumb area-->


@endsection
@section('jsscripts')
    <script type="application/ld+json">
        @verbatim
            {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                "@type": "Question",
                "name": "What is a gasket?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "A gasket is a mechanical sealing component placed between two surfaces to prevent leakage of fluids or gases. Industrial gaskets are widely used in pipelines, heat exchangers, valves, and flanges to ensure a secure seal under high pressure and temperature."
                }
                },
                {
                "@type": "Question",
                "name": "Which gasket material is best?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "The best gasket material depends on the application. Rubber gaskets work well for low-temperature sealing, PTFE gaskets are ideal for chemical resistance, while metal gaskets like spiral wound or ring-type joints are best for high-pressure, high-temperature environments."
                }
                },
                {
                "@type": "Question",
                "name": "What are the different types of gaskets?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Common types of gaskets include Spiral Wound Gaskets, Ring Type Joint (RTJ) Gaskets, Graphite Gaskets, PTFE Gaskets, Rubber Gaskets, and Non-Asbestos Gaskets."
                }
                },
                {
                "@type": "Question",
                "name": "How do I choose the right gasket for my project?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "To select the right industrial gasket, consider factors like pressure, temperature, fluid type, and flange design. Consulting with experts like Mokshtubes Fittings LLP ensures you get the correct gasket material for long-term performance."
                }
                },
                {
                "@type": "Question",
                "name": "What industries use gaskets?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Gaskets are essential in industries such as oil & gas, petrochemicals, power generation, marine, pharmaceuticals, and food processing, where reliable sealing is critical to safety and efficiency."
                }
                }
            ]
            }
        
        @endverbatim
    </script>
    <!-- Datasheet Download -->
    <section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download Flanges And Gaskets Datasheet</h3>
            <p class="mb-3">
                Get the complete Flanges And Gaskets datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>
@endsection
