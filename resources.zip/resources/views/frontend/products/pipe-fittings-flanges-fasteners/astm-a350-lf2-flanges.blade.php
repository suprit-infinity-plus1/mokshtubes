@extends('layouts.master')

@section('title', 'ASTM A350 LF2 Flanges Supplier UAE, Saudi | Low Temp CS Flanges')
@section('meta_description', 'ASTM A350 LF2 flanges exporter to UAE, Saudi Arabia, Qatar & Oman. Low-temperature carbon
    steel flanges for cryogenic & industrial use.')
@section('meta_keywords', 'ASTM A350 LF2 Flanges, LF2 Flanges, Low Temperature Carbon Steel Flanges, Moksh Tubes')
@section('og_image', asset('assets/images/fasteners/astm-a350-lf2-flanges_11zon.jpg'))
@section('og_type', 'product')
@section('content')

    <!--Start breadcrumb area (Hero Section)-->
    <section class="breadcrumb-area" style="background-image: url(/assets/images/fasteners/astm-a350-lf2-flanges_11zon.jpg);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>ASTM A350 LF2 Flanges <br> Supplier & Exporter</h1>
                    <!-- Short Introduction -->
                    <p class="text-center mt-3 px-3 py-2 text-white position-relative"
                        style="background:rgba(0,0,0,0.4); display:inline-block; border-radius:6px;">
                        ASTM A350 LF2 Flanges are low-temperature carbon steel flanges specifically designed for
                        <br>applications requiring high toughness at sub-zero temperatures. These <a
                            href="{{ route('products.pipe-fittings-flanges-fasteners') }}"
                            style="color: blue; text-decoration: underline;">flanges</a> are <br>widely used in industries
                        where impact resistance and reliability in cold environments <br>are critical.
                        At Moksh Tubes & Fittings LLP, we are a trusted ASTM A350 LF2 flange supplier and <br>exporter,
                        delivering high-quality flanges manufactured as per ASTM, ASME, ANSI, DIN, <br>and EN standards.
                    </p>
                    <!-- End extra content -->
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Navigation (Standardized sticky tabs)-->
    <div class="sticky-top bg-white border-bottom material-tabs w-100 shadow-sm">
        <div class="container text-center py-2">
            <a href="#overview">Overview</a> |
            <a href="#specifications">Specifications</a> |
            <a href="#types">Types</a> |
            <a href="#size-chart">Size Chart</a> |
            <a href="#chemical-composition">Chemical</a> |
            <a href="#mechanical-properties">Mechanical</a> |
            <a href="#applications">Applications</a> |
            <a href="#industries">Industries</a> |
            <a href="#manufacturing">Manufacturing</a> |
            <a href="#export">Export</a> |
            <a href="#buying-guide">Buying Guide</a> |
            <a href="#faq">FAQ</a>
        </div>
    </div>

    <!-- 1. Product Overview -->
    <section id="overview" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center">
                <h2>Product Overview</h2>
            </div>

            <h2 class="fw-semibold text-center mb-5" style="color: #db7227;">
                Introduction to ASTM A350 LF2 Flanges
            </h2>

            <div class="row align-items-center">
                <!-- Image Left -->
                <div class="col-md-6 mb-4 mb-md-0">
                    <img src="{{ asset('assets/images/fasteners/astm-a350-lf2-flanges_11zon.jpg') }}"
                        alt="ASTM A350 LF2 Flanges Overview" class="img-fluid rounded shadow-sm" loading="lazy">
                </div>

                <!-- Content Right -->
                <div class="col-md-6">
                    <div class="pe-md-3">
                        <p class="fs-6 mb-3 text-justify" style="text-align: justify;">
                            <strong class="text-black">ASTM A350 LF2</strong> is a carbon steel grade specifically developed
                            for low-temperature service. It offers excellent toughness and strength even in sub-zero
                            conditions, making it suitable for critical industrial applications.
                        </p>

                        <p class="fs-6 mb-2">LF2 flanges are preferred because:</p>
                        <ul class="fs-6 mb-3 list-unstyled">
                            <li class="mb-1"><i class="bi bi-check-circle-fill text-primary"></i> They maintain ductility
                                at
                                low temperatures</li>
                            <li class="mb-1"><i class="bi bi-check-circle-fill text-primary"></i> Provide strong
                                mechanical
                                performance</li>
                            <li class="mb-1"><i class="bi bi-check-circle-fill text-primary"></i> Ensure safety in
                                cryogenic
                                environments</li>
                        </ul>

                        <p class="fs-6 text-justify" style="text-align: justify;">
                            These flanges are ideal for <a href="{{ route('products.pipes-tubes') }}"
                                style="color: blue;">oil & gas</a>, petrochemical, and LNG handling <a
                                href="{{ url('products/pipes-tubes/welded-pipes') }}"
                                style="color: blue; text-decoration: underline;">applications</a>.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 2. Key Features -->
    <section class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center mb-5">
                <h2>Key Features</h2>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card" style="min-height: 120px;">
                        <div class="advantage-icon"><i class="bi bi-thermometer-snow"></i></div>
                        <h5>Designed for low-temperature applications</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card" style="min-height: 120px;">
                        <div class="advantage-icon"><i class="bi bi-shield-fill-check"></i></div>
                        <h5>Excellent impact resistance</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card" style="min-height: 120px;">
                        <div class="advantage-icon"><i class="bi bi-layers-fill"></i></div>
                        <h5>High strength and durability</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card" style="min-height: 120px;">
                        <div class="advantage-icon"><i class="bi bi-tools"></i></div>
                        <h5>Good weldability</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card" style="min-height: 120px;">
                        <div class="advantage-icon"><i class="bi bi-snow2"></i></div>
                        <h5>Suitable for cryogenic environments</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="advantage-card" style="min-height: 120px;">
                        <div class="advantage-icon"><i class="bi bi-lock-fill"></i></div>
                        <h5>Reliable performance under stress</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. Specifications -->
    <!-- Datasheet Download -->
    <section class="sec-padd-bottom bg-light">
        <div class="datasheet-download px-4 text-center">
            <h3 class="mb-3" style="color:#174268;">Download ASTM A350 LF2 Flanges Datasheet</h3>
            <p class="mb-3">
                Get the complete ASTM A350 LF2 Flanges datasheet with chemical composition,
                mechanical properties, heat treatment details, and applications.
                Enter your email to receive the PDF instantly.
            </p>

            <!-- Lead Capture Form -->
            <form id="leadForm" method="POST" action="{{ route('lead.capture') }}" class="mb-3">
                @csrf

                <input type="hidden" name="page_path" value="{{ $slug }}">

                <div class="row justify-content-center">
                    <div class="col-md-6 mb-2">
                        <input type="email" name="email" required class="form-control p-3"
                            placeholder="Enter your email address">
                    </div>

                    <div class="col-md-3 mb-2">
                        <button type="submit" class="btn btn-lg w-100 text-white"
                            style="background-color:#db7227; border-radius:8px;">
                            Get Datasheet
                        </button>
                    </div>
                </div>
            </form>

            @if (session('success'))
                <div class="alert alert-success mt-3">
                    {{ session('success') }}
                </div>
            @endif

            <p class="small text-muted">
                We respect your privacy. Your email will only be used to send the datasheet.
            </p>
        </div>
    </section>

    <section class="sec-padd-top sec-padd-bottom bg-light" id="specifications">
        <div class="container">
            <div class="section-title center">
                <h2>Specifications</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Category</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="t-row">
                                    <td><strong>Standard</strong></td>
                                    <td>ASTM A350 LF2 / ASME SA350 LF2</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Type</strong></td>
                                    <td><a href="{{ url('products/flanges/weld-neck-flanges') }}" s t
                                            yle="color: blue; text-decoration: none;">WN</a>, SORF, <a h r
                                            ef="{{ url('products/flanges/blind-flanges') }}" s t
                                            yle="color: blue; text-decoration: none;">Blind</a>, Socket Weld, Threaded, <a
                                            h r ef="{{ url('products/flanges/lap-joint-flanges') }}" s t
                                            yle="color: blue; text-decoration: none;">Lap Joint</a></td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Sizes</strong></td>
                                    <td>½” to 48” (DN15 to DN1200)</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Pressure Class</strong></td>
                                    <td>150, 300, 600, 900, 1500, 2500</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Facing</strong></td>
                                    <td>RF, FF, RTJ</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Material</strong></td>
                                    <td>Carbon Steel LF2</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Finish</strong></td>
                                    <td>Machined, Coated, Pickled</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. Types of LF2 Flanges -->


    <!-- 5. Size Chart -->
    <section id="size-chart" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-4">
                <h2>Size & Pressure Range</h2>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card shadow-sm border-0">
                        <div class="card-body p-4 text-center">
                            <div class="row g-4">
                                <div class="col-md-4">
                                    <h5 class="fw-bold text-primary">Pressure Class</h5>
                                    <p class="fs-6 mb-0">Class 150 to 2500</p>
                                </div>
                                <div class="col-md-4">
                                    <h5 class="fw-bold text-success">Size Range</h5>
                                    <p class="fs-6 mb-0">½” to 48”</p>
                                </div>
                                <div class="col-md-4">
                                    <h5 class="fw-bold text-warning">Customization</h5>
                                    <p class="fs-6 mb-0">Custom sizes & drilling available</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <p class="text-center mt-3 text-muted">For detailed dimension charts including bolt hole patterns and
                        weights, please contact our technical team.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. Chemical Composition & 7. Mechanical Properties -->
    <section id="chemical-composition" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="row justify-content-center g-5">
                <div class="col-lg-6">
                    <div class="section-title center mb-4">
                        <h2>Chemical Composition</h2>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Element</th>
                                    <th>Composition (%)</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td><strong>Carbon (C)</strong></td>
                                    <td>≤ 0.30</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Manganese (Mn)</strong></td>
                                    <td>0.60 – 1.35</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Silicon (Si)</strong></td>
                                    <td>0.15 – 0.30</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Phosphorus (P)</strong></td>
                                    <td>≤ 0.035</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Sulfur (S)</strong></td>
                                    <td>≤ 0.040</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p class="text-center mt-2 fw-bold text-primary"><i class="bi bi-info-circle-fill me-1"></i>Controlled
                        composition ensures low-temperature toughness and strength.</p>
                </div>

                <div id="mechanical-properties" class="col-lg-6">
                    <div class="section-title center mb-4">
                        <h2>Mechanical Properties</h2>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark text-center">
                                <tr class="t-row">
                                    <th>Property</th>
                                    <th>Value</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <tr class="t-row">
                                    <td><strong>Tensile Strength</strong></td>
                                    <td>485 – 655 MPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Yield Strength</strong></td>
                                    <td>≥ 250 MPa</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Elongation</strong></td>
                                    <td>≥ 22%</td>
                                </tr>
                                <tr class="t-row">
                                    <td><strong>Impact Test</strong></td>
                                    <td class="text-danger fw-bold">Required at low temperature</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p class="text-center mt-2 fw-bold text-success"><i class="bi bi-check-circle-fill me-1"></i>Designed
                        to
                        perform in extreme cold environments.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 8. Applications -->
    <section id="applications" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="section-title center mb-5">
                <h2>Applications</h2>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-3">
                    <div class="application-card h-100">
                        <div class="application-icon"><i class="bi bi-fuel-pump"></i></div>
                        <h5>Oil & Gas</h5>
                        <ul class="list-unstyled text-start mb-0 ps-3">
                            <li>• <a href="{{ route('products.pipes-tubes') }}" style="color: blue;">Low-temperature
                                    pipelines</a></li>
                            <li>• Offshore installations</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="application-card h-100">
                        <div class="application-icon"><i class="bi bi-snow2"></i></div>
                        <h5>LNG & Cryogenic Systems</h5>
                        <ul class="list-unstyled text-start mb-0 ps-3">
                            <li>• Storage tanks</li>
                            <li>• Gas processing plants</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="application-card h-100">
                        <div class="application-icon"><i class="bi bi-ev-station"></i></div>
                        <h5>Petrochemical</h5>
                        <ul class="list-unstyled text-start mb-0 ps-3">
                            <li>• <a href="{{ url('products/pipes-tubes/welded-pipes') }}" style="color: blue;">Process
                                    piping</a></li>
                            <li>• Chemical plants</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="application-card h-100">
                        <div class="application-icon"><i class="bi bi-lightning-charge-fill"></i></div>
                        <h5>Power Plants</h5>
                        <ul class="list-unstyled text-start mb-0 ps-3">
                            <li>• <a href="{{ url('products/pipes-tubes/boiler-heat-exchanger-tubes') }}"
                                    style="color: blue;">Low-temperature service lines</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 9. Industries Served -->


    <!-- 10. Manufacturing Process -->
    <!-- 11. Packaging & Export -->
    <section id="export" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="section-title center mb-4">
                <h2>Packaging & Export</h2>
            </div>
            <p class="fs-6 text-center text-muted mb-4">
                We are a reliable ASTM A350 LF2 flange supplier and exporter, supplying globally. <br>Trusted by EPC
                contractors and global buyers.
            </p>

            <div class="row g-4 justify-content-center">
                <div class="col-md-6 col-lg-5">
                    <div class="p-4 bg-white rounded shadow-sm border border-light h-100">
                        <h4 class="fw-bold mb-3 text-primary border-bottom pb-2">Export Markets</h4>
                        <ul class="fs-6 list-unstyled mb-0 custom-list">
                            <li><i class="bi bi-chevron-right text-warning"></i> UAE</li>
                            <li><i class="bi bi-chevron-right text-warning"></i> Saudi Arabia</li>
                            <li><i class="bi bi-chevron-right text-warning"></i> Qatar</li>
                            <li><i class="bi bi-chevron-right text-warning"></i> Oman</li>
                            <li><i class="bi bi-chevron-right text-warning"></i> Kuwait</li>
                            <li><i class="bi bi-chevron-right text-warning"></i> Europe & Southeast Asia</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 col-lg-5">
                    <div class="p-4 bg-white rounded shadow-sm border border-light h-100">
                        <h4 class="fw-bold mb-3 text-success border-bottom pb-2">Export Services</h4>
                        <ul class="fs-6 list-unstyled mb-0 custom-list">
                            <li><i class="bi bi-box-seam text-success me-2"></i> Export packaging</li>
                            <li><i class="bi bi-file-earmark-check text-success me-2"></i> EN 10204 3.1 certification</li>
                            <li><i class="bi bi-geo-alt text-success me-2"></i> Third-party inspection</li>
                            <li><i class="bi bi-truck text-success me-2"></i> Bulk project supply</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 12. Advantages & 13. LF2 vs A105 & 14. Buying Guide -->
    <section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6">
                    <div class="section-title mb-4">
                        <h2>Advantages</h2>
                    </div>
                    <ul class="fs-6 list-unstyled mb-5">
                        <li class="mb-3 p-3 bg-white border rounded shadow-sm"><i
                                class="bi bi-check-circle-fill text-primary me-2"></i> Excellent performance at low
                            temperatures</li>
                        <li class="mb-3 p-3 bg-white border rounded shadow-sm"><i
                                class="bi bi-check-circle-fill text-primary me-2"></i> High impact resistance</li>
                        <li class="mb-3 p-3 bg-white border rounded shadow-sm"><i
                                class="bi bi-check-circle-fill text-primary me-2"></i> Strong and durable material</li>
                        <li class="mb-3 p-3 bg-white border rounded shadow-sm"><i
                                class="bi bi-check-circle-fill text-primary me-2"></i> Reliable for critical applications
                        </li>
                        <li class="mb-3 p-3 bg-white border rounded shadow-sm"><i
                                class="bi bi-check-circle-fill text-primary me-2"></i> Long service life</li>
                    </ul>

                    <div class="section-title mb-4">
                        <h2>LF2 vs A105 Flanges</h2>
                    </div>
                    <div class="table-responsive bg-white rounded shadow-sm border">
                        <table class="table table-bordered table-striped align-middle mb-0">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th>Parameter</th>
                                    <th>LF2 Flanges</th>
                                    <th>A105 Flanges</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Temperature</strong></td>
                                    <td>Low-temp</td>
                                    <td>Normal temp</td>
                                </tr>
                                <tr>
                                    <td><strong>Toughness</strong></td>
                                    <td>High</td>
                                    <td>Moderate</td>
                                </tr>
                                <tr>
                                    <td><strong>Application</strong></td>
                                    <td>Cryogenic</td>
                                    <td>General</td>
                                </tr>
                                <tr>
                                    <td><strong>Cost</strong></td>
                                    <td>Slightly higher</td>
                                    <td>Lower</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p class="fs-6 mt-3 text-muted"><strong>Note:</strong> LF2 is preferred for low-temperature
                        environments, while A105 is for standard use.</p>
                </div>

                <div id="buying-guide" class="col-lg-6">
                    <div class="p-4 bg-white rounded shadow-sm border-start border-4 border-warning h-100">
                        <h3 class="fw-bold mb-4" style="color: #174268;">Buying Guide</h3>
                        <p class="fs-6 text-muted">Before selecting LF2 <a
                                href="{{ route('products.pipe-fittings-flanges-fasteners') }}"
                                style="color: blue; text-decoration: underline;">flanges</a>, consider:</p>
                        <ul class="fs-6 list-unstyled font-weight-bold">
                            <li class="mb-2"><i class="bi bi-arrow-right text-warning me-2"></i> Check operating
                                temperature
                            </li>
                            <li class="mb-2"><i class="bi bi-arrow-right text-warning me-2"></i> Select correct pressure
                                class</li>
                            <li class="mb-2"><i class="bi bi-arrow-right text-warning me-2"></i> Choose suitable flange
                                type
                            </li>
                            <li class="mb-2"><i class="bi bi-arrow-right text-warning me-2"></i> Verify certifications
                            </li>
                            <li class="mb-2"><i class="bi bi-arrow-right text-warning me-2"></i> Ensure compatibility
                                with
                                <a href="{{ route('products.pipes-tubes') }}" style="color: blue;">piping system</a>
                            </li>
                        </ul>
                        <p class="fs-6 mt-4 fw-bold p-3 bg-light rounded border text-center border-warning">We help you
                            choose the right flange for your project.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 15. Testing & Quality Control -->
    <section id="quality" class="sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-9">
                    <div class="p-4 bg-light rounded shadow-sm border-start border-4 border-primary h-100">
                        <h3 class="fw-bold mb-4 text-center" style="color: #174268;">Testing & Quality Control</h3>
                        <div class="row">
                            <div class="col-md-4">
                                <ul class="fs-6 list-unstyled">
                                    <li class="mb-2"><i class="bi bi-tools text-primary me-2"></i> • Impact testing (low
                                        temp)</li>
                                    <li class="mb-2"><i class="bi bi-tools text-primary me-2"></i> • PMI testing</li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <ul class="fs-6 list-unstyled">
                                    <li class="mb-2"><i class="bi bi-tools text-primary me-2"></i> • Ultrasonic testing
                                    </li>
                                    <li class="mb-2"><i class="bi bi-tools text-primary me-2"></i> • Hardness testing
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <ul class="fs-6 list-unstyled">
                                    <li class="mb-2"><i class="bi bi-tools text-primary me-2"></i> • Dimensional
                                        inspection
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <p class="fs-6 mt-4 fw-bold text-success text-center"><i class="bi bi-patch-check-fill me-2"></i>
                            EN
                            10204 3.1 certification available.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 16. Why Choose Us -->
    <section class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container text-center">
            <div class="section-title center">
                <h2>Why Choose Moksh Tubes & Fittings LLP</h2>
            </div>
            <div class="row g-4 mt-3 justify-content-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-box-seam"></i></div>
                        <h5>Wide stock availability</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-globe"></i></div>
                        <h5>Export expertise</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-tags-fill"></i></div>
                        <h5>Competitive pricing</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-tools"></i></div>
                        <h5>Custom solutions</h5>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="why-banner-block">
                        <div class="why-banner-icon"><i class="bi bi-truck"></i></div>
                        <h5>Fast delivery</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 17. FAQ -->
    <section id="faq" class="faq-content-area sec-padd-top sec-padd-bottom">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="accordion-box">
                        <div class="section-title center">
                            <h2>FAQ</h2>
                        </div>
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is ASTM A350 LF2 used for?</h4>
                            </div>
                            <div class="accord-content">
                                <p>Used in low-temperature and cryogenic applications.</p>
                            </div>
                        </div>
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>What is the difference between LF2 and A105?</h4>
                            </div>
                            <div class="accord-content">
                                <p>LF2 is for low temperatures, A105 is for normal conditions.</p>
                            </div>
                        </div>
                        <div class="accordion accordion-block">
                            <div class="accord-btn">
                                <h4>Do you export LF2 flanges?</h4>
                            </div>
                            <div class="accord-content">
                                <p>Yes, we export globally including GCC countries.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 18. Strong CTA -->
    <section id="contact-us" class="sec-padd-top sec-padd-bottom bg-light">
        <div class="container">
            <div class="contact-cta-box">
                <h2>Request a Quote for ASTM A350 LF2 Flanges</h2>
                <p>
                    Looking for a reliable LF2 flange supplier & exporter?<br>
                    Contact <a href="{{ route('contact-us') }}"
                        style="color: blue; text-decoration: underline;"><strong>Moksh Tubes & Fittings LLP</strong></a>
                    for
                    bulk supply, custom sizes, and fast delivery. Get the best price today.
                </p>
                <!-- Call button -->
                <a href="javascript:void(0);" class="contact-cta-btn" data-bs-toggle="modal"
                    data-bs-target="#contactFormModal">
                    Contact Us
                </a>
            </div>
        </div>
    </section>

@endsection

@section('jsscripts')
    <script type="application/ld+json">
                    @verbatim
                        {
                            "@context": "https://schema.org",
                            "@type": "FAQPage",
                            "mainEntity": [
                                {
                                    "@type": "Question",
                                    "name": "What is ASTM A350 LF2 used for?",
                                    "acceptedAnswer": {
                                        "@type": "Answer",
                                        "text": "Used in low-temperature and cryogenic applications."
                                    }
                                },
                                {
                                    "@type": "Question",
                                    "name": "What is the difference between LF2 and A105?",
                                    "acceptedAnswer": {
                                        "@type": "Answer",
                                        "text": "LF2 is for low temperatures, A105 is for normal conditions."
                                    }
                                },
                                {
                                    "@type": "Question",
                                    "name": "Do you export LF2 flanges?",
                                    "acceptedAnswer": {
                                        "@type": "Answer",
                                        "text": "Yes, we export globally including GCC countries."
                                    }
                                }
                            ]
                        }
                    @endverbatim
                </script>
@endsection
