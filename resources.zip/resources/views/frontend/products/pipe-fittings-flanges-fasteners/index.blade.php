@extends('layouts.master')
@section('title', 'Industrial Pipes, Tubes & Fittings – Mokshtubes LLP') <!-- 52 characters -->
@section(
    'meta_description',
    'Explore pipes, tubes, fittings, flanges & fasteners in stainless steel, nickel alloys, and
    titanium. Global delivery.'
) <!-- 153 characters -->
@section(
    'meta_keywords',
    'Pipe Fittings, Flanges, Fasteners, Stainless Steel Fittings, Nickel Alloy Fittings, Titanium
    Fittings, Custom Fabricated Fittings'
)
@section('content')
    <!--Start breadcrumb area-->
    <section class="breadcrumb-area"
        style="background-image: url(/assets/images/product/flangs/Flanges-&-Pipe-Fittings.webp);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-auto text-center">
                    <h1>Premium Pipe Fittings, Flanges & Fasteners</h1> <!-- 52 characters -->
                </div>
            </div>
        </div>
    </section>




    <section class="sec-padd-top sec-padd-bottom bg-white">
        <div class="container">
            <div class="section-title center mb-5">
                <h2 class="fw-bold" style="color: #174268;">Pipe Fittings Flanges Fasteners Types</h2>
            </div>

            <div class="row g-4">
                {{-- @php
                $types = [
                [
                'name' => 'Fittings And Flanges',
                'slug' => 'fittings-and-flanges',
                'image' => 'assets/images/product/flangs/Flanges-&-Pipe-Fittings.webp',
                ],
                [
                'name' => 'Flanges And Gaskets',
                'slug' => 'flanges-and-gaskets',
                'image' => 'assets/images/product/flangs/Flange-Gaskets.webp',
                ],
                [
                'name' => 'Custom Fabricated Fittings',
                'slug' => 'custom-fabricated-fittings',
                'image' => 'assets/images/product/flangs/custom-fabricated-fittings.webp',
                ],
                [
                'name' => 'Fasteners',
                'slug' => 'fasteners',
                'image' => 'assets/images/product/flangs/FASTENERS.webp',
                ],
                [
                'name' => 'Pipe Fittings ',
                'slug' => 'pipe-fittings ',
                'image' => 'assets/images/product/flangs/Pipe-Fittings.webp',
                ],
                ];
                @endphp --}}

                {{-- @foreach ($types as $type)
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('/products/pipe-fittings-flanges-fasteners/' . $type['slug']) }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">

                            <img src="{{ asset($type['image'] ?? 'assets/images/default.webp') }}" alt="{{ $type['name'] }}"
                                class="img-fluid rounded mb-3" style="border-radius: 8px;">

                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                {{ $type['name'] }}
                            </h6>
                        </div>
                    </a>
                </div>
                @endforeach --}}
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings-flanges-fasteners/fittings-and-flanges') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">

                            <img src="{{ asset('assets/images/product/flangs/Flanges-&-Pipe-Fittings.webp') }}"
                                alt="Fittings And Flanges" class="img-fluid rounded mb-3" style="border-radius: 8px;">

                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Fittings And Flanges
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings-flanges-fasteners/flanges-and-gaskets') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">

                            <img src="{{ asset('assets/images/product/flangs/Flange-Gaskets.webp') }}"
                                alt="Flanges And Gaskets" class="img-fluid rounded mb-3" style="border-radius: 8px;">

                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Flanges And Gaskets
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings-flanges-fasteners/custom-fabricated-fittings') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">

                            <img src="{{ asset('assets/images/product/flangs/custom-fabricated-fittings.webp') }}"
                                alt="Custom Fabricated Fittings" class="img-fluid rounded mb-3" style="border-radius: 8px;">

                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Custom Fabricated Fittings
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/fasteners') }}" class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">

                            <img src="{{ asset('assets/images/product/flangs/FASTENERS.webp') }}" alt="Fasteners"
                                class="img-fluid rounded mb-3" style="border-radius: 8px;">

                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Fasteners
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings') }}" class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">

                            <img src="{{ asset('assets/images/product/flangs/Pipe-Fittings.webp') }}" alt="Pipe Fittings"
                                class="img-fluid rounded mb-3" style="border-radius: 8px;">

                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Pipe Fittings
                            </h6>
                        </div>
                    </a>
                </div>
                <!-- New Flanges -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/flanges/weld-neck-flanges') }}" class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/fasteners/WNRF-Flanges_11zon.jpg') }}" alt="WNRF Flanges"
                                class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                WNRF Flanges
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/flanges/slip-on-flanges') }}" class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/fasteners/sorf-flanges_11zon.jpg') }}" alt="SORF Flanges"
                                class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                SORF Flanges
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/flanges/blind-flanges') }}" class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/fasteners/blind-flanges_11zon.jpg') }}" alt="Blind Flanges"
                                class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Blind Flanges
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/flanges/lap-joint-flanges') }}" class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/fasteners/ljff-flanges_11zon.jpeg') }}" alt="LJFF Flanges"
                                class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                LJFF Flanges
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/flanges/astm-a182-f316-flanges') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/fasteners/astm-a182-f316-flanges_11zon.jpg') }}"
                                alt="ASTM A182 F316 Flanges" class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                ASTM A182 F316 Flanges
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/flanges/astm-a350-lf2-flanges') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/fasteners/astm-a350-lf2-flanges_11zon.jpg') }}"
                                alt="ASTM A350 LF2 Flanges" class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                ASTM A350 LF2 Flanges
                            </h6>
                        </div>
                    </a>
                </div>
                <!-- New Pipe Fittings -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings/reducers/concentric') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/product/flangs/concentric-reducers_11zon.jpg') }}"
                                alt="Concentric Reducers" class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Concentric Reducers
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings/reducers/eccentric') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/product/flangs/eccentric-reducers_11zon.jpg') }}"
                                alt="Eccentric Reducers" class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                Eccentric Reducers
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings/elbows/90-degree-elbows') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/product/flangs/90-degree-elbows_11zon.jpeg') }}"
                                alt="90 Degree Elbows" class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                90 Degree Elbows
                            </h6>
                        </div>
                    </a>
                </div>
                <div class="col-12 col-sm-6 col-lg-4">
                    <a href="{{ url('products/pipe-fittings/elbows/45-degree-elbows') }}"
                        class="text-decoration-none d-block h-100">
                        <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                            style="border-color: #db7227; transition: 0.3s;">
                            <img src="{{ asset('assets/images/product/flangs/45-degree-elbows_11zon.jpg') }}"
                                alt="45 Degree Elbows" class="img-fluid rounded mb-3" style="border-radius: 8px;">
                            <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                style="background-color: #174268; color: #fff; display: inline-block;">
                                45 Degree Elbows
                            </h6>
                        </div>
                    </a>
                    {{-- U Bend card removed --}}
                    <div class="col-12 col-sm-6 col-lg-4">
                        <a href="{{ url('products/pipe-fittings/olets/weldolet') }}"
                            class="text-decoration-none d-block h-100">
                            <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                                style="border-color: #db7227; transition: 0.3s;">
                                <img src="{{ asset('assets/images/product/flangs/weldolets_11zon.jpg') }}" alt="Weldolets"
                                    class="img-fluid rounded mb-3" style="border-radius: 8px;">
                                <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                    style="background-color: #174268; color: #fff; display: inline-block;">
                                    Weldolets
                                </h6>
                            </div>
                        </a>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4">
                        <a href="{{ url('products/pipe-fittings/olets/sockolet') }}"
                            class="text-decoration-none d-block h-100">
                            <div class="material-card border rounded shadow-sm p-3 text-center h-100 transition"
                                style="border-color: #db7227; transition: 0.3s;">
                                <img src="{{ asset('assets/images/product/flangs/sockolets_11zon.jpg') }}" alt="Sockolets"
                                    class="img-fluid rounded mb-3" style="border-radius: 8px;">
                                <h6 class="text-uppercase fw-bold mb-0 py-2 px-2 rounded"
                                    style="background-color: #174268; color: #fff; display: inline-block;">
                                    Sockolets
                                </h6>
                            </div>
                        </a>
                    </div>

                    <!-- End New Pipe Fittings -->
                    <!-- End New Flanges -->
                </div>
            </div>
    </section>






    <!--End breadcrumb area-->


@endsection