<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <!-- Google Tag Manager -->
        <script>
                (function (w, d, s, l, i) {
                        w[l] = w[l] || [];
                        w[l].push({
                                'gtm.start': new Date().getTime(),
                                event: 'gtm.js'
                        });
                        var f = d.getElementsByTagName(s)[0],
                                j = d.createElement(s),
                                dl = l != 'dataLayer' ? '&l=' + l : '';
                        j.async = true;
                        j.src =
                                'https://www.googletagmanager.com/gtm.js?id=GTM-PT5QP6JV' + dl;
                        f.parentNode.insertBefore(j, f);
                })(window, document, 'script', 'dataLayer', 'GTM-PT5QP6JV');
        </script>
        <!-- End Google Tag Manager -->


        {{-- Dynamic Page Title --}}
        <title>@yield('title', 'Mokshtubes')</title>

        {{-- Dynamic Meta Description --}}
        <meta name="description" content="@yield('meta_description', 'Mokshtubes')">


        {{-- Canonical Tag --}}
        <link rel="canonical" href="@yield('canonical', request()->fullUrl())">

        <!-- Individual Page OG Override -->

        <!-- OpenGraph -->
        <meta property="og:title" content="@yield('title', 'Mokshtubes')" />
        <meta property="og:description" content="@yield('meta_description', 'Mokshtubes')" />
        <meta property="og:url" content="@yield('canonical', url()->current())" />
        <meta property="og:image"
                content="@yield('og_image', asset('assets/images/slides/mokshtubes-banner-desktop.webp'))" />
        <meta property="og:type" content="@yield('og_type', 'website')" />
        <meta property="og:site_name" content="@yield('og_site_name', 'Moksh Tubes & Fittings LLP')">

        <!-- Twitter -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="@yield('title', 'Mokshtubes')" />
        <meta name="twitter:description" content="@yield('meta_description', 'Mokshtubes')" />
        <meta name="twitter:image"
                content="@yield('og_image', asset('assets/images/slides/mokshtubes-banner-desktop.webp'))" />


        <!-- responsive meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">




        <!-- Favicon -->


        <link rel="icon" href="{{ asset('assets/images/favicon/favicon.ico') }}" type="image/x-icon">
        <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('assets/images/favicon/apple-touch-icon.png') }}">




        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">


        @yield('extracss')

        <!-- Font Awesome 6 CDN -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

        <!-- master stylesheet -->
        <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}?v={{ filemtime(public_path('assets/css/style.css')) }}">

        <!-- Responsive stylesheet -->
        <link rel="stylesheet" href="{{ asset('assets/css/responsive.css') }}?v={{ filemtime(public_path('assets/css/responsive.css')) }}">

        <style>
                .nav-link:focus-visible {
                        box-shadow: none !important;
                }

                /* Sticky CTA styling */
                .sticky-cta {
                        position: fixed;
                        bottom: 0;
                        left: 0;
                        width: 100%;
                        z-index: 9999;
                        display: flex;
                        justify-content: space-between;
                        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
                }

                .sticky-cta a,
                .sticky-cta button {
                        flex: 1;
                        border: 0;
                        margin: 0;
                        font-family: inherit;
                        line-height: inherit;
                        cursor: pointer;
                        padding: 12px 10px;
                        color: #fff !important;
                        font-size: 14px;
                        font-weight: bold;
                        text-align: center;
                        text-decoration: none;
                        text-transform: uppercase;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                }

                .sticky-cta a i,
                .sticky-cta button i {
                        margin-right: 5px;
                        font-size: 16px;
                }

                .cta-quote {
                        background: #004d99;
                }

                .cta-call {
                        background: #007bff;
                }

                .cta-whatsapp {
                        background: #25d366;
                }

                @media (min-width: 768px) {
                        .sticky-cta {
                                bottom: 20px;
                                left: 20px;
                                width: auto;
                                flex-direction: column;
                                gap: 10px;
                                box-shadow: none;
                        }

                        .sticky-cta a,
                        .sticky-cta button {
                                border-radius: 5px;
                                padding: 10px 15px;
                                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
                                transition: transform 0.3s ease;
                                justify-content: flex-start;
                        }

                        .sticky-cta a:hover,
                        .sticky-cta button:hover {
                                transform: translateY(-3px);
                        }
                }

                /* Certifications section (homepage) */
                .certifications-section {
                        background-color: #f9f9f9;
                }

                .certifications-section .cert-card {
                        background-color: #fff;
                        height: 100%;
                }

                .certifications-section .cert-img {
                        height: 250px;
                        width: 100%;
                        object-fit: contain;
                        border-radius: 4px;
                        background-color: #f8f9fa;
                }

                .certifications-section .cert-btn {
                        padding: 8px 20px;
                        font-size: 14px;
                }

                .pulse-btn {
                        animation: pulse-animation 2s infinite;
                }

                @keyframes pulse-animation {
                        0% {
                                box-shadow: 0 0 0 0 rgba(237, 28, 36, 0.7);
                        }

                        70% {
                                box-shadow: 0 0 0 10px rgba(237, 28, 36, 0);
                        }

                        100% {
                                box-shadow: 0 0 0 0 rgba(237, 28, 36, 0);
                        }
                }
        </style>
        @stack('styles')

        @verbatim
        <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "Organization",
          "@id": "https://mokshtubes.com/#organization",
          "name": "Moksh Tubes & Fittings LLP",
          "url": "https://mokshtubes.com/",
          "logo": {
            "@type": "ImageObject",
            "url": "https://mokshtubes.com/assets/images/logo/moksh-tubes-logo.png",
            "width": 818,
            "height": 248
          },
          "telephone": "+91-97695-84950",
          "sameAs": [
            "https://www.facebook.com/mokshtubes/",
            "https://www.linkedin.com/company/moksh-tubes/",
            "https://x.com/Moksh_Tubes",
            "https://www.instagram.com/mokshtubesandfittingsllp/"
          ]
        }
        </script>
        <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "WebSite",
          "@id": "https://mokshtubes.com/#website",
          "name": "Moksh Tubes & Fittings LLP",
          "url": "https://mokshtubes.com/",
          "publisher": { "@id": "https://mokshtubes.com/#organization" }
        }
        </script>
        @endverbatim

        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<body>

        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PT5QP6JV" height="0" width="0"
                        style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->


        <div class="">
                <!--Start Preloader -->

                <!--End Preloader -->

                <!--Start Top bar area -->
                <section class="top-bar-area">
                        <div class="container">
                                <div class="clearfix d-none d-sm-block">
                                        <div class="float-start">
                                                <p>Welcome to Moksh Tubes & Fittings LLP</p>
                                        </div>
                                        <div class="float-end">
                                                <p><i class="fa-regular fa-clock"></i>Monday - Friday : 8:00 AM to 7:00 PM</p>
                                        </div>
                                </div>
                                <div
                                        class="d-block d-sm-none d-flex justify-content-between align-items-center text-white">
                                        <p>
                                                <i class="fa-solid fa-phone-volume"></i>
                                                <a href="tel:9769584950" class="text-white">+91 97695 84950</a>
                                        </p>
                                        <p>
                                                <i class="fa-solid fa-envelope"></i>
                                                <a href="mailto:info@mokshtubes.com"
                                                        class="text-white">info@mokshtubes.com</a>
                                        </p>
                                </div>
                        </div>
                </section>
                <!--End Top bar area -->

                <!--Start header area-->
                <header class="header-area">
                        <div class="logo">
                                <a href="{{ route('index') }}">
                                        <img src="{{ asset('assets/images/logo/moksh-tubes-logo.png') }}" width="818" height="248" alt="Moksh Tubes &amp; Fittings LLP">
                                </a>
                        </div>
                        <div class="header-contact-info d-none d-md-block">
                                <ul>
                                        <li>
                                                <div class="iocn-holder">
                                                        <span class="icon-technology-1"></span>
                                                </div>
                                                <div class="text-holder">
                                                        <p>Call Us On</p>
                                                        <a href="tel:9769584950">
                                                                <p>+91 97695 84950</p>
                                                        </a>
                                                </div>
                                        </li>
                                        <li>
                                                <div class="iocn-holder">
                                                        <span class="icon-letter-1"></span>
                                                </div>
                                                <div class="text-holder">
                                                        <p>Mail Us @</p>
                                                        <a href="mailto:info@mokshtubes.com">
                                                                <p>info@mokshtubes.com</p>
                                                        </a>
                                                </div>
                                        </li>
                                </ul>
                        </div>
                        <div class="d-none d-sm-block d-md-none small-header-contact-info">
                                <p>
                                        <i class="fa-solid fa-phone-volume"></i>
                                        <a href="tel:9769584950">+91 97695 84950</a>
                                </p>
                                <p>
                                        <i class="fa-solid fa-envelope"></i>
                                        <a href="mailto:info@mokshtubes.com">info@mokshtubes.com</a>
                                </p>
                        </div>

                </header>
                <!--End header area-->


                <!--Start mainmenu area-->
                <section class="mainmenu-area stricky mainmenu-area-headers">
                        <div class="container-xl">
                                <div class="mainmenu-bg">
                                        <div class="row">
                                                <div class="col-sm-12 col-xs-12">

                                                        <nav class="main-menu navbar navbar-expand-lg">
                                                                <div class="navbar-header">
                                                                        <button type="button"
                                                                                class="navbar-toggler ms-3 rounded-0 border-0"
                                                                                data-bs-toggle="collapse"
                                                                                data-bs-target=".navbar-collapse">
                                                                                <span
                                                                                        class="navbar-toggler-icon"></span>
                                                                        </button>
                                                                </div>
                                                                <div class="collapse navbar-collapse clearfix">
                                                                        <ul
                                                                                class="navigation navbar-nav me-auto mb-2 mb-lg-0 clearfix">
                                                                                <li class="nav-item"><a class="nav-link"
                                                                                                href="{{ route('index') }}">Home</a>
                                                                                </li>
                                                                                <li class="nav-item"><a class="nav-link"
                                                                                                href="{{ route('about-us') }}">About
                                                                                                Us</a></li>
                                                                                <li class="nav-item dropdown"><a
                                                                                                class="nav-link"
                                                                                                href="{{ route('products') }}">Products</a>
                                                                                        <ul class="dropdown-menu">
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.pipes-tubes') }}">
                                                                                                                Pipes &
                                                                                                                Tubes <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ url('products/pipes-tubes/welded-pipes') }}">Welded
                                                                                                                                Pipes
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss304-welded-pipes') }}">SS304
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss316-welded-pipes') }}">SS316
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss304-erw-pipes') }}">SS304
                                                                                                                                                ERW
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss316-erw-pipes') }}">SS316
                                                                                                                                                ERW
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss304-semi-welded-pipes') }}">SS304
                                                                                                                                                Semi
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss316-semi-welded-pipes') }}">SS316
                                                                                                                                                Semi
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/seamless-pipes') }}">Seamless
                                                                                                                                Pipes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/boiler-heat-exchanger-tubes') }}">Boiler
                                                                                                                                &
                                                                                                                                Heat
                                                                                                                                Exchanger
                                                                                                                                Tubes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/hollow-section-pipe') }}">Hollow
                                                                                                                                Section
                                                                                                                                Pipes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/capillaries') }}">Capillary
                                                                                                                                Tubes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/u-bent-tubes') }}">U-Bend
                                                                                                                                Tubes</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.structures') }}">Structures
                                                                                                                <i class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.structures.indian-profiles') }}">Indian Profiles <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'angles']) }}">Angles</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'channels']) }}">Channels</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'beams']) }}">Beams</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'columns']) }}">Columns</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'hollow-sections']) }}">Hollow Sections</a></li>
</ul>
</li>
<li class="dropdown">
<a class="dropdown-item d-flex justify-content-between align-items-center"
href="{{ route('products.structures.american-profiles') }}">American Profiles <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
<li>
    <a href="{{ route('products.structures.american.angel') }}">Angles</a>
</li>                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'channels']) }}">Channels</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'beams']) }}">Beams</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'columns']) }}">Columns</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'hollow-sections']) }}">Hollow Sections</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.structures.european-profiles') }}">European Profiles (EN) <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'angles']) }}">Angles</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'channels']) }}">Channels</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'beams']) }}">Beams</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'columns']) }}">Columns</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'hollow-sections']) }}">Hollow Sections</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.sheets-plates-coils') }}">
                                                                                                                Sheets,
                                                                                                                Plates &
                                                                                                                Coils <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/chequered-sheets') }}">Chequered
                                                                                                                                Sheets</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/strips') }}">Strips</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/shim-sheets') }}">Shim
                                                                                                                                Sheets</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/sheets-and-plates') }}">Sheets
                                                                                                                                &
                                                                                                                                Plates</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/perforated-sheets') }}">Perforated
                                                                                                                                Sheets</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/coils') }}">Coils</a>
                                                                                                                </li>
                                                                                                                        <li><a href="{{ url('products/sheets-plates-coils/cladded-plates') }}">Cladded
                                                                                                                                Plates</a>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.mild-steel') }}">Mild Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 'ms-is-2062-e250']) }}">MS IS 2062 E250</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 'ms-is-2062-e350']) }}">MS IS 2062 E350 (A/BR/C)</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 'a36']) }}">A36</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 's275jr']) }}">S275JR</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.carbon-steel') }}">Carbon Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'bq-plates-sa-516-gr-60-70']) }}">BQ Plates - SA 516 Gr 60/70</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'sa-537-class-1']) }}">SA 537 Class 1</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'sa-537-class-2']) }}">SA 537 Class 2</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'c45']) }}">C45</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.stainless-steel') }}">Stainless Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'ss-300-series']) }}">SS 300 Series</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'ss-400-series']) }}">SS 400 Series</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'austenitic']) }}">Austenitic</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'ferritic']) }}">Ferritic</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'martensitic']) }}">Martensitic</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.alloy-steel') }}">Alloy Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-11']) }}">SA 387 Gr 11</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-12']) }}">SA 387 Gr 12</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-22']) }}">SA 387 Gr 22</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-p5']) }}">SA 387 Gr P5</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-p9']) }}">SA 387 Gr P9</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-p91']) }}">SA 387 Gr P91</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => '16mo3']) }}">16Mo3</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.abrasion-resistant-steel') }}">Abrasion Resistant Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'abrasion-resistant-steel', 'slug' => 'rockstar-400-500']) }}">Rockstar 400/500</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'abrasion-resistant-steel', 'slug' => 'rockhard-400-500']) }}">Rockhard 400/500</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'abrasion-resistant-steel', 'slug' => 'nm-400-500']) }}">NM 400/500</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.high-strength-steel') }}">High Strength Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 'sail-hard']) }}">SAIL Hard</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 'jindal-hard']) }}">Jindal Hard</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 'uttam-hard']) }}">Uttam Hard</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 's690ql']) }}">S690QL</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 's700mc']) }}">S700MC</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.special-steel-grades') }}">Special Steel Grades <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'special-steel-grades', 'slug' => 'high-manganese-mn13']) }}">High Manganese MN13 Grade</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'special-steel-grades', 'slug' => 'corten-a']) }}">Corten A</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'special-steel-grades', 'slug' => 'corten-b']) }}">Corten B (IRSM 41-97)</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                        </ul>
        </li>
        <li class="dropdown">
                <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.pipe-fittings') }}">
                                                                                                                Pipe
                                                                                                                Fittings
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Elbows
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/elbows/90-degree-elbows') }}">90
                                                                                                                                                Degree
                                                                                                                                                Elbow</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/elbows/45-degree-elbows') }}">45
                                                                                                                                                Degree
                                                                                                                                                Elbow</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Bends
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/bends/90-degree-bend') }}">90
                                                                                                                                                Degree
                                                                                                                                                Bend</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/bends/45-degree-bend') }}">45
                                                                                                                                                Degree
                                                                                                                                                Bend</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Reducers
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/reducers/concentric') }}">Concentric</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/reducers/eccentric') }}">Eccentric</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Olets
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/olets/weldolet') }}">Weldolet</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/olets/sockolet') }}">Sockolet</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                {{-- U
                                                                                                                Bend
                                                                                                                removed
                                                                                                                --}}
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.flanges') }}">
                                                                                                                Flanges
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/flanges/weld-neck-flanges') }}">Weld
                                                                                                                                Neck
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/slip-on-flanges') }}">Slip
                                                                                                                                On
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/blind-flanges') }}">Blind
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/lap-joint-flanges') }}">Lap
                                                                                                                                Joint
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/threaded-flanges') }}">Threaded
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/socket-weld-flanges') }}">Socket
                                                                                                                                Weld
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/spectacle-blind-flanges') }}">Spectacle
                                                                                                                                Blind
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.bars-rods') }}">
                                                                                                                Bars &
                                                                                                                Rods <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/bars-rods/square-bars') }}">Square
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/threaded-rods') }}">Threaded
                                                                                                                                Rods</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/round-bars') }}">Round
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/hollow-bars') }}">Hollow
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/hexagon-bars') }}">Hexagon
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/flat-bars') }}">Flat
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.fasteners') }}">
                                                                                                                Fasteners
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/fasteners/studs') }}">Studs</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/threaded-rods') }}">Threaded
                                                                                                                                Rods</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/hex-bolts') }}">Hex
                                                                                                                                Bolts</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/nuts') }}">Nuts</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/washers') }}">Washers</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/socket-head-screws') }}">Socket
                                                                                                                                Head
                                                                                                                                Screws</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/allen-bolts') }}">Allen
                                                                                                                                Bolts</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.special-fabricated') }}">
                                                                                                                Special
                                                                                                                Fabricated
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/special-fabricated/custom-steel-furniture') }}">Custom
                                                                                                                                Steel
                                                                                                                                Furniture</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/special-fabricated/fabricated-ss-grills') }}">Fabricated
                                                                                                                                SS
                                                                                                                                Grills</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/special-fabricated/ss-railings') }}">SS
                                                                                                                                Railings</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/special-fabricated/glass-railings') }}">Glass
                                                                                                                                Railings</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>

                                                                                        </ul>
                                                                                </li>


                                                                                <li class="nav-item dropdown">
                                                                                        <a class="nav-link"
                                                                                                href="{{ route('materials') }}">Materials</a>
                                                                                        <ul class="dropdown-menu">
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.hastelloy') }}">Hastelloy
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c276') }}">Hastelloy
                                                                                                                                C276</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c22') }}">Hastelloy
                                                                                                                                C22</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c4') }}">Hastelloy
                                                                                                                                C4</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-b2') }}">Hastelloy
                                                                                                                                B2</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-b3') }}">Hastelloy
                                                                                                                                B3</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c2000') }}">Hastelloy
                                                                                                                                C2000</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-g3') }}">Hastelloy
                                                                                                                                G3</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-g30') }}">Hastelloy
                                                                                                                                G30</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-x') }}">Hastelloy
                                                                                                                                X</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.monel') }}">Monel
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/monel/monel-400') }}">Monel
                                                                                                                                400</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/monel/monel-k500') }}">Monel
                                                                                                                                K500</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/monel/monel-r405') }}">Monel
                                                                                                                                R405</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.incoloy') }}">Incoloy
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-020') }}">Incoloy
                                                                                                                                020</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-800') }}">Incoloy
                                                                                                                                800</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-800h-800ht') }}">Incoloy
                                                                                                                                800H/800HT</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-825') }}">Incoloy
                                                                                                                                825</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-925') }}">Incoloy
                                                                                                                                925</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.nickel-Based-Superalloys') }}">Nickel
                                                                                                                Based
                                                                                                                Superalloys
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/nickel-based-superalloys/nickel-based-superalloys-200') }}">Nickel
                                                                                                                                200</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/nickel-based-superalloys/nickel-based-superalloys-201') }}">Nickel
                                                                                                                                201</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/nickel-based-superalloys/nickel-based-superalloys-a286-ais660') }}">A286-AIS660</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.inconel') }}">Inconel
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-600') }}">Inconel
                                                                                                                                600</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-617') }}">Inconel
                                                                                                                                617</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-625') }}">Inconel
                                                                                                                                625</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-690') }}">Inconel
                                                                                                                                690</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-718') }}">Inconel
                                                                                                                                718</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-x750') }}">Inconel
                                                                                                                                X750</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.titanium') }}">Titanium
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-1') }}">Titanium
                                                                                                                                Gr
                                                                                                                                1</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-2') }}">Titanium
                                                                                                                                Gr
                                                                                                                                2</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-4') }}">Titanium
                                                                                                                                Gr
                                                                                                                                4</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-4-eli') }}">Titanium
                                                                                                                                Gr
                                                                                                                                4
                                                                                                                                ELI</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-5') }}">Titanium
                                                                                                                                Gr
                                                                                                                                5</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-5-eli') }}">Titanium
                                                                                                                                Gr
                                                                                                                                5
                                                                                                                                ELI</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-7') }}">Titanium
                                                                                                                                Gr
                                                                                                                                7</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-7-nb') }}">Titanium
                                                                                                                                Gr
                                                                                                                                7
                                                                                                                                Nb</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-9') }}">Titanium
                                                                                                                                Gr
                                                                                                                                9</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-12') }}">Titanium
                                                                                                                                Gr
                                                                                                                                12</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-23') }}">Titanium
                                                                                                                                Gr
                                                                                                                                23</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.aluminium-Alloys') }}">Aluminium
                                                                                                                Alloys
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-1100') }}">Aluminium
                                                                                                                                1100</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-1200') }}">Aluminium
                                                                                                                                1200</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-2014-t6') }}">Aluminium
                                                                                                                                2014-T6</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-5083') }}">Aluminium
                                                                                                                                5083</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6012') }}">Aluminium
                                                                                                                                6012</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6061-t6') }}">Aluminium
                                                                                                                                6061-T6</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6063') }}">Aluminium
                                                                                                                                6063</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6082-t6') }}">Aluminium
                                                                                                                                6082-T6</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-he30') }}">Aluminium
                                                                                                                                HE30</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys7075') }}">Aluminium
                                                                                                                                7075</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.super-Austenitic-Stainless-Steel') }}">Super
                                                                                                                Austenitic
                                                                                                                Stainless
                                                                                                                Steel <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-smo-254') }}">SMO
                                                                                                                                254</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-smo-654') }}">SMO
                                                                                                                                654</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-904l') }}">Alloy
                                                                                                                                904L</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-alloy-926') }}">Alloy
                                                                                                                                926</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-al-6xn') }}">AL-6XN</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-253-ma') }}">253
                                                                                                                                MA</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.hard-To-Find-Special-Alloys') }}">Hard
                                                                                                                To Find
                                                                                                                Special
                                                                                                                Alloys
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-carbide') }}">Carbide</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-nimonic') }}">Nimonic</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-nitinol') }}">Nitinol</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-stellite') }}">Stellite</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-tantalum') }}">Tantalum</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-tungsten') }}">Tungsten</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.engineering-Steels') }}">Engineering
                                                                                                                Steels
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en8') }}">EN8</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en9') }}">EN9</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en19') }}">EN19</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en24') }}">EN24</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en31') }}">EN31</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en36') }}">EN36</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en47') }}">EN47</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-1045') }}">1045</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-1055') }}">1055</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-4130') }}">4130</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-4140') }}">4140</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-4340') }}">4340</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-d2') }}">D2</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p1') }}">P1</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p11') }}">P11</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p12') }}">P12</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p22') }}">P22</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.austenitic-stainless-Steel') }}">Austenitic
                                                                                                                Stainless
                                                                                                                Steel <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-304') }}">SS
                                                                                                                                304</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-309') }}">SS
                                                                                                                                309</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-310') }}">SS
                                                                                                                                310</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-316') }}">SS
                                                                                                                                316</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-316ti') }}">SS
                                                                                                                                316Ti</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-317') }}">SS
                                                                                                                                317</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-321') }}">SS
                                                                                                                                321</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-347') }}">SS
                                                                                                                                347</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-nitronic-50') }}">Nitronic
                                                                                                                                50</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-nitronic-60') }}">Nitronic
                                                                                                                                60</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.copper-Alloys') }}">Copper
                                                                                                                Alloys
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-cu-ni-90-10') }}">Copper
                                                                                                                                Nickel
                                                                                                                                90/10</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-cu-ni-70-30') }}">Copper
                                                                                                                                Nickel
                                                                                                                                70/30</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-aluminium-bronze') }}">Aluminium
                                                                                                                                Bronze</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-beryllium-copper') }}">Beryllium
                                                                                                                                Copper</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c44300') }}">C44300</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c46400') }}">C46400</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c63000') }}">C63000</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c71500') }}">C71500</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c71520') }}">C71520</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-cartridge-brass') }}">Cartridge
                                                                                                                                Brass</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-ec-copper') }}">EC
                                                                                                                                Copper</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-etp-copper') }}">ETP
                                                                                                                                Copper</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-navel-brass') }}">Navel
                                                                                                                                Brass</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.zirconium') }}">Zirconium
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/zirconium/zirconium-702') }}">Zirconium
                                                                                                                                702</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/zirconium/zirconium-704') }}">Zirconium
                                                                                                                                704</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/zirconium/zirconium-705') }}">Zirconium
                                                                                                                                705</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.haynes-Superalloys') }}">Haynes
                                                                                                                Superalloys
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-160') }}">Haynes
                                                                                                                                160</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-188') }}">Haynes
                                                                                                                                188</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-230') }}">Haynes
                                                                                                                                230</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-242') }}">Haynes
                                                                                                                                242</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.duplex-and-super-duplex') }}">Duplex
                                                                                                                and
                                                                                                                Super
                                                                                                                Duplex
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/duplex-s31803') }}">Duplex
                                                                                                                                S31803</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/super-duplex-2205') }}">Super
                                                                                                                                Duplex
                                                                                                                                2205</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/super-duplex-2507') }}">Super
                                                                                                                                Duplex
                                                                                                                                2507</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/super-duplex-s32760') }}">Super
                                                                                                                                Duplex
                                                                                                                                S32760</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('materials.high-strength-stainless-steel') }}">High
                                                                                                                Strength
                                                                                                                Stainless
                                                                                                                Steel <i
                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/14-4ph-stainless-steel') }}">14-4
                                                                                                                                PH</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/15-5ph-stainless-steel') }}">15-5
                                                                                                                                PH</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/17-4ph-stainless-steel') }}">17-4
                                                                                                                                PH</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-403') }}">SS
                                                                                                                                403</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-405') }}">SS
                                                                                                                                405</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-410') }}">SS
                                                                                                                                410</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-416') }}">SS
                                                                                                                                416</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-420') }}">SS
                                                                                                                                420</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/420hc-stainless-steel') }}">SS
                                                                                                                                420HC</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-422') }}">SS
                                                                                                                                422</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/430f-stainless-steel') }}">SS
                                                                                                                                430F</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-431') }}">SS
                                                                                                                                431</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/440a-stainless-steel') }}">SS
                                                                                                                                440A</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/440b-stainless-steel') }}">SS
                                                                                                                                440B</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/440c-stainless-steel') }}">SS
                                                                                                                                440C</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                        </ul>
                                                                                </li>


                                                                                <li class="nav-item"><a
                                                                                                class="nav-link">Quality</a>
                                                                                </li>
                                                                                <li class="nav-item"><a class="nav-link"
                                                                                                href="{{ route('calculator') }}">Calculator</a>
                                                                                </li>
                                                                                <li class="nav-item"><a class="nav-link"
                                                                                                href="{{ route('blogs') }}">Blogs</a>
                                                                                </li>
                                                                        </ul>
                                                                        <ul class="mobile-menu clearfix">
                                                                                <li><a href="{{ route('index') }}">Home</a>
                                                                                </li>
                                                                                <li><a href="{{ route('about-us') }}">About
                                                                                                Us</a></li>
                                                                                <li class="dropdown"><a
                                                                                                href="{{ route('products') }}">Products</a>
                                                                                        <ul>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('products.pipes-tubes') }}">PIPES
                                                                                                                &
                                                                                                                TUBES</a>
                                                                                                        <ul>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ url('products/pipes-tubes/welded-pipes') }}">Welded
                                                                                                                                Pipes
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss304-welded-pipes') }}">SS304
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss316-welded-pipes') }}">SS316
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss304-erw-pipes') }}">SS304
                                                                                                                                                ERW
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss316-erw-pipes') }}">SS316
                                                                                                                                                ERW
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss304-semi-welded-pipes') }}">SS304
                                                                                                                                                Semi
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipes-tubes/welded-pipes/ss316-semi-welded-pipes') }}">SS316
                                                                                                                                                Semi
                                                                                                                                                Welded
                                                                                                                                                Pipes</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/seamless-pipes') }}">Seamless
                                                                                                                                Pipes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/boiler-heat-exchanger-tubes') }}">Boiler
                                                                                                                                &
                                                                                                                                Heat
                                                                                                                                Exchanger
                                                                                                                                Tubes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/hollow-section-pipe') }}">Hollow
                                                                                                                                Section
                                                                                                                                Pipes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/capillaries') }}">Capillary
                                                                                                                                Tubes</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/pipes-tubes/u-bent-tubes') }}">U-Bend
                                                                                                                                Tubes</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.structures') }}">Structures
                                                                                                                <i class="fa fa-angle-right"></i></a>
                                                                                                        <ul>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.structures.indian-profiles') }}">Indian Profiles <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'angles']) }}">Angles</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'channels']) }}">Channels</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'beams']) }}">Beams</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'columns']) }}">Columns</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'indian-profiles', 'slug' => 'hollow-sections']) }}">Hollow Sections</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.structures.american-profiles') }}">American Profiles (ASTM / AISC) <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.structures.american.angel') }}">Angles</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'channels']) }}">Channels</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'beams']) }}">Beams</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'columns']) }}">Columns</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'american-profiles', 'slug' => 'hollow-sections']) }}">Hollow Sections</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.structures.european-profiles') }}">European Profiles (EN) <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'angles']) }}">Angles</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'channels']) }}">Channels</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'beams']) }}">Beams</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'columns']) }}">Columns</a></li>
                                                                                                                                <li><a href="{{ route('products.structures.profile.item', ['profile' => 'european-profiles', 'slug' => 'hollow-sections']) }}">Hollow Sections</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                        </ul>
</li>
<li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.sheets-plates-coils') }}">
                                                                                                                Sheets,
                                                                                                                Plates &
                                                                                                                Coils <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/chequered-sheets') }}">Chequered
                                                                                                                                Sheets</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/strips') }}">Strips</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/shim-sheets') }}">Shim
                                                                                                                                Sheets</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/sheets-and-plates') }}">Sheets
                                                                                                                                &
                                                                                                                                Plates</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/perforated-sheets') }}">Perforated
                                                                                                                                Sheets</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/coils') }}">Coils</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/sheets-plates-coils/cladded-plates') }}">Cladded
                                                                                                                                Plates</a>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.mild-steel') }}">Mild Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 'ms-is-2062-e250']) }}">MS IS 2062 E250</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 'ms-is-2062-e350']) }}">MS IS 2062 E350 (A/BR/C)</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 'a36']) }}">A36</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'mild-steel', 'slug' => 's275jr']) }}">S275JR</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.carbon-steel') }}">Carbon Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'bq-plates-sa-516-gr-60-70']) }}">BQ Plates - SA 516 Gr 60/70</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'sa-537-class-1']) }}">SA 537 Class 1</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'sa-537-class-2']) }}">SA 537 Class 2</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'carbon-steel', 'slug' => 'c45']) }}">C45</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.stainless-steel') }}">Stainless Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'ss-300-series']) }}">SS 300 Series</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'ss-400-series']) }}">SS 400 Series</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'austenitic']) }}">Austenitic</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'ferritic']) }}">Ferritic</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'stainless-steel', 'slug' => 'martensitic']) }}">Martensitic</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.alloy-steel') }}">Alloy Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-11']) }}">SA 387 Gr 11</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-12']) }}">SA 387 Gr 12</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-22']) }}">SA 387 Gr 22</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-p5']) }}">SA 387 Gr P5</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-p9']) }}">SA 387 Gr P9</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => 'sa-387-gr-p91']) }}">SA 387 Gr P91</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'alloy-steel', 'slug' => '16mo3']) }}">16Mo3</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.abrasion-resistant-steel') }}">Abrasion Resistant Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'abrasion-resistant-steel', 'slug' => 'rockstar-400-500']) }}">Rockstar 400/500</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'abrasion-resistant-steel', 'slug' => 'rockhard-400-500']) }}">Rockhard 400/500</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'abrasion-resistant-steel', 'slug' => 'nm-400-500']) }}">NM 400/500</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.high-strength-steel') }}">High Strength Steel <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 'sail-hard']) }}">SAIL Hard</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 'jindal-hard']) }}">Jindal Hard</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 'uttam-hard']) }}">Uttam Hard</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 's690ql']) }}">S690QL</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'high-strength-steel', 'slug' => 's700mc']) }}">S700MC</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li class="dropdown">
                                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                                href="{{ route('products.sheets-plates-coils.special-steel-grades') }}">Special Steel Grades <i class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'special-steel-grades', 'slug' => 'high-manganese-mn13']) }}">High Manganese MN13 Grade</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'special-steel-grades', 'slug' => 'corten-a']) }}">Corten A</a></li>
                                                                                                                                <li><a href="{{ route('products.sheets-plates-coils.item', ['category' => 'special-steel-grades', 'slug' => 'corten-b']) }}">Corten B (IRSM 41-97)</a></li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                        </ul>
</li>
<li class="dropdown">
<a class="dropdown-item d-flex justify-content-between align-items-center"
href="{{ route('products.bars-rods') }}">
                                                                                                                Bars &
                                                                                                                Rods <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/bars-rods/square-bars') }}">Square
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/threaded-rods') }}">Threaded
                                                                                                                                Rods</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/round-bars') }}">Round
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/hollow-bars') }}">Hollow
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/hexagon-bars') }}">Hexagon
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/bars-rods/flat-bars') }}">Flat
                                                                                                                                Bars</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
<li><a href="{{ route('products.pipe-fittings-flanges-fasteners') }}">PIPE
        FITTINGS,
                                                                                                                FLANGES
                                                                                                                &
                                                                                                                FASTENERS</a>
</li>
<li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.pipe-fittings') }}">
                                                                                                                Pipe
                                                                                                                Fittings
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Elbows
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/elbows/90-degree-elbows') }}">90
                                                                                                                                                Degree
                                                                                                                                                Elbow</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/elbows/45-degree-elbows') }}">45
                                                                                                                                                Degree
                                                                                                                                                Elbow</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Bends
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/bends/90-degree-bend') }}">90
                                                                                                                                                Degree
                                                                                                                                                Bend</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/bends/45-degree-bend') }}">45
                                                                                                                                                Degree
                                                                                                                                                Bend</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Reducers
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/reducers/concentric') }}">Concentric</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/reducers/eccentric') }}">Eccentric</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                <li
                                                                                                                        class="dropdown">
                                                                                                                        <a
                                                                                                                                class="dropdown-item d-flex justify-content-between align-items-center">Olets
                                                                                                                                <i
                                                                                                                                        class="fa fa-angle-right"></i></a>
                                                                                                                        <ul>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/olets/weldolet') }}">Weldolet</a>
                                                                                                                                </li>
                                                                                                                                <li><a href="{{ url('products/pipe-fittings/olets/sockolet') }}">Sockolet</a>
                                                                                                                                </li>
                                                                                                                        </ul>
                                                                                                                </li>
                                                                                                                {{-- U
                                                                                                                Bend
                                                                                                                removed
                                                                                                                --}}
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.flanges') }}">
                                                                                                                Flanges
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/flanges/weld-neck-flanges') }}">Weld
                                                                                                                                Neck
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/slip-on-flanges') }}">Slip
                                                                                                                                On
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/blind-flanges') }}">Blind
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/lap-joint-flanges') }}">Lap
                                                                                                                                Joint
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/threaded-flanges') }}">Threaded
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/socket-weld-flanges') }}">Socket
                                                                                                                                Weld
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/flanges/spectacle-blind-flanges') }}">Spectacle
                                                                                                                                Blind
                                                                                                                                Flanges</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.fasteners') }}">
                                                                                                                Fasteners
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/fasteners/studs') }}">Studs</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/threaded-rods') }}">Threaded
                                                                                                                                Rods</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/hex-bolts') }}">Hex
                                                                                                                                Bolts</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/nuts') }}">Nuts</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/washers') }}">Washers</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/socket-head-screws') }}">Socket
                                                                                                                                Head
                                                                                                                                Screws</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/fasteners/allen-bolts') }}">Allen
                                                                                                                                Bolts</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown">
                                                                                                        <a class="dropdown-item d-flex justify-content-between align-items-center"
                                                                                                                href="{{ route('products.special-fabricated') }}">
                                                                                                                Special
                                                                                                                Fabricated
                                                                                                                <i
                                                                                                                        class="fa fa-angle-right"></i>
                                                                                                        </a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('products/special-fabricated/custom-steel-furniture') }}">Custom
                                                                                                                                Steel
                                                                                                                                Furniture</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/special-fabricated/fabricated-ss-grills') }}">Fabricated
                                                                                                                                SS
                                                                                                                                Grills</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/special-fabricated/ss-railings') }}">SS
                                                                                                                                Railings</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('products/special-fabricated/glass-railings') }}">Glass
                                                                                                                                Railings</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                        </ul>
                                                                                </li>
                                                                                <li class="dropdown"><a
                                                                                                href="{{ route('materials') }}">Materials</a>
                                                                                        <ul>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.hastelloy') }}">Hastelloy</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c276') }}">Hastelloy
                                                                                                                                C276</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c22') }}">Hastelloy
                                                                                                                                C22</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c4') }}">Hastelloy
                                                                                                                                C4</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-b2') }}">Hastelloy
                                                                                                                                B2</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-b3') }}">Hastelloy
                                                                                                                                B3</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-c2000') }}">Hastelloy
                                                                                                                                C2000</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-g3') }}">Hastelloy
                                                                                                                                G3</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-g30') }}">Hastelloy
                                                                                                                                G30</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hastelloy/hastelloy-x') }}">Hastelloy
                                                                                                                                X</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.monel') }}">Monel</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/monel/monel-400') }}">Monel
                                                                                                                                400</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/monel/monel-k500') }}">Monel
                                                                                                                                K500</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/monel/monel-r405') }}">Monel
                                                                                                                                R405</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.incoloy') }}">Incoloy</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-020') }}">Incoloy
                                                                                                                                020</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-800') }}">Incoloy
                                                                                                                                800</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-800h-800ht') }}">Incoloy
                                                                                                                                800H/800HT</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-825') }}">Incoloy
                                                                                                                                825</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/incoloy/incoloy-925') }}">Incoloy
                                                                                                                                925</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.nickel-Based-Superalloys') }}">Nickel
                                                                                                                Based
                                                                                                                Superalloys</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/nickel-based-superalloys/nickel-based-superalloys-200') }}">Nickel
                                                                                                                                200</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/nickel-based-superalloys/nickel-based-superalloys-201') }}">Nickel
                                                                                                                                201</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/nickel-based-superalloys/nickel-based-superalloys-a286-ais660') }}">A286-AIS660</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.inconel') }}">Inconel</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-600') }}">Inconel
                                                                                                                                600</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-617') }}">Inconel
                                                                                                                                617</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-625') }}">Inconel
                                                                                                                                625</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-690') }}">Inconel
                                                                                                                                690</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-718') }}">Inconel
                                                                                                                                718</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/inconel/inconel-x750') }}">Inconel
                                                                                                                                X750</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.titanium') }}">Titanium</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-1') }}">Titanium
                                                                                                                                Gr
                                                                                                                                1</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-2') }}">Titanium
                                                                                                                                Gr
                                                                                                                                2</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-4') }}">Titanium
                                                                                                                                Gr
                                                                                                                                4</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-4-eli') }}">Titanium
                                                                                                                                Gr
                                                                                                                                4
                                                                                                                                ELI</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-5') }}">Titanium
                                                                                                                                Gr
                                                                                                                                5</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-5-eli') }}">Titanium
                                                                                                                                Gr
                                                                                                                                5
                                                                                                                                ELI</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-7') }}">Titanium
                                                                                                                                Gr
                                                                                                                                7</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-7-nb') }}">Titanium
                                                                                                                                Gr
                                                                                                                                7
                                                                                                                                Nb</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-9') }}">Titanium
                                                                                                                                Gr
                                                                                                                                9</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-12') }}">Titanium
                                                                                                                                Gr
                                                                                                                                12</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/titanium/titanium-grade-23') }}">Titanium
                                                                                                                                Gr
                                                                                                                                23</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.aluminium-Alloys') }}">Aluminium
                                                                                                                Alloys</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-1100') }}">Aluminium
                                                                                                                                1100</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-1200') }}">Aluminium
                                                                                                                                1200</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-2014-t6') }}">Aluminium
                                                                                                                                2014-T6</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-5083') }}">Aluminium
                                                                                                                                5083</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6012') }}">Aluminium
                                                                                                                                6012</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6061-t6') }}">Aluminium
                                                                                                                                6061-T6</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6063') }}">Aluminium
                                                                                                                                6063</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-6082-t6') }}">Aluminium
                                                                                                                                6082-T6</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys-he30') }}">Aluminium
                                                                                                                                HE30</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/aluminium-alloys/aluminium-alloys7075') }}">Aluminium
                                                                                                                                7075</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.super-Austenitic-Stainless-Steel') }}">Super
                                                                                                                Austenitic
                                                                                                                Stainless
                                                                                                                Steel</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-smo-254') }}">SMO
                                                                                                                                254</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-smo-654') }}">SMO
                                                                                                                                654</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-904l') }}">Alloy
                                                                                                                                904L</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-alloy-926') }}">Alloy
                                                                                                                                926</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-al-6xn') }}">AL-6XN</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/super-austenitic-stainless-steel/super-austenitic-stainless-steel-253-ma') }}">253
                                                                                                                                MA</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.hard-To-Find-Special-Alloys') }}">Hard
                                                                                                                To Find
                                                                                                                Special
                                                                                                                Alloys</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-carbide') }}">Carbide</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-nimonic') }}">Nimonic</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-nitinol') }}">Nitinol</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-stellite') }}">Stellite</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-tantalum') }}">Tantalum</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/hard-to-find-special-alloys/hard-to-find-special-alloys-tungsten') }}">Tungsten</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.engineering-Steels') }}">Engineering
                                                                                                                Steels</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en8') }}">EN8</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en9') }}">EN9</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en19') }}">EN19</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en24') }}">EN24</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en31') }}">EN31</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en36') }}">EN36</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-en47') }}">EN47</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-1045') }}">1045</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-1055') }}">1055</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-4130') }}">4130</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-4140') }}">4140</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-4340') }}">4340</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-d2') }}">D2</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p1') }}">P1</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p11') }}">P11</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p12') }}">P12</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/engineering-steels/engineering-steels-p22') }}">P22</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.austenitic-stainless-Steel') }}">Austenitic
                                                                                                                Stainless
                                                                                                                Steel</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-304') }}">SS
                                                                                                                                304</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-309') }}">SS
                                                                                                                                309</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-310') }}">SS
                                                                                                                                310</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-316') }}">SS
                                                                                                                                316</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-316ti') }}">SS
                                                                                                                                316Ti</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-317') }}">SS
                                                                                                                                317</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-321') }}">SS
                                                                                                                                321</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-347') }}">SS
                                                                                                                                347</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-nitronic-50') }}">Nitronic
                                                                                                                                50</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/austenitic-stainless-steel/austenitic-stainless-steel-nitronic-60') }}">Nitronic
                                                                                                                                60</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.copper-Alloys') }}">Copper
                                                                                                                Alloys</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-cu-ni-90-10') }}">Copper
                                                                                                                                Nickel
                                                                                                                                90/10</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-cu-ni-70-30') }}">Copper
                                                                                                                                Nickel
                                                                                                                                70/30</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-aluminium-bronze') }}">Aluminium
                                                                                                                                Bronze</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-beryllium-copper') }}">Beryllium
                                                                                                                                Copper</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c44300') }}">C44300</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c46400') }}">C46400</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c63000') }}">C63000</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c71500') }}">C71500</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-c71520') }}">C71520</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-cartridge-brass') }}">Cartridge
                                                                                                                                Brass</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-ec-copper') }}">EC
                                                                                                                                Copper</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-etp-copper') }}">ETP
                                                                                                                                Copper</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/copper-alloys/copper-alloys-navel-brass') }}">Navel
                                                                                                                                Brass</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.zirconium') }}">Zirconium</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/zirconium/zirconium-702') }}">Zirconium
                                                                                                                                702</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/zirconium/zirconium-704') }}">Zirconium
                                                                                                                                704</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/zirconium/zirconium-705') }}">Zirconium
                                                                                                                                705</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.haynes-Superalloys') }}">Haynes
                                                                                                                Superalloys</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-160') }}">Haynes
                                                                                                                                160</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-188') }}">Haynes
                                                                                                                                188</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-230') }}">Haynes
                                                                                                                                230</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/haynes-superalloys/haynes-superalloys-242') }}">Haynes
                                                                                                                                242</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.duplex-and-super-duplex') }}">Duplex
                                                                                                                and
                                                                                                                Super
                                                                                                                Duplex</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/duplex-s31803') }}">Duplex
                                                                                                                                S31803</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/super-duplex-2205') }}">Super
                                                                                                                                Duplex
                                                                                                                                2205</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/super-duplex-2507') }}">Super
                                                                                                                                Duplex
                                                                                                                                2507</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/duplex-and-super-duplex/super-duplex-s32760') }}">Super
                                                                                                                                Duplex
                                                                                                                                S32760</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                                <li class="dropdown"><a
                                                                                                                href="{{ route('materials.high-strength-stainless-steel') }}">High
                                                                                                                Strength
                                                                                                                Stainless
                                                                                                                Steel</a>
                                                                                                        <ul>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/14-4ph-stainless-steel') }}">14-4
                                                                                                                                PH</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/15-5ph-stainless-steel') }}">15-5
                                                                                                                                PH</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/17-4ph-stainless-steel') }}">17-4
                                                                                                                                PH</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-403') }}">SS
                                                                                                                                403</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-405') }}">SS
                                                                                                                                405</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-410') }}">SS
                                                                                                                                410</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-416') }}">SS
                                                                                                                                416</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-420') }}">SS
                                                                                                                                420</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/420hc-stainless-steel') }}">SS
                                                                                                                                420HC</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-422') }}">SS
                                                                                                                                422</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/430f-stainless-steel') }}">SS
                                                                                                                                430F</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/stainless-steel-431') }}">SS
                                                                                                                                431</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/440a-stainless-steel') }}">SS
                                                                                                                                440A</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/440b-stainless-steel') }}">SS
                                                                                                                                440B</a>
                                                                                                                </li>
                                                                                                                <li><a href="{{ url('materials/high-strength-stainless-steel/440c-stainless-steel') }}">SS
                                                                                                                                440C</a>
                                                                                                                </li>
                                                                                                        </ul>
                                                                                                </li>
                                                                                        </ul>
                                                                                </li>

                                                                                <li><a>Quality</a></li>
                                                                                <li><a href="{{ route('calculator') }}">Calculator</a>
                                                                                </li>
                                                                                <li><a href="{{ route('blogs') }}">Blogs</a>
                                                                                </li>

                                                                        </ul>
                                                                </div>
                                                        </nav>

                                                </div>
                                        </div>
                                        <div class="right-column">
                                                <div class="right-area">

                                                        <div class="link_btn float_right">
                                                                <a href="{{ route('contact-us') }}"
                                                                        class="thm-btn bg-clr1">Contact Us</a>
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                        </div>
                </section>

                <!--End mainmenu area-->


                @yield('content')

                <!--Start footer area-->
                <footer>
                        <div class="footer-main sec-padd2">
                                <div class="container">
                                        <div class="row">
                                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                                        <div class="footer-col">
                                                                <div class="logo-part">
                                                                        <a href="{{ route('index') }}"
                                                                                class="footer-logo text-uppercase">
                                                                                <img src="{{ asset('assets/images/logo/moksh-tubes-logo.png') }}" width="818" height="248"
                                                                                        alt="Moksh Tubes &amp; Fittings LLP">
                                                                        </a>
                                                                </div>
                                                                <p class="footer-words">With over 20 years of experience
                                                                        since 2005, we supply stainless steel pipes, tubes and
                                                                        fittings that meet international standards. Our focus
                                                                        is on reliable quality at an economical price.</p>
                                                                <address class="footer-words">
                                                                        <i class="fa-solid fa-location-dot"></i>
                                                                        Office No. 20, 2nd Floor, Bldg. No. 36/40, Hinglaj Bhavan,
                                                                        Kika Street, Gulalwadi, Mumbai 400004, India<br>
                                                                        <i class="fa-solid fa-phone"></i>
                                                                        <a href="tel:+919769584950">+91 97695 84950</a><br>
                                                                        <i class="fa-solid fa-envelope"></i>
                                                                        <a href="mailto:info@mokshtubes.com">info@mokshtubes.com</a>
                                                                </address>
                                                                <ul class="list-inline footer-social mb-0">
                                                                        <li class="list-inline-item">
                                                                                <a href="https://www.facebook.com/mokshtubes/"
                                                                                        target="_blank" rel="noopener">
                                                                                        <i
                                                                                                class="fab fa-facebook-f"></i>
                                                                                </a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                                <a href="https://www.instagram.com/mokshtubesandfittingsllp/"
                                                                                        target="_blank" rel="noopener">
                                                                                        <i class="fab fa-instagram"></i>
                                                                                </a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                                <a href="https://www.linkedin.com/company/moksh-tubes/"
                                                                                        target="_blank" rel="noopener">
                                                                                        <i
                                                                                                class="fab fa-linkedin-in"></i>
                                                                                </a>
                                                                        </li>
                                                                        <li class="list-inline-item">
                                                                                <a href="https://x.com/Moksh_Tubes"
                                                                                        target="_blank" rel="noopener">
                                                                                        <i class="fab fa-x-twitter"></i>
                                                                                </a>
                                                                        </li>
                                                                </ul>


                                                        </div>
                                                </div>

                                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 ">
                                                        <div class="footer-col service-col">
                                                                <h3 class="footer-title">Products</h3>
                                                                <ul class="footer-list">
                                                                        <li><a href="{{ route('products.pipes-tubes') }}">PIPES
                                                                                        & TUBES</a>
                                                                        </li>
                                                                        <li><a href="{{ route('products.sheets-plates-coils') }}">SHEETS,
                                                                                        PLATES &
                                                                                        COILS</a></li>
                                                                        <li><a href="{{ route('products.bars-rods') }}">BARS
                                                                                        & RODS</a></li>
                                                                        <li><a href="{{ route('products.pipe-fittings-flanges-fasteners') }}">PIPE
                                                                                        FITTINGS, FLANGES &
                                                                                        FASTENERS</a></li>
                                                                        <li><a href="{{ route('products.special-fabricated') }}">SPECIAL
                                                                                        FABRICATED</a>
                                                                        </li>
                                                                </ul>
                                                        </div>
                                                </div>


                                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                                        <div class="footer-col post-column">
                                                                <h3 class="footer-title">Materials</h3>
                                                                <ul class="footer-list">
                                                                        <li><a href="{{ route('materials.hastelloy') }}">HASTELLOY</a>
                                                                        </li>
                                                                        <li><a href="{{ route('materials.austenitic-stainless-Steel') }}">AUSTENTIC
                                                                                        STAINLESS STEEL</a>
                                                                        </li>
                                                                        <li><a href="{{ route('materials.engineering-Steels') }}">ENGINEERING
                                                                                        STEELS</a>
                                                                        </li>
                                                                        <li><a href="{{ route('materials.copper-Alloys') }}">COPPER
                                                                                        ALLOYS</a>
                                                                        </li>
                                                                        <li><a href="{{ route('materials.nickel-Based-Superalloys') }}">NICKEL
                                                                                        BASED
                                                                                        SUPERALLOYS</a></li>
                                                                        <li><a href="{{ route('materials.inconel') }}">INCONEL</a>
                                                                        </li>
                                                                </ul>

                                                        </div>
                                                </div>

                                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                                        <div class="footer-col">
                                                                <h3 class="footer-title">Useful Links</h3>
                                                                <ul class="footer-list">
                                                                        <li><a href="{{ route('index') }}">Home</a></li>
                                                                        <li><a href="{{ route('about-us') }}">About
                                                                                        Us</a></li>
                                                                        <li><a href="{{ route('products') }}">Our
                                                                                        Products</a></li>
                                                                        <li><a href="{{ route('blogs') }}">Blogs</a>
                                                                        </li>
                                                                        <li><a href="{{ route('contact-us') }}">Contact
                                                                                        Us</a></li>
                                                                </ul>

                                                        </div>
                                                </div>

                                        </div>
                                </div>
                        </div>
                        <div class="footer-bottom">
                                <div class="container">
                                        <div class="row align-items-center">
                                                <div class="col-md-3">
                                                        <p class="copyright mb-0">
                                                                © {{ date('Y') }} Moksh Tubes &amp; Fittings LLP. All rights reserved | Designed by
                                                                <a href="https://naze.in/" target="_blank"
                                                                        rel="noopener noreferrer "
                                                                        style="color: #db7227"
                                                                        class="text-decoration-none">
                                                                        Naze Technology
                                                                </a>
                                                        </p>
                                                </div>
                                                <div class="col-md-9">
                                                        <nav class="footer-menu d-flex justify-content-end">
                                                                <ul class="nav">
                                                                        <li class="nav-item"><a class="nav-link"
                                                                                        href="{{ route('index') }}">Home</a>
                                                                        </li>
                                                                        <li class="nav-item"><a class="nav-link"
                                                                                        href="{{ route('products') }}">Products</a>
                                                                        </li>
                                                                        <li class="nav-item"><a class="nav-link">Terms
                                                                                        &amp;
                                                                                        Conditions</a>
                                                                        </li>
                                                                        <li class="nav-item"><a class="nav-link">Privacy
                                                                                        Policy</a></li>
                                                                        <li class="nav-item"><a class="nav-link"
                                                                                        href="{{ route('contact-us') }}">Contact
                                                                                        Us</a></li>
                                                                </ul>
                                                        </nav>
                                                </div>
                                        </div>
                                </div>
                        </div>

                </footer>



                <!-- Sticky CTA Floating Buttons -->
                <div class="sticky-cta">
                        <button type="button" data-bs-toggle="modal" data-bs-target="#contactFormModal"
                                class="cta-quote"><i class="fa fa-envelope"></i> Get Quote</button>
                        <a href="tel:+919769584950" class="cta-call"><i class="fa fa-phone"></i> Call Now</a>
                        <a href="https://wa.me/919769584950" target="_blank" class="cta-whatsapp"><i
                                        class="fa-brands fa-whatsapp"></i> WhatsApp</a>
                </div>


                <!-- Contact Form Modal -->
                <!-- Contact Form Modal -->
                <div class="modal fade" id="contactFormModal" tabindex="-1" role="dialog"
                        aria-labelledby="contactFormModalLabel" aria-hidden="true" style="z-index: 2000;">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content p-3" style="z-index:2001;">

                                        <!-- Modal Header -->
                                        <div class="modal-header">
                                                <h5 class="modal-title fw-bold fs-3" id="contactFormModalLabel">Get in
                                                        Touch</h5>
                                                <button type="button" class="close ms-auto" data-bs-dismiss="modal"
                                                        aria-label="Close" style="font-size: 3rem;">
                                                        <span aria-hidden="true">&times;</span>
                                                </button>
                                        </div>

                                        <!-- Modal Body -->
                                        <div class="modal-body">
                                                <form id="contact-form-modal" name="contact_form" class="default-form"
                                                        action="{{ url('sendmail') }}" method="post">
                                                        @csrf
                                                        <div class="row">
                                                                <!-- Honeypot Anti-Bot Field -->
                                                                <input type="text" name="website"
                                                                        style="display:none !important;" tabindex="-1"
                                                                        autocomplete="off">
                                                                <div class="col-md-12 mb-3">
                                                                        <input class="form-control" type="text"
                                                                                name="form_name"
                                                                                placeholder="Your Name*" required>
                                                                </div>
                                                                <div class="col-md-12 mb-3">
                                                                        <input class="form-control" type="email"
                                                                                name="form_email"
                                                                                placeholder="Your Mail*" required>
                                                                </div>
                                                                <div class="col-md-12 mb-3">
                                                                        <input class="form-control" type="text"
                                                                                name="form_phone" placeholder="Phone">
                                                                </div>
                                                                <div class="col-md-12 mb-3">
                                                                        <textarea name="form_message"
                                                                                class="form-control"
                                                                                placeholder="Your Message.."
                                                                                required></textarea>
                                                                </div>
                                                                <div class="col-md-12 mb-3">
                                                                        <div class="g-recaptcha"
                                                                                data-sitekey="{{ env('RECAPTCHA_SITE_KEY') }}"
                                                                                style="margin-bottom:10px;"></div>
                                                                </div>
                                                                <div class="col-md-12 text-end">
                                                                        <input id="form_botcheck_modal" name="form_botcheck"
                                                                                type="hidden" value="">
                                                                        <button class="thm-btn bg-clr1" type="submit"
                                                                                data-loading-text="Please wait...">
                                                                                Send Message
                                                                        </button>
                                                                </div>
                                                        </div>
                                                </form>
                                        </div>

                                </div>
                        </div>
                </div>



                @if (!Cookie::get('cookie_consent'))
                        <div id="cookie-consent" class="position-fixed text-white shadow-lg"
                                style="background: rgba(33,33,33,0.95);
                                                                                                                                                                                                                                                                                                                                                                                               bottom: 0;
                                                                                                                                                                                                                                                                                                                                                                                               left: 0;
                                                                                                                                                                                                                                                                                                                                                                                               right: 0;
                                                                                                                                                                                                                                                                                                                                                                                               width: 100%;
                                                                                                                                                                                                                                                                                                                                                                                               z-index: 999999;
                                                                                                                                                                                                                                                                                                                                                                                               display: none;
                                                                                                                                                                                                                                                                                                                                                                                               border-radius: 0;
                                                                                                                                                                                                                                                                                                                                                                                               padding: 15px 20px;">
                                <div class="container">
                                        <div class="row align-items-center">
                                                <!-- Text -->
                                                <div class="col-12 col-sm-9 mb-3 mb-sm-0">
                                                        <p class="mb-0 small text-white">
                                                                We use cookies to personalize content, improve site performance,
                                                                and analyze traffic.
                                                                Some
                                                                cookies are essential for the site to function correctly. You
                                                                can manage your
                                                                preferences or
                                                                accept all cookies.
                                                        </p>
                                                </div>

                                                <!-- Buttons -->
                                                <div class="col-12 col-sm-3">
                                                        <div class="justify-content-between p-2">
                                                                <button id="reject-cookies" class="btn btn-sm border text-white"
                                                                        style="border-color:#db7227; margin-right:10px;">Reject</button>
                                                                <button id="accept-cookies" class="btn btn-sm text-white"
                                                                        style="background-color:#db7227;">Accept</button>
                                                        </div>
                                                </div>

                                        </div>
                                </div>
                        </div>
                @endif











                <!--Scroll to top-->
                <div class="scroll-to-top scroll-to-target" data-bs-target="html"><span class="fa fa-angle-up"></span>
                </div>
                <!-- All scripts below are deferred: they run in document order once the HTML is parsed,
                     before DOMContentLoaded. Inline scripts must not use jQuery/bootstrap at parse time. -->
                <!-- jQuery 1.12.4 (minified) + WOW -->
                <script src="{{ asset('assets/js/core.bundle.min.js') }}" defer></script>
                <script>
                        // The HTML may be served from Cloudflare's cache with a stale CSRF token,
                        // so fetch a fresh one (once) before any form or AJAX POST is sent.
                        (function () {
                                let tokenRequest = null;
                                let tokenFresh = false;

                                window.refreshCsrfToken = function () {
                                        if (!tokenRequest) {
                                                tokenRequest = fetch("{{ route('csrf-token') }}", {
                                                        credentials: "same-origin",
                                                        cache: "no-store"
                                                })
                                                        .then(res => res.json())
                                                        .then(data => {
                                                                document.querySelector('meta[name="csrf-token"]')
                                                                        .setAttribute("content", data.token);
                                                                document.querySelectorAll('input[name="_token"]')
                                                                        .forEach(input => input.value = data.token);
                                                                tokenFresh = true;
                                                        })
                                                        .catch(err => {
                                                                console.error("CSRF token error:", err);
                                                                tokenRequest = null;
                                                        });
                                        }
                                        return tokenRequest;
                                };

                                // Fetch as soon as the visitor starts using a form or opens the modal
                                document.addEventListener("focusin", function (e) {
                                        if (e.target.closest && e.target.closest("form")) window.refreshCsrfToken();
                                });
                                document.addEventListener("show.bs.modal", function () {
                                        window.refreshCsrfToken();
                                });

                                // Hold back submission until the fresh token is in place
                                document.addEventListener("submit", function (e) {
                                        const form = e.target;
                                        if (tokenFresh || !form.querySelector('input[name="_token"]')) return;
                                        e.preventDefault();
                                        Promise.resolve(window.refreshCsrfToken()).then(() => form.submit());
                                }, true);
                        })();
                </script>
                <script>
                        document.addEventListener("DOMContentLoaded", function () {
                                const popup = document.getElementById("cookie-consent");
                                if (!popup) return;

                                setTimeout(() => popup.style.display = "block", 3000);

                                async function sendConsent(url) {
                                        await window.refreshCsrfToken();
                                        fetch(url, {
                                                method: "POST",
                                                headers: {
                                                        "Content-Type": "application/json",
                                                        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute(
                                                                "content"),
                                                },
                                                credentials: "same-origin" // 👈 VERY IMPORTANT: allows cookies to be saved
                                        })
                                                .then(res => res.json())
                                                .then(data => {
                                                        console.log("Cookie status:", data.status);
                                                        popup.style.display = "none";
                                                })
                                                .catch(err => console.error("Cookie error:", err));
                                }

                                document.getElementById("accept-cookies")?.addEventListener("click", () => sendConsent(
                                        "{{ route('cookie.accept') }}"));
                                document.getElementById("reject-cookies")?.addEventListener("click", () => sendConsent(
                                        "{{ route('cookie.reject') }}"));
                        });
                </script>



                <!-- Bootstrap 5.3.6 Bundle JS (includes Popper) - keep version in sync with the CSS in <head> -->
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" defer></script>

                <!-- Page-specific plugins (revolution slider, owl carousel, counters); pages push them with defer -->
                @stack('vendor-scripts')

                <!-- thm custom script -->
                <script src="{{ asset('assets/js/custom.js') }}" defer></script>
                <script>
                        // Load Google Maps embeds only when the visitor asks for them
                        document.addEventListener("click", function (e) {
                                const btn = e.target.closest(".map-facade-btn");
                                if (!btn) return;
                                const iframe = btn.parentElement.querySelector("iframe[data-src]");
                                iframe.src = iframe.dataset.src;
                                iframe.removeAttribute("data-src");
                                btn.remove();
                        });
                </script>








        </div>
        @yield('extrajs')
        @yield('jsscripts')

        <!--Start of Tawk.to Script-->
        <script type="text/javascript">
                var Tawk_API = Tawk_API || {},
                        Tawk_LoadStart = new Date();
                Tawk_API.customStyle = {
                        visibility: {
                                desktop: {
                                        position: 'br', // bottom-right
                                        xOffset: 18,
                                        yOffset: 80 // ⬆ moves it UP
                                },
                                mobile: {
                                        position: 'br',
                                        xOffset: 10,
                                        yOffset: 70
                                }
                        }
                };
                (function () {
                        var s1 = document.createElement("script"),
                                s0 = document.getElementsByTagName("script")[0];
                        s1.async = true;
                        s1.src = 'https://embed.tawk.to/692d953abb2f8419802db9ae/1jbd0trj6';
                        s1.charset = 'UTF-8';
                        s1.setAttribute('crossorigin', '*');
                        s0.parentNode.insertBefore(s1, s0);
                })();
        </script>
        <!--End of Tawk.to Script-->
</body>



</html>